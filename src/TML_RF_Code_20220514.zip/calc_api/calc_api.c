/*******************************************************************************
**	File name		: calc_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Err32_def_api.h"
#include "calc_api.h"
#include "common.h"
#include "mem_map.h"

/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] SolveDmatrixMultiplication22_21

[arguments]
mat1_22			    :	the data of Matrix
mat2_21			    :	the data of Matrix
matrixResult21    	:	the result of the multiplication


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SolveDmatrixMultiplication22_21(float *mat1_22, float *mat2_21, float *matrixResult21)
{
    if (NULL == mat1_22)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == mat2_21)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == matrixResult21)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    // uint32_t iCount = 0;
    float matrix1[MATRIX_SIZE];
    float matrix2[MATRIX_SIZE];
    Calculate_Typedef_22_st *calc_result;
    unsigned long long reg_VirthBaseAddr_Mat;

    mem_mmap(MATRIX_BASE_DDR, MATRIX_DDR_SIZE, &reg_VirthBaseAddr_Mat);

    /* transform the data */
    matrix1[0] = mat1_22[0];
    matrix1[1] = mat1_22[2];
    matrix1[2] = mat1_22[1];
    matrix1[3] = mat1_22[3];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX1_22_OFFSET), matrix1, sizeof(float) * 4);

    /* transform the data */
    matrix2[0] = mat2_21[0];
    matrix2[1] = mat2_21[2];
    matrix2[2] = mat2_21[1];
    matrix2[3] = mat2_21[3];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX2_22_OFFSET), matrix2, sizeof(float) * 4);
    calc_result = (Calculate_Typedef_22_st *)(reg_VirthBaseAddr_Mat + MATRIX3_22_OFFSET);

    /* transform the data */
    matrixResult21[0] = calc_result->a[0];
    matrixResult21[2] = calc_result->a[1];
    matrixResult21[1] = calc_result->b[0];
    matrixResult21[3] = calc_result->b[1];

    mem_unmap(reg_VirthBaseAddr_Mat, MATRIX_DDR_SIZE);

    return NO_ERROR;
}

/*********************************************************************************
[function name] SolveDmatrixMultiplication33_31

[arguments]
mat1_33			    :	the data of Matrix
mat2_31			    :	the data of Matrix
matrixResult31    	:	the result of the multiplication


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SolveDmatrixMultiplication33_31(float *mat1_33, float *mat2_31, float *matrixResult31)
{
    if (NULL == mat1_33)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == mat2_31)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == matrixResult31)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    uint32_t iCount = 0;
    float matrix1[MATRIX_SIZE];
    float matrix2[MATRIX_SIZE];
    Calculate_Typedef_33_st *calc_result;
    unsigned long long reg_VirthBaseAddr_Mat;

    mem_mmap(MATRIX_BASE_DDR, MATRIX_DDR_SIZE, &reg_VirthBaseAddr_Mat);

    /* transform the data */
    matrix1[0] = mat1_33[0];
    matrix1[1] = mat1_33[3];
    matrix1[2] = mat1_33[6];
    matrix1[3] = mat1_33[1];
    matrix1[4] = mat1_33[4];
    matrix1[5] = mat1_33[7];
    matrix1[6] = mat1_33[2];
    matrix1[7] = mat1_33[5];
    matrix1[8] = mat1_33[8];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX1_33_OFFSET), matrix1, sizeof(float) * 9);
    DEBUG_INFO("matrix1 set successfully");

    /* transform the data */
    matrix2[0] = mat2_31[0];
    matrix2[1] = mat2_31[3];
    matrix2[2] = mat2_31[6];
    matrix2[3] = mat2_31[1];
    matrix2[4] = mat2_31[4];
    matrix2[5] = mat2_31[7];
    matrix2[6] = mat2_31[2];
    matrix2[7] = mat2_31[5];
    matrix2[8] = mat2_31[8];

    DEBUG_INFO("---------------------------------\n");
    for (iCount = 0; iCount < 9; iCount++)
    {
        *((float *)(reg_VirthBaseAddr_Mat + MATRIX2_33_OFFSET + (iCount * 4))) = matrix2[iCount];
    }

    DEBUG_INFO("---------------------------------\n");
    // memcpy(reg_VirthBaseAddr_Mat + MATRIX2_33_OFFSET, matrix2, sizeof(float) * 9);
    DEBUG_INFO("matrix2 set successfully");
    calc_result = (Calculate_Typedef_33_st *)(reg_VirthBaseAddr_Mat + MATRIX3_33_OFFSET);

    /* transform the data */
    matrixResult31[0] = calc_result->a[0];
    matrixResult31[3] = calc_result->a[1];
    matrixResult31[6] = calc_result->a[2];
    matrixResult31[1] = calc_result->b[0];
    matrixResult31[4] = calc_result->b[1];
    matrixResult31[7] = calc_result->b[2];
    matrixResult31[2] = calc_result->c[0];
    matrixResult31[5] = calc_result->c[1];
    matrixResult31[8] = calc_result->c[2];

    mem_unmap(reg_VirthBaseAddr_Mat, MATRIX_DDR_SIZE);

    return NO_ERROR;
}

/*********************************************************************************
[function name] SolveSqrt

[arguments]
calc			    :	the data
calcResult		    :	the result of calculation


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SolveSqrt(float calc, float *calcResult)
{
    if (0 >= calc)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == calcResult)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    unsigned long long reg_VirthBaseAddr_Mat;

    mem_mmap(MATRIX_BASE_DDR, MATRIX_DDR_SIZE, &reg_VirthBaseAddr_Mat);
    *(float *)(reg_VirthBaseAddr_Mat + MATRIX_DIN_OFFSET) = calc;

    *calcResult = *(float *)(reg_VirthBaseAddr_Mat + MATRIX_SQRT_OFFSET);

    return NO_ERROR;
}

/*********************************************************************************
[function name] SolveDmatrixMultiplication22_22

[arguments]
mat1_22			    :	the data of Matrix
mat2_22			    :	the data of Matrix
matrixResult22    	:	the result of the multiplication


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SolveDmatrixMultiplication22_22(float *mat1_22, float *mat2_22, float *matrixResult22)
{
    if (NULL == mat1_22)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == mat2_22)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == matrixResult22)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }

    // uint32_t iCount = 0;
    float matrix1[MATRIX_SIZE];
    float matrix2[MATRIX_SIZE];
    Calculate_Typedef_22_st *calc_result;
    unsigned long long reg_VirthBaseAddr_Mat;

    mem_mmap(MATRIX_BASE_DDR, MATRIX_DDR_SIZE, &reg_VirthBaseAddr_Mat);

    /* transform the data */
    matrix1[0] = mat1_22[0];
    matrix1[1] = mat1_22[2];
    matrix1[2] = mat1_22[1];
    matrix1[3] = mat1_22[3];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX1_22_OFFSET), matrix1, sizeof(float) * 4);

    /* transform the data */
    matrix2[0] = mat2_22[0];
    matrix2[1] = mat2_22[2];
    matrix2[2] = mat2_22[1];
    matrix2[3] = mat2_22[3];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX2_22_OFFSET), matrix2, sizeof(float) * 4);
    calc_result = (Calculate_Typedef_22_st *)(reg_VirthBaseAddr_Mat + MATRIX3_22_OFFSET);

    /* transform the data */
    matrixResult22[0] = calc_result->a[0];
    matrixResult22[2] = calc_result->a[1];
    matrixResult22[1] = calc_result->b[0];
    matrixResult22[3] = calc_result->b[1];

    mem_unmap(reg_VirthBaseAddr_Mat, MATRIX_DDR_SIZE);

    return NO_ERROR;
}

/*********************************************************************************
[function name] SolveDmatrixMultiplication33_33

[arguments]
mat1_33			    :	the data of Matrix
mat2_33			    :	the data of Matrix
matrixResult33    	:	the result of the multiplication


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SolveDmatrixMultiplication33_33(float *mat1_33, float *mat2_33, float *matrixResult33)
{
    if (NULL == mat1_33)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == mat2_33)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }
    if (NULL == matrixResult33)
    {
        printf("parameter error");
        return PARAM_ERROR;
    }

    uint32_t iCount = 0;
    float matrix1[MATRIX_SIZE];
    float matrix2[MATRIX_SIZE];
    Calculate_Typedef_33_st *calc_result;
    unsigned long long reg_VirthBaseAddr_Mat;

    mem_mmap(MATRIX_BASE_DDR, MATRIX_DDR_SIZE, &reg_VirthBaseAddr_Mat);

    /* transform the data */
    matrix1[0] = mat1_33[0];
    matrix1[1] = mat1_33[3];
    matrix1[2] = mat1_33[6];
    matrix1[3] = mat1_33[1];
    matrix1[4] = mat1_33[4];
    matrix1[5] = mat1_33[7];
    matrix1[6] = mat1_33[2];
    matrix1[7] = mat1_33[5];
    matrix1[8] = mat1_33[8];

    memcpy((void *)(reg_VirthBaseAddr_Mat + MATRIX1_33_OFFSET), matrix1, sizeof(float) * 9);
    DEBUG_INFO("matrix1 set successfully");

    /* transform the data */
    matrix2[0] = mat2_33[0];
    matrix2[1] = mat2_33[3];
    matrix2[2] = mat2_33[6];
    matrix2[3] = mat2_33[1];
    matrix2[4] = mat2_33[4];
    matrix2[5] = mat2_33[7];
    matrix2[6] = mat2_33[2];
    matrix2[7] = mat2_33[5];
    matrix2[8] = mat2_33[8];

    DEBUG_INFO("---------------------------------\n");
    for (iCount = 0; iCount < 9; iCount++)
    {
        *((float *)(reg_VirthBaseAddr_Mat + MATRIX2_33_OFFSET + (iCount * 4))) = matrix2[iCount];
    }

    DEBUG_INFO("---------------------------------\n");
    // memcpy(reg_VirthBaseAddr_Mat + MATRIX2_33_OFFSET, matrix2, sizeof(float) * 9);
    DEBUG_INFO("matrix2 set successfully");
    calc_result = (Calculate_Typedef_33_st *)(reg_VirthBaseAddr_Mat + MATRIX3_33_OFFSET);

    /* transform the data */
    matrixResult33[0] = calc_result->a[0];
    matrixResult33[3] = calc_result->a[1];
    matrixResult33[6] = calc_result->a[2];
    matrixResult33[1] = calc_result->b[0];
    matrixResult33[4] = calc_result->b[1];
    matrixResult33[7] = calc_result->b[2];
    matrixResult33[2] = calc_result->c[0];
    matrixResult33[5] = calc_result->c[1];
    matrixResult33[8] = calc_result->c[2];

    mem_unmap(reg_VirthBaseAddr_Mat, MATRIX_DDR_SIZE);

    return NO_ERROR;
}