/*******************************************************************************
**	File name		: calc_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

#ifndef __CALC_API_H__
#define __CALC_API_H__

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define MATRIX_SIZE 9
#define MATRIX_BASE_DDR 0x80000000
#define MATRIX_DDR_SIZE 0x7FFF
#define MATRIX1_33_OFFSET 0x200
#define MATRIX2_33_OFFSET 0x224
#define MATRIX3_33_OFFSET 0x248
#define MATRIX1_22_OFFSET 0x280
#define MATRIX2_22_OFFSET 0x290
#define MATRIX3_22_OFFSET 0x2A0
#define MATRIX_DIN_OFFSET 0x270
#define MATRIX_SQRT_OFFSET 0x274

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct
{
    float a[3];
    float b[3];
    float c[3];
} Calculate_Typedef_33_st;

typedef struct
{
    float a[2];
    float b[2];
} Calculate_Typedef_22_st;
/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int SolveDmatrixMultiplication22_21(float *mat1_22, float *mat2_21, float *matrixResult21);
extern int SolveDmatrixMultiplication33_31(float *mat1_33, float *mat2_31, float *matrixResult31);
extern int SolveSqrt(float calc, float *calcResult);
extern int SolveDmatrixMultiplication22_22(float *mat1_22, float *mat2_22, float *matrixResult22);
extern int SolveDmatrixMultiplication33_33(float *mat1_33, float *mat2_33, float *matrixResult33);

#endif
