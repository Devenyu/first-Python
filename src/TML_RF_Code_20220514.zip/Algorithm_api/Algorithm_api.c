/*******************************************************************************
**	File name		: Algorithm_api.c                                         **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2022/03/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

// #include<sys/mman.h>
#include "mem_map.h"
#include "common.h"
#include "eeprom_api.h"
#include "Err32_def_api.h"
#include "Algorithm_api.h"


/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] GetFeatureVal

[arguments]
pFreqData			:	First address of the structure containing the frequency data
num			        :	the valid num of structure
dataSetNum			:	Number of data sets for 10 msec periodic data

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetFeatureVal(freqData *pFreqData, int *num, int dataSetNum)
{
    /* judge the parameters */
    if (NULL == pFreqData)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    uint32_t read_point = 0;
    uint32_t write_point = 0;
    // uint32_t feature_val[10000]; // Box to store Max,Min,Lvl1-5 average (for now)
    uint32_t cnt = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    uint32_t n = 1;   // system n = 1 or 2
    uint32_t iRet = 0;
    uint32_t iValue_wadr = 0;
    uint32_t iValue_sadr = 0;
    uint32_t iValue_block = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    // pFreqData->Max = *(unsigned *)(reg_VirthBaseAddr + MAX_OFFSET);
    do
    {
        write_point = *(unsigned *)(reg_VirthBaseAddr + RAM_COUNT_OFFSET + (vip * 0x1000));
        // DEBUG_INFO("the val of write_point is 0x%8x", write_point);
        // DEBUG_INFO("--------------------------------------------------");

        while ((read_point != write_point) && (read_point + 1) != write_point && (write_point % 2) == 0)
        {

            *(unsigned *)(reg_VirthBaseAddr + RAM_MON_OFFSET + (vip * 0x1000)) = read_point + (n - 1);

            pFreqData[cnt].Max = *(float *)(reg_VirthBaseAddr + MAX_OFFSET + (vip * 0x1000));           // Max set
            pFreqData[cnt].Min = *(float *)(reg_VirthBaseAddr + MIN_OFFSET + (vip * 0x1000));           // Min set
            pFreqData[cnt].Lvl1Ave = *(float *)(reg_VirthBaseAddr + LVL1AVE_OFFSET + (vip * 0x1000));   // Lv1 average set
            pFreqData[cnt].Lvl2Ave = *(float *)(reg_VirthBaseAddr + LVL2AVE_OFFSET + (vip * 0x1000));   // Lv2 average set
            pFreqData[cnt].Lvl3Ave = *(float *)(reg_VirthBaseAddr + LVL3AVE_OFFSET + (vip * 0x1000));   // Lv3 average set
            pFreqData[cnt].Lvl4Ave = *(float *)(reg_VirthBaseAddr + LVL4AVE_OFFSET + (vip * 0x1000));   // Lv4 average set
            pFreqData[cnt].Lvl5Ave = *(float *)(reg_VirthBaseAddr + LVL5AVE_OFFSET + (vip * 0x1000));   // Lv5 average set
            pFreqData[cnt].Lvl1Duty = *(float *)(reg_VirthBaseAddr + LVL1DUTY_OFFSET + (vip * 0x1000)); // Lv1 Duty set
            pFreqData[cnt].Lvl2Duty = *(float *)(reg_VirthBaseAddr + LVL2DUTY_OFFSET + (vip * 0x1000)); // Lv2 Duty set
            pFreqData[cnt].Lvl3Duty = *(float *)(reg_VirthBaseAddr + LVL3DUTY_OFFSET + (vip * 0x1000)); // Lv3 Duty set
            pFreqData[cnt].Lvl4Duty = *(float *)(reg_VirthBaseAddr + LVL4DUTY_OFFSET + (vip * 0x1000)); // Lv4 Duty set
            pFreqData[cnt].Lvl5Duty = *(float *)(reg_VirthBaseAddr + LVL5DUTY_OFFSET + (vip * 0x1000)); // Lv5 Duty set

            // feature_val[0 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + MAX_OFFSET + (vip * 0x1000));     // Max set
            // feature_val[1 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + MIN_OFFSET + (vip * 0x1000));     // Min set
            // feature_val[2 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + LVL1AVE_OFFSET + (vip * 0x1000)); // Lv1 average set
            // feature_val[3 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + LVL2AVE_OFFSET + (vip * 0x1000)); // Lv2 average set
            // feature_val[4 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + LVL3AVE_OFFSET + (vip * 0x1000)); // Lv3 average set
            // feature_val[5 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + LVL4AVE_OFFSET + (vip * 0x1000)); // Lv4 average set
            // feature_val[6 + (cnt * 7)] = *(unsigned *)(reg_VirthBaseAddr + LVL5AVE_OFFSET + (vip * 0x1000)); // Lv5 average set
            if (0 != pFreqData[cnt].Max)
            {
                DEBUG_INFO("--------------------------------------------------");
                DEBUG_INFO("the val of pFreqData[%d]->Max is 0x%f", cnt, pFreqData[cnt].Max);
                DEBUG_INFO("the val of pFreqData[%d]->Min is 0x%f", cnt, pFreqData[cnt].Min);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl1Ave is 0x%f", cnt, pFreqData[cnt].Lvl1Ave);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl2Ave is 0x%f", cnt, pFreqData[cnt].Lvl2Ave);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl3Ave is 0x%f", cnt, pFreqData[cnt].Lvl3Ave);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl4Ave is 0x%f", cnt, pFreqData[cnt].Lvl4Ave);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl5Ave is 0x%f", cnt, pFreqData[cnt].Lvl5Ave);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl1Duty is 0x%f", cnt, pFreqData[cnt].Lvl1Duty);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl2Duty is 0x%f", cnt, pFreqData[cnt].Lvl2Duty);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl3Duty is 0x%f", cnt, pFreqData[cnt].Lvl3Duty);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl4Duty is 0x%f", cnt, pFreqData[cnt].Lvl4Duty);
                DEBUG_INFO("the val of pFreqData[%d]->Lvl5Duty is 0x%f", cnt, pFreqData[cnt].Lvl5Duty);
                DEBUG_INFO("--------------------------------------------------");
            }
            read_point += 2;
            read_point &= 0x000003FF;
            cnt++;
            if (cnt == dataSetNum)
            {
                DEBUG_INFO("the cnt is %d", cnt);
                DEBUG_INFO("the dataSetNum is %d", dataSetNum);
                break;
            }
        }
    } while (cnt < dataSetNum);
    // } while (1);

    iValue_wadr = *(unsigned *)(reg_VirthBaseAddr + DRAM_WADR_OFFSET);
    iValue_sadr = *(unsigned *)(reg_VirthBaseAddr + DRAM_SADR_OFFSET);
    iValue_block = *(unsigned *)(reg_VirthBaseAddr + DRAM_BLOCK_OFFSET);
    DEBUG_INFO("the value of WADR is 0x%08x", iValue_wadr);
    DEBUG_INFO("the value of SADR is 0x%08x", iValue_sadr);
    DEBUG_INFO("the value of BLOCK is 0x%08x", iValue_block);
    *num = (iValue_wadr - iValue_sadr) / iValue_block;
    DEBUG_INFO("the value of valid num is %d", *num);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] GetFeatureAnalysisVal

[arguments]
pFreqData			:	First address of the structure containing the frequency data
num			        :	the valid num of structure
dataSetNum			:	Number of data sets for 10 msec periodic data

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetFeatureAnalysisVal(freqData *pFreqData, int *num, int dataSetNum)
{
    /* judge the parameters */
    if (NULL == pFreqData)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    uint32_t read_point = 0;
    uint32_t write_point = 0;
    // uint32_t feature_val[10000]; // Box to store Max,Min,Lvl1-5 average (for now)
    uint32_t cnt = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    uint32_t n = 1;   // system n = 1 or 2
    uint32_t iRet = 0;
    uint32_t iValue_wadr = 0;
    uint32_t iValue_sadr = 0;
    uint32_t iValue_block = 0;
    // freqData *tempFreqData;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    // pFreqData->Max = *(unsigned *)(reg_VirthBaseAddr + MAX_OFFSET);
    do
    {
        write_point = *(unsigned *)(reg_VirthBaseAddr + RAM_COUNT_OFFSET + (vip * 0x1000));
        DEBUG_INFO("the val of write_point is 0x%8x", write_point);
        DEBUG_INFO("--------------------------------------------------")

        while ((read_point != write_point) && (read_point + 1) != write_point && (write_point % 2) == 0)
        {

            *(unsigned *)(reg_VirthBaseAddr + RAM_MON_OFFSET + (vip * 0x1000)) = read_point + (n - 1);

            DEBUG_INFO("memcpy the pFreqData");
            pFreqData[cnt].Ave = *(float *)(reg_VirthBaseAddr + AVE_OFFSET + (vip * 0x1000));       //
            pFreqData[cnt].Var = *(float *)(reg_VirthBaseAddr + VAR_OFFSET + (vip * 0x1000));       //
            pFreqData[cnt].Max = *(float *)(reg_VirthBaseAddr + MAX_OFFSET + (vip * 0x1000));       //
            pFreqData[cnt].Min = *(float *)(reg_VirthBaseAddr + MIN_OFFSET + (vip * 0x1000));       //
            pFreqData[cnt].HAve = *(float *)(reg_VirthBaseAddr + HAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HVar = *(float *)(reg_VirthBaseAddr + HVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LAve = *(float *)(reg_VirthBaseAddr + LAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LVar = *(float *)(reg_VirthBaseAddr + LVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HHAve = *(float *)(reg_VirthBaseAddr + HHAVE_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HHVar = *(float *)(reg_VirthBaseAddr + HHVAR_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HLAve = *(float *)(reg_VirthBaseAddr + HLAVE_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HLVar = *(float *)(reg_VirthBaseAddr + HLVAR_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LHAve = *(float *)(reg_VirthBaseAddr + LHAVE_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LHVar = *(float *)(reg_VirthBaseAddr + LHVAR_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LLAve = *(float *)(reg_VirthBaseAddr + LLAVE_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LLVar = *(float *)(reg_VirthBaseAddr + LLAVE_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HHHAve = *(float *)(reg_VirthBaseAddr + HHHAVE_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HHHVar = *(float *)(reg_VirthBaseAddr + HHHVAR_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HHLAve = *(float *)(reg_VirthBaseAddr + HHLAVE_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HHLVar = *(float *)(reg_VirthBaseAddr + HHLVAR_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HLHAve = *(float *)(reg_VirthBaseAddr + HLHAVE_OFFSET + (vip * 0x1000)); //

            pFreqData[cnt].HLHVar = *(float *)(reg_VirthBaseAddr + HLHVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HLLAve = *(float *)(reg_VirthBaseAddr + HLLAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HLLVar = *(float *)(reg_VirthBaseAddr + HLLVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LHHAve = *(float *)(reg_VirthBaseAddr + LHHAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LHHVar = *(float *)(reg_VirthBaseAddr + LHHVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LHLAve = *(float *)(reg_VirthBaseAddr + LHLAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LHLVar = *(float *)(reg_VirthBaseAddr + LHLVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LLHAve = *(float *)(reg_VirthBaseAddr + LLHAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LLHVar = *(float *)(reg_VirthBaseAddr + LLHVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LLLAve = *(float *)(reg_VirthBaseAddr + LLLAVE_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LLLVar = *(float *)(reg_VirthBaseAddr + LLLVAR_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HCount = *(float *)(reg_VirthBaseAddr + HCOUNT_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].LCount = *(float *)(reg_VirthBaseAddr + LCOUNT_OFFSET + (vip * 0x1000));     //
            pFreqData[cnt].HHCount = *(float *)(reg_VirthBaseAddr + HHCOUNT_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HLCount = *(float *)(reg_VirthBaseAddr + HLCOUNT_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LHCount = *(float *)(reg_VirthBaseAddr + LHCOUNT_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].LLCount = *(float *)(reg_VirthBaseAddr + LLCOUNT_OFFSET + (vip * 0x1000));   //
            pFreqData[cnt].HHHCount = *(float *)(reg_VirthBaseAddr + HHHCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HHLCount = *(float *)(reg_VirthBaseAddr + HHLCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HLHCount = *(float *)(reg_VirthBaseAddr + HLHCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].HLLCount = *(float *)(reg_VirthBaseAddr + HLLCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].LHHCount = *(float *)(reg_VirthBaseAddr + LHHCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].LHLCount = *(float *)(reg_VirthBaseAddr + LHLCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].LLHCount = *(float *)(reg_VirthBaseAddr + LLHCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].LLLCount = *(float *)(reg_VirthBaseAddr + LLLCOUNT_OFFSET + (vip * 0x1000)); //
            pFreqData[cnt].Lvl1Ave = *(float *)(reg_VirthBaseAddr + LVL1AVE_OFFSET + (vip * 0x1000));     // Lv1 average set
            pFreqData[cnt].Lvl1Var = *(float *)(reg_VirthBaseAddr + LVL1VAR_OFFSET + (vip * 0x1000));     // Lv1 Var set
            pFreqData[cnt].Lvl2Ave = *(float *)(reg_VirthBaseAddr + LVL2AVE_OFFSET + (vip * 0x1000));     // Lv2 average set
            pFreqData[cnt].Lvl2Var = *(float *)(reg_VirthBaseAddr + LVL2VAR_OFFSET + (vip * 0x1000));     // Lv2 Var set
            pFreqData[cnt].Lvl3Ave = *(float *)(reg_VirthBaseAddr + LVL3AVE_OFFSET + (vip * 0x1000));     // Lv3 average set
            pFreqData[cnt].Lvl3Var = *(float *)(reg_VirthBaseAddr + LVL3VAR_OFFSET + (vip * 0x1000));     // Lv3 Var set
            pFreqData[cnt].Lvl4Ave = *(float *)(reg_VirthBaseAddr + LVL4AVE_OFFSET + (vip * 0x1000));     // Lv4 average set
            pFreqData[cnt].Lvl4Var = *(float *)(reg_VirthBaseAddr + LVL4VAR_OFFSET + (vip * 0x1000));     // Lv4 Var set
            pFreqData[cnt].Lvl5Ave = *(float *)(reg_VirthBaseAddr + LVL5AVE_OFFSET + (vip * 0x1000));     // Lv5 average set
            pFreqData[cnt].Lvl5Var = *(float *)(reg_VirthBaseAddr + LVL5VAR_OFFSET + (vip * 0x1000));     // Lv5 Var set
            pFreqData[cnt].Lvl1Count = *(float *)(reg_VirthBaseAddr + LVL1COUNT_OFFSET + (vip * 0x1000)); // Lv1 count set
            pFreqData[cnt].Lvl2Count = *(float *)(reg_VirthBaseAddr + LVL2COUNT_OFFSET + (vip * 0x1000)); // Lv2 count set
            pFreqData[cnt].Lvl3Count = *(float *)(reg_VirthBaseAddr + LVL3COUNT_OFFSET + (vip * 0x1000)); // Lv3 count set
            pFreqData[cnt].Lvl4Count = *(float *)(reg_VirthBaseAddr + LVL4COUNT_OFFSET + (vip * 0x1000)); // Lv4 count set
            pFreqData[cnt].Lvl5Count = *(float *)(reg_VirthBaseAddr + LVL5COUNT_OFFSET + (vip * 0x1000)); // Lv5 count set
            pFreqData[cnt].LvlCount = *(float *)(reg_VirthBaseAddr + LVLCOUNT_OFFSET + (vip * 0x1000));   // Lv count set
            pFreqData[cnt].Lvl1Duty = *(float *)(reg_VirthBaseAddr + LVL1DUTY_OFFSET + (vip * 0x1000));   // Lv1 Duty set
            pFreqData[cnt].Lvl2Duty = *(float *)(reg_VirthBaseAddr + LVL2DUTY_OFFSET + (vip * 0x1000));   // Lv2 Duty set
            pFreqData[cnt].Lvl3Duty = *(float *)(reg_VirthBaseAddr + LVL3DUTY_OFFSET + (vip * 0x1000));   // Lv3 Duty set
            pFreqData[cnt].Lvl4Duty = *(float *)(reg_VirthBaseAddr + LVL4DUTY_OFFSET + (vip * 0x1000));   // Lv4 Duty set
            pFreqData[cnt].Lvl5Duty = *(float *)(reg_VirthBaseAddr + LVL5DUTY_OFFSET + (vip * 0x1000));   // Lv5 Duty set

            // DEBUG_INFO("the pFreqData[%d] is %f", cnt, pFreqData[cnt].LHLVar);
            // DEBUG_INFO("the pFreqData[%d] is %f", cnt, pFreqData[cnt].LHLVar);

            read_point += 2;
            read_point &= 0x000003FF;
            cnt++;
            // memset(tempFreqData, 0, sizeof(freqData));
            if (cnt == dataSetNum)
            {
                DEBUG_INFO("the cnt is %d", cnt);
                DEBUG_INFO("the dataSetNum is %d", dataSetNum);
                break;
            }
        }
    } while (cnt < dataSetNum);

    iValue_wadr = *(unsigned *)(reg_VirthBaseAddr + DRAM_WADR_OFFSET);
    iValue_sadr = *(unsigned *)(reg_VirthBaseAddr + DRAM_SADR_OFFSET);
    iValue_block = *(unsigned *)(reg_VirthBaseAddr + DRAM_BLOCK_OFFSET);
    DEBUG_INFO("the value of WADR is 0x%08x", iValue_wadr);
    DEBUG_INFO("the value of SADR is 0x%08x", iValue_sadr);
    DEBUG_INFO("the value of BLOCK is 0x%08x", iValue_block);
    *num = (iValue_wadr - iValue_sadr) / iValue_block;
    DEBUG_INFO("the value of valid num is %d", *num);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetRfFreqMode

[arguments]
mode			    :	Mode number to be specified


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetRfFreqMode(int mode)
{
    /* judge the parameters */
    DEBUG_INFO("the mode is %d", mode);
    if ((MODE_NUM1 != mode) && (MODE_NUM2 != mode) && (MODE_NUM3 != mode) && (MODE_NUM4 != mode))
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    DEBUG_INFO("start to set");
    iRet = EepromWrite(0x08, 0x04, &mode);
    return iRet;
}

/*********************************************************************************
[function name] GetRfFreqMode

[arguments]
mode			    :	Mode number to be specified


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetRfFreqMode(int *mode)
{
    /* judge the parameters */
    if (NULL == mode)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int32_t iRet = 0;
    iRet = EepromRead(0x08, 0x04, mode);

    return iRet;
}

float HexToFloat(uint32_t data)
{
    float result = 0;
    memcpy(&result, &data, sizeof(float));
    DEBUG_INFO("result = %f\n", result);
    return result;
}
/*********************************************************************************
[function name] FeatureAnalysisEnable

[arguments]
None

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int FeatureRegInit(WaferLevelCalcCoefficient *wLevelCoff, FeatureAnalysisParameter *featureParam, struct BoardSerialParam *boardSerialParam)
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    unsigned long long reg_VirthBaseAddr;

    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    SetRegister(reg_VirthBaseAddr, 0x0000, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x1420, 0x3b360b61);
    SetRegister(reg_VirthBaseAddr, 0x2420, 0x3b360b61);
    SetRegister(reg_VirthBaseAddr, 0x3420, 0x3b360b61);
    SetRegister(reg_VirthBaseAddr, 0x5420, 0x3b360b61);
    SetRegister(reg_VirthBaseAddr, 0x6420, 0x3b360b61);
    SetRegister(reg_VirthBaseAddr, 0x7420, 0x3b360b61);
    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);

    SetWlevelCalcCoeff(wLevelCoff, 0);
    SetWlevelCalcCoeff(wLevelCoff, 1);

    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    SetRegister(reg_VirthBaseAddr, 0x0080, 0x00000032);
    SetRegister(reg_VirthBaseAddr, 0x0084, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x0088, 0x00004E20);
    SetRegister(reg_VirthBaseAddr, 0x008c, 0x000000c8);
    SetRegister(reg_VirthBaseAddr, 0x0090, 0x00000003);
    SetRegister(reg_VirthBaseAddr, 0x1440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x2440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x3440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x5440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x6440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x7440, 0x00008000);
    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);

    SetFeatureAnalysisParameter(featureParam, 1);
    SetFeatureAnalysisParameter(featureParam, 0);

    SetBoardSerialparameter(boardSerialParam, 0);
    SetBoardSerialparameter(boardSerialParam, 1);

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    SetRegister(reg_VirthBaseAddr, 0x1500, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x2500, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x3500, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x1500, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x2500, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x3500, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x007c, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x0198, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x019c, 0x00000000);
    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);

    return NO_ERROR;
}
int FeatureAnalysisEnable()
{
    uint32_t iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    SetRegister(reg_VirthBaseAddr, 0x0000, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x1508, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x2508, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x3508, 0x00000000);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);

    usleep(1000000);
    return NO_ERROR;
}

/*********************************************************************************
[function name] FeatureAnalysisDisable

[arguments]
None

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int FeatureAnalysisDisable()
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *(unsigned *)(reg_VirthBaseAddr + EIGEN_DETECT_START) = 0;
    // iValue = *(unsigned *)(reg_VirthBaseAddr + EIGEN_DETECT_START);
    // DEBUG_INFO("the value of 0x%08x = %d", (BASE_ADDRESS + EIGEN_DETECT_START), *(unsigned *)(reg_VirthBaseAddr + EIGEN_DETECT_START));

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetFeatureAnalysisParameter

[arguments]
faParam             :	First address of the structure containing the feature parameter data
ch                  :   Target Ch.

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetFeatureAnalysisParameter(FeatureAnalysisParameter *faParam, int ch)
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    if (NULL == faParam)
    {
        printf("the parameters is NULL\n");
        return PARAM_ERROR;
    }
    if ((ch != 0) && (ch != 1))
    {
        printf("the ch is out of range\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    for (vip = 1; vip <= 3; vip++)
    {
        *(unsigned *)(reg_VirthBaseAddr + AVARAGE_OFFSET + (vip * 0x1000) + (ch * 0x4000)) = faParam->movingAverage_Count;
        memcpy((void *)(reg_VirthBaseAddr + COUNTMINIMUM_OFFSET + (vip * 0x1000) + (ch * 0x4000)), &faParam->transitionJudge_LowLimitCount, sizeof(FeatureAnalysisParameter) - sizeof(int));
    }

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] GetFeatureAnalysisParameter

[arguments]
faParam             :	First address of the structure containing the feature parameter data
ch                  :   Target Ch.

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetFeatureAnalysisParameter(FeatureAnalysisParameter *faParam, int ch)
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    if (NULL == faParam)
    {
        printf("the parameters is NULL\n");
        return PARAM_ERROR;
    }
    if ((ch != 0) && (ch != 1))
    {
        printf("the ch is out of range\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    // memcpy(reg_VirthBaseAddr+COUNTMINIMUM_OFFSET, faParam, sizeof(FeatureAnalysisParameter));
    memcpy(&faParam->transitionJudge_LowLimitCount, (void *)(reg_VirthBaseAddr + COUNTMINIMUM_OFFSET + (vip * 0x1000) + (ch * 0x4000)), sizeof(FeatureAnalysisParameter) - sizeof(int));
    faParam->movingAverage_Count = *(unsigned *)(reg_VirthBaseAddr + AVARAGE_OFFSET + (vip * 0x1000) + (ch * 0x4000));
    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetDownSamplingMode

[arguments]
thinningNum         :	Thinning number (specify denominator)

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetDownSamplingMode(int thinningNum)
{
    /* judge the parameters */
    if ((MIN_THINING_NUM > thinningNum) || (MAX_THINING_NUM < thinningNum))
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;
    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *((unsigned *)(reg_VirthBaseAddr + DOWN_SAMPLING_OFFSET)) = thinningNum;

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] GetDownSamplingMode

[arguments]
thinningNum         :	Thinning number (specify denominator)

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetDownSamplingMode(int *thinningNum)
{
    /* judge the parameters */
    if (NULL == thinningNum)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *thinningNum = *(unsigned *)(reg_VirthBaseAddr + DOWN_SAMPLING_OFFSET);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetUpSamplingMode

[arguments]
interpolationNum      :	    Supplementary room

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetUpSamplingMode(int interpolationNum)
{
    DEBUG_INFO("the interpolationNum = %d", interpolationNum);
    /* judge the parameters */
    if ((MIN_INTERPOL_NUM > interpolationNum) || (MAX_INTERPOL_NUM < interpolationNum))
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *((unsigned *)(reg_VirthBaseAddr + UPSAMPLING_OFFSET)) = interpolationNum;

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetUpSamplingMode

[arguments]
interpolationNum      :	    Supplementary room

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetUpSamplingMode(int *interpolationNum)
{
    /* judge the parameters */
    if (NULL == interpolationNum)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *interpolationNum = *(unsigned *)(reg_VirthBaseAddr + UPSAMPLING_OFFSET);
    DEBUG_INFO("the interpolationNum = %d", *interpolationNum);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetMaxDataSetMode

[arguments]
maxDataSet            :	    the max num of data sets

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetMaxDataSetMode(int maxDataSet)
{
    /* judge the parameters */
    if (0 >= maxDataSet)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *((unsigned *)(reg_VirthBaseAddr + SAMPLING_COUNT_OFFSET)) = maxDataSet;
    *((unsigned *)(reg_VirthBaseAddr + DRAM_BLOCK_OFFSET)) = 0x80000;

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] GetMaxDataSetMode

[arguments]
maxDataSet            :	    the max num of data sets

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetMaxDataSetMode(int *maxDataSet)
{
    /* judge the parameters */
    if (NULL == maxDataSet)
    {
        printf("parameters error\n");
        return PARAM_ERROR;
    }
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    *maxDataSet = *(unsigned *)(reg_VirthBaseAddr + SAMPLING_COUNT_OFFSET);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

int SetWlevelCalcCoeff(WaferLevelCalcCoefficient *wLevelCoff, int ch)
{
    int iRet = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    if (NULL == wLevelCoff)
    {
        printf("the wLevelCoff is NULL\n");
        return PARAM_ERROR;
    }
    if ((ch != 0) && (ch != 1))
    {
        printf("the ch is out of range\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

#if DEBUG
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_1raw);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_1clm);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_2raw);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_2clm);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_3raw);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_3clm);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_4raw);
    DEBUG_INFO("wLevelCoff.matrix_1raw = %f", wLevelCoff->matrix_4clm);

#endif
    for (vip = 1; vip <= 3; vip++)
    {
        memcpy((void *)(reg_VirthBaseAddr + WLEVEL_OFFSET + (vip * 0x1000) + (ch * 0x4000)), wLevelCoff, sizeof(WaferLevelCalcCoefficient));
    }

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

int GetWlevelCalcCoeff(WaferLevelCalcCoefficient *wLevelCoff, int ch)
{
    int iRet = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    if (NULL == wLevelCoff)
    {
        printf("the wLevelCoff is NULL\n");
        return PARAM_ERROR;
    }
    if ((ch != 0) && (ch != 1))
    {
        printf("the ch is out of range\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    memcpy(wLevelCoff, (float *)(reg_VirthBaseAddr + WLEVEL_OFFSET + (vip * 0x1000) + (ch * 0x4000)), sizeof(WaferLevelCalcCoefficient));
    // wLevelCoff = (WaferLevelCalcCoefficient *)(reg_VirthBaseAddr + WLEVEL_OFFSET + (vip * 0x1000));
    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

int StartSelfCalibration()
{
    return NO_ERROR;
}

int GetSelfCalibrationResult()
{
    return NO_ERROR;
}

int SetSelfCalibrationTable()
{
    return NO_ERROR;
}

int GetSelfCalibrationTable()
{
    return NO_ERROR;
}

// int SetTempCompensationParam(const struct TemperatureCompensationParam *tempCompParam)
// {
// }

// int GetTempCompensationParam(const struct TemperatureCompensationParam *tempCompParam)
// {
// }

int NotifyTempCompensation(int temp)
{
    const float coff_1st = 8; // Tilt (read in advance from EEPROM)
    // float constant;     // Intercept
    float gain_float;   // Gain value (float)
    int iRet = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    DEBUG_INFO("calculate the gain_float");
    gain_float = 1 + coff_1st * ((float)(temp - 2500) / 100.0);
    DEBUG_INFO("the gain_float is %f", gain_float);
    *(unsigned *)(reg_VirthBaseAddr + TMP_GAIN_OFFSET + (vip * 0x1000)) = (int)(gain_float * 32768);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}