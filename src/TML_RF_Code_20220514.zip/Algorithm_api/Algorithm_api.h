/*******************************************************************************
**	File name		: Algorithm_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __ALGORITHM_API_H__
#define __ALGORITHM_API_H__

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include "Parameter_api.h"
#include "DataStrage_api.h"

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define BASE_ADDRESS 0x80000000
#define MODE_REG_SIZE 0x7FFF
#define MODE_REG_OFFSET 2
#define MODE_NUM1 1
#define MODE_NUM2 2
#define MODE_NUM3 3
#define MODE_NUM4 4
#define MIN_THINING_NUM 1
#define MAX_THINING_NUM 5000
#define DOWN_SAMPLING_OFFSET 0x0080
#define MIN_INTERPOL_NUM 0
#define MAX_INTERPOL_NUM 10
#define UPSAMPLING_OFFSET 0x0084
#define SAMPLING_COUNT_OFFSET 0x0088
#define EIGEN_DETECT_START 0x0000
#define DRAM_SADR_OFFSET 0x0180
#define DRAM_BLOCK_OFFSET 0x0188
#define DRAM_WADR_OFFSET 0x018C
#define RAM_COUNT_OFFSET 0x504
#define RAM_MON_OFFSET 0x508
#define TMP_GAIN_OFFSET 0x440
#define WLEVEL_OFFSET 0x400

#define AVE_OFFSET 0x600
#define VAR_OFFSET 0x604
#define MAX_OFFSET 0x608
#define MIN_OFFSET 0x60C
#define HAVE_OFFSET 0x610
#define HVAR_OFFSET 0x614
#define LAVE_OFFSET 0x618
#define LVAR_OFFSET 0x61C
#define HHAVE_OFFSET 0x620
#define HHVAR_OFFSET 0x624
#define HLAVE_OFFSET 0x628
#define HLVAR_OFFSET 0x62C
#define LHAVE_OFFSET 0x630
#define LHVAR_OFFSET 0x634
#define LLAVE_OFFSET 0x638
#define LLVAR_OFFSET 0x63C
#define HHHAVE_OFFSET 0x640
#define HHHVAR_OFFSET 0x644
#define HHLAVE_OFFSET 0x648
#define HHLVAR_OFFSET 0x64C
#define HLHAVE_OFFSET 0x650
#define HLHVAR_OFFSET 0x654
#define HLLAVE_OFFSET 0x658
#define HLLVAR_OFFSET 0x65C
#define LHHAVE_OFFSET 0x660
#define LHHVAR_OFFSET 0x664
#define LHLAVE_OFFSET 0x668
#define LHLVAR_OFFSET 0x66C
#define LLHAVE_OFFSET 0x670
#define LLHVAR_OFFSET 0x674
#define LLLAVE_OFFSET 0x678
#define LLLVAR_OFFSET 0x67C
#define HCOUNT_OFFSET 0x680
#define LCOUNT_OFFSET 0x684
#define HHCOUNT_OFFSET 0x688
#define HLCOUNT_OFFSET 0x68C
#define LHCOUNT_OFFSET 0x690
#define LLCOUNT_OFFSET 0x694
#define HHHCOUNT_OFFSET 0x698
#define HHLCOUNT_OFFSET 0x69C
#define HLHCOUNT_OFFSET 0x6A0
#define HLLCOUNT_OFFSET 0x6A4
#define LHHCOUNT_OFFSET 0x6A8
#define LHLCOUNT_OFFSET 0x6AC
#define LLHCOUNT_OFFSET 0x6B0
#define LLLCOUNT_OFFSET 0x6B4
#define LVL1AVE_OFFSET 0x700
#define LVL1VAR_OFFSET 0x704
#define LVL2AVE_OFFSET 0x708
#define LVL2VAR_OFFSET 0x70C
#define LVL3AVE_OFFSET 0x710
#define LVL3VAR_OFFSET 0x714
#define LVL4AVE_OFFSET 0x718
#define LVL4VAR_OFFSET 0x71C
#define LVL5AVE_OFFSET 0x720
#define LVL5VAR_OFFSET 0x724
#define LVL1COUNT_OFFSET 0x728
#define LVL2COUNT_OFFSET 0x72C
#define LVL3COUNT_OFFSET 0x730
#define LVL4COUNT_OFFSET 0x734
#define LVL5COUNT_OFFSET 0x738
#define LVLCOUNT_OFFSET 0x73C
#define LVL1DUTY_OFFSET 0x740
#define LVL2DUTY_OFFSET 0x744
#define LVL3DUTY_OFFSET 0x748
#define LVL4DUTY_OFFSET 0x74C
#define LVL5DUTY_OFFSET 0x750
#define COUNTMINIMUM_OFFSET 0x480
#define AVARAGE_OFFSET 0x424
// #define
#define FEATURE_REG_SIZE 0x800
#define FEATURE_V_BASE_ADDR 0x80001000

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct
{
    float Ave;
    float Var;
    float Max;
    float Min;
    float HAve;
    float HVar;
    float LAve;
    float LVar;
    float HHAve;
    float HHVar;
    float HLAve;
    float HLVar;
    float LHAve;
    float LHVar;
    float LLAve;
    float LLVar;
    float HHHAve;
    float HHHVar;
    float HHLAve;
    float HHLVar;
    float HLHAve;
    float HLHVar;
    float HLLAve;
    float HLLVar;
    float LHHAve;
    float LHHVar;
    float LHLAve;
    float LHLVar;
    float LLHAve;
    float LLHVar;
    float LLLAve;
    float LLLVar;
    float HCount;
    float LCount;
    float HHCount;
    float HLCount;
    float LHCount;
    float LLCount;
    float HHHCount;
    float HHLCount;
    float HLHCount;
    float HLLCount;
    float LHHCount;
    float LHLCount;
    float LLHCount;
    float LLLCount;
    float Lvl1Ave;
    float Lvl1Var;
    float Lvl2Ave;
    float Lvl2Var;
    float Lvl3Ave;
    float Lvl3Var;
    float Lvl4Ave;
    float Lvl4Var;
    float Lvl5Ave;
    float Lvl5Var;
    float Lvl1Count;
    float Lvl2Count;
    float Lvl3Count;
    float Lvl4Count;
    float Lvl5Count;
    float LvlCount;
    float Lvl1Duty;
    float Lvl2Duty;
    float Lvl3Duty;
    float Lvl4Duty;
    float Lvl5Duty;
} freqData;

typedef struct // Specify for each channel of the VI sensor
{
    int movingAverage_Count;             // Moving average Number of moving averages
    int transitionJudge_LowLimitCount;   // Transient judgment Lower limit of the number of data
    float transitionJudge_LowLimitSigma; // Transition determination σ lower limit
    float transitionJudge_UpperLimitCv;  // Transition determination Upper limit CV
    float transitionJudge_LowLimitDuty;
    float transitionJudge_SigmaDiffCofficient;
    float aggregationJudge_Sigma;
    float aggregationJudge_DiffPercentage;
    float aggregationJudge_DiffVoltage;
    float aggregationWeights_CvThreshold;
    float aggregationWeights_LowLimit;
} FeatureAnalysisParameter;


typedef struct 
{
    float matrix_1raw; // A real num
    float matrix_1clm; // A virtual num
    float matrix_2raw; // B real num
    float matrix_2clm; // B virtual num
    float matrix_3raw; // C real num
    float matrix_3clm; // C virtual num
    float matrix_4raw; // D real num
    float matrix_4clm; // D virtual num
}WaferLevelCalcCoefficient;

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int GetFeatureVal(freqData *pFreqData, int *num, int dataSetNum);
extern int GetFeatureAnalysisVal(freqData *pFreqData, int *num, int dataSetNum);
extern int SetRfFreqMode(int mode);
extern int GetRfFreqMode(int *mode);
extern float HexToFloat(uint32_t data);
extern int FeatureRegInit(WaferLevelCalcCoefficient *wLevelCoff, FeatureAnalysisParameter *featureParam, struct BoardSerialParam *boardSerialParam);
extern int FeatureAnalysisEnable();
extern int FeatureAnalysisDisable();
extern int SetFeatureAnalysisParameter(FeatureAnalysisParameter *faParam, int ch);
extern int GetFeatureAnalysisParameter(FeatureAnalysisParameter *faParam, int ch);
extern int SetDownSamplingMode(int thinningNum);
extern int GetDownSamplingMode(int *thinningNum);
extern int SetUpSamplingMode(int interpolationNum);
extern int GetUpSamplingMode(int *interpolationNum);
extern int SetMaxDataSetMode(int maxDataSet);
extern int GetMaxDataSetMode(int *maxDataSet);
extern int SetWlevelCalcCoeff(WaferLevelCalcCoefficient *wLevelCoff, int ch);
extern int GetWlevelCalcCoeff(WaferLevelCalcCoefficient *wLevelCoff, int ch);
extern int NotifyTempCompensation(int temp);

#endif