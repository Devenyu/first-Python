/*******************************************************************************
**	File name		: dio_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __DIO_API_H__ 
#define __DIO_API_H__

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define GPIO_DI_BASE 356
#define GPIO_DO_BASE 364
#define GPIO_DI0 356
#define GPIO_DI1 357
#define GPIO_DI2 362
#define GPIO_DI3 363
#define GPIO_DO0 364
#define GPIO_DO1 365
#define GPIO_DO2 366
#define GPIO_DO3 367
#define GPIO_DIR_IN 0
#define GPIO_DIR_OUT 1
#define FALSE 0
#define TRUE 1

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int DioInit(void);
extern int DioGetDi(int diid, unsigned char *val);
extern int DioSetDi(int diid, unsigned char val);
extern int DioGetDo(int doid, unsigned char *val);
extern int DioSetDo(int doid, unsigned char val);

#endif /* __DIO_API_H__ */