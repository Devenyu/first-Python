/*******************************************************************************
**	File name		: gpio.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include "gpio.h"
#include "Err32_def_api.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <poll.h>
#include <errno.h>
#include <unistd.h>


/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] gpio_export

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_export(unsigned int uiGPIO_number)
{
	int fd, len;
	char cBuf[MAX_BUF];

	fd = open("/sys/class/gpio/export",O_WRONLY);
	if(fd < 0)
	{
		printf("[error]gpio/export error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}

	//snprintf function: covert uiGPIO_number to cBuf , size = sizeof(cBuf)-1
	len = snprintf(cBuf, sizeof(cBuf), "%d", uiGPIO_number);

	write(fd, cBuf, len);
	close(fd);

	return NO_ERROR;
}

/*********************************************************************************
[function name] gpio_unexport

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_unexport(unsigned int uiGPIO_number)
{
	int fd,len;
	char cBuf[MAX_BUF];

	fd = open("/sys/class/gpio/unexport",O_WRONLY);
	if(fd < 0)
	{
		printf("[error]gpio/unexport error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}

	len = snprintf(cBuf, sizeof(cBuf), "%d", uiGPIO_number);

	write(fd, cBuf, len);
	close(fd);
	return NO_ERROR;
}

/*********************************************************************************
[function name] gpio_set_dir

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1
uiOutFlag				  : 	0: GPIO input; 1: GPIO output

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_set_dir(unsigned int uiGPIO_number, unsigned int uiOutFlag)
{
	int fd;
	char cBuf[MAX_BUF];

	snprintf(cBuf, sizeof(cBuf), "/sys/class/gpio/gpio%d/direction", uiGPIO_number);

	fd = open(cBuf, O_WRONLY);
	if(fd < 0)
	{
		printf("[error]gpio/direction error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}

	if(uiOutFlag)
	{
		write(fd, "out", 4);
	}
	else
	{
		write(fd, "in", 3);
	}

	close(fd);
	return NO_ERROR;
}

/*********************************************************************************
[function name] gpio_set_value

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1
uiValue					  : 	0: Low voltage; 1: High voltage

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_set_value(unsigned int uiGPIO_number, unsigned char uiValue)
{
	int fd;
	char cBuf[MAX_BUF];

	snprintf(cBuf, sizeof(cBuf), "/sys/class/gpio/gpio%d/value", uiGPIO_number);

	fd = open(cBuf, O_WRONLY);
	if(fd < 0)
	{
		printf("[error]gpio/set-value error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}

	write(fd, &uiValue, 1);
	// if(uiValue)
	// {
	// 	write(fd, "1", 2);
	// }
	// else
	// {
	// 	write(fd, "0", 2);
	// }
	close(fd);
	return NO_ERROR;
}

/*********************************************************************************
[function name] gpio_get_value

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1
puchValue				  : 	The value read

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_get_value(unsigned int uiGPIO_number, unsigned char *puchValue)
{
	int fd;
	char cBuf[MAX_BUF];
	unsigned char cReadValue;

	snprintf(cBuf, sizeof(cBuf), "/sys/class/gpio/gpio%d/value", uiGPIO_number);

	fd = open(cBuf, O_RDONLY);
	if(fd < 0)
	{
		printf("[error]gpio/get-value error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}

	read(fd, &cReadValue, 1);

	if(cReadValue != '0')
	{
		*puchValue = (unsigned char)1;
	}
	else
	{
		*puchValue = (unsigned char)0;
	}

	close(fd);
	return NO_ERROR;
}

/*********************************************************************************
[function name] gpio_set_edge

[arguments]
uiGPIO_number			  :		the number of GPIO, such as 0,1
cEdge					  : 	"rising" :  signal rising trigger;
						 	    "falling":  signal falling trigger
[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int gpio_set_edge(unsigned int uiGPIO_number, char *cEdge)
{
	int fd;
	char buf[MAX_BUF];

	snprintf(buf,sizeof(buf), "/sys/class/gpio/gpio%d/edge", uiGPIO_number);

	//Open GPIO edge file
	fd = open(buf,O_WRONLY);
	if(fd < 0)
	{
		printf("[error]gpio/set-edge error.CODE %d\n", uiGPIO_number);
		return GENERAL_ERROR;
	}
	//Set trigger type
	write(fd, cEdge, strlen(cEdge) + 1);
	close(fd);
	return NO_ERROR;
}
