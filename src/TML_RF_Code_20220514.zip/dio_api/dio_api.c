/*******************************************************************************
**	File name		: dio_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>

#include "gpio.h"
#include "Err32_def_api.h"
#include "dio_api.h"
#include "common.h"

_Bool DIO_Init_Flag = FALSE;
/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] DioInit

[arguments]
 NULL


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DioInit(void)
{
    int iRet1, iRet2, iRet3, iRet4, iRet5, iRet6, iRet7, iRet8;
    iRet1 = gpio_export(GPIO_DI0); /* export the gpio1 */
    iRet2 = gpio_export(GPIO_DI1); /* export the gpio2 */
    iRet3 = gpio_export(GPIO_DI2); /* export the gpio3 */
    iRet4 = gpio_export(GPIO_DI3);
    iRet5 = gpio_export(GPIO_DO0);
    iRet6 = gpio_export(GPIO_DO1);
    iRet7 = gpio_export(GPIO_DO2);
    iRet8 = gpio_export(GPIO_DO3);

    gpio_set_dir(GPIO_DI0, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DI1, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DI2, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DI3, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DO0, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DO1, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DO2, GPIO_DIR_OUT); /* set the direction of gpio */
    gpio_set_dir(GPIO_DO3, GPIO_DIR_OUT); /* set the direction of gpio */

    if ((GENERAL_ERROR == iRet1) || (GENERAL_ERROR == iRet2) || (GENERAL_ERROR == iRet3) || (GENERAL_ERROR == iRet4) || (GENERAL_ERROR == iRet5) || (GENERAL_ERROR == iRet6) || (GENERAL_ERROR == iRet7) || (GENERAL_ERROR == iRet8))
    {
        return GENERAL_ERROR;
    }

    DIO_Init_Flag = TRUE; 

    return NO_ERROR;
}

/*********************************************************************************
[function name] DioGetDi

[arguments]
diid			    :	the id of the di
val     			:	the value of the di


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DioGetDi(int diid, unsigned char *val)
{
    int gpio_di_id;
    if(FALSE == DIO_Init_Flag)
    {
        printf("please init the dio firstly\n");
        return GENERAL_ERROR;
    }
    if((0 != diid) && (1 != diid) && (2 != diid) && (3 != diid))
    {
        printf("the number of di is error\n");
        return PARAM_ERROR;
    }
    if(NULL == val)
    {
        printf("the val is NULL\n");
        return PARAM_ERROR;
    }
    if(2 > diid)
    {
        gpio_di_id = GPIO_DI_BASE + diid;
    }
    else
    {
        gpio_di_id = GPIO_DI_BASE + diid + 4;
    }
    DEBUG_INFO("gpio_di_id = %d\n", gpio_di_id);
    gpio_get_value(gpio_di_id, val); /* get the value of gpio */
    return NO_ERROR;
}

/*********************************************************************************
[function name] DioSetDi

[arguments]
diid			    :	the id of the di
val     			:	the value which is going to set


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DioSetDi(int diid, unsigned char val)
{
    int gpio_di_id;
    if(FALSE == DIO_Init_Flag)
    {
        printf("please init the dio firstly\n");
        return GENERAL_ERROR;
    }
    if((0 != diid) && (1 != diid) && (2 != diid) && (3 != diid))
    {
        printf("the number of di is error\n");
        return PARAM_ERROR;
    }
    if((0 != val)&&(1 != val))
    {
        printf("the value is out of range\n");
        return PARAM_ERROR;
    }
    if(1 >= diid)
    {
        gpio_di_id = GPIO_DI_BASE + diid;
    }
    else
    {
        gpio_di_id = GPIO_DI_BASE + diid + 4;
    }
    DEBUG_INFO("gpio_di_id = %d\n", gpio_di_id);
    gpio_set_value(gpio_di_id, val); /* set the value of gpio */
    return NO_ERROR;
}

/*********************************************************************************
[function name] DioGetDo

[arguments]
diid			    :	the id of the do
val     			:	the value of the do


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DioGetDo(int doid, unsigned char *val)
{
    int gpio_do_id;
    if(FALSE == DIO_Init_Flag)
    {
        printf("please init the dio firstly\n");
        return GENERAL_ERROR;
    }
    if((0 != doid) && (1 != doid) && (2 != doid) && (3 != doid))
    {
        printf("the number of do is error\n");
        return PARAM_ERROR;
    }
    if(NULL == val)
    {
        printf("the val is NULL\n");
        return PARAM_ERROR;
    }
    gpio_do_id = GPIO_DO_BASE + doid;
    DEBUG_INFO("gpio_do_id = %d\n", gpio_do_id);
    gpio_get_value(gpio_do_id, val); /* get the value of gpio */
    return NO_ERROR;
}

/*********************************************************************************
[function name] DioSetDo

[arguments]
diid			    :	the id of the do
val     			:	the value which is going to set


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DioSetDo(int doid, unsigned char val)
{
    int gpio_do_id;
    if(FALSE == DIO_Init_Flag)
    {
        printf("please init the dio firstly\n");
        return GENERAL_ERROR;
    }
    if((0 != doid) && (1 != doid) && (2 != doid) && (3 != doid))
    {
        printf("the number of do is error\n");
        return PARAM_ERROR;
    }
    if((0 != val)&&(1 != val))
    {
        printf("the value is out of range\n");
        return PARAM_ERROR;
    }
    gpio_do_id = GPIO_DO_BASE + doid;
    DEBUG_INFO("gpio_do_id = %d\n", gpio_do_id);
    gpio_set_value(gpio_do_id, val); /* set the value of gpio */
    return NO_ERROR;
}