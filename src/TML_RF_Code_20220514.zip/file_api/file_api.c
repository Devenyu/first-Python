/*******************************************************************************
**	File name		: file_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/

#include "file_api.h"
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/*------------------------------------------------------------------------------
                              static variables
------------------------------------------------------------------------------*/
struct FILE_ST fileContent;
int32_t s_Apilnit;             // Initialization flag (0:uninitialized, 1:initialized)
int32_t s_MaxFileNo;           // Maximum number of files to be handled simultaneously by this API
struct TFD_ALL_t *s_pFileInfo; // Top address of all File management information
struct timespec req;

/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/

/*********************************************************************************
[function name] t_file_api_init

[arguments]
files			:	Maximum number of files to be handled simultaneously by this API



[return value]
Normal	:	NO_ERROR
Initialized : FILE_INIT_ERROR
Parameter error : PARAM_ERROR
Malloc error : MALLOC_ERROR

*********************************************************************************/
int32_t t_file_api_init(int32_t files)
{

    if (0 != s_Apilnit)
    {
        printf("file api init error\n");
        return FILE_INIT_ERROR;
    }

    if (1 > files)
    {
        printf("the num of file is not in range\n");
        return PARAM_ERROR;
    }

    s_pFileInfo = (struct TFD_ALL_t *)malloc(files * sizeof(struct TFD_ALL_t));
    

    /* judge whether malloc successfully */
    if (NULL == s_pFileInfo)
    {
        printf("fail to malloc\n");
        return MALLOC_ERROR;
    }
    memset(s_pFileInfo, 0, files * sizeof(struct TFD_ALL_t));

    DEBUG_INFO("start to spin init");
    for (int i = 0; i < files; i++)
    {
        pthread_spin_init(&s_pFileInfo[i].exclusion.spin, PTHREAD_PROCESS_PRIVATE);
    }
    DEBUG_INFO("finish spin init");

    s_Apilnit = 1;
    s_MaxFileNo = files;

    return NO_ERROR;
}

/*********************************************************************************
[function name] GetCubeLock

[arguments]
FileInfo			:	File information pointer
idx                 :   Cube-lock number

[return value]
Normal	:	First address of this cube lock

*********************************************************************************/
struct T_FIO_REQ_CMD *GetCubeLock(struct TFD_ALL_t *FileInfo, int32_t idx)
{
    uint8_t *ptr = FileInfo->QueBlock.que_ptr;
    size_t size = FileInfo->QueBlock.que_size;
    struct T_FIO_REQ_CMD *ret;

    if (NULL == FileInfo)
    {
        DEBUG_INFO("the FileInfo is NULL");
    }

    ret = (struct T_FIO_REQ_CMD *)(ptr + (size * idx));

    return ret;
}

/*********************************************************************************
[function name] ExclusiveLock

[arguments]
spin			:	Spin locks for threads

[return value]
NONE

*********************************************************************************/
void ExclusiveLock(pthread_spinlock_t *spin)
{
    int ret = 0;
    do
    {
        ret = pthread_spin_trylock(spin);
        if (0 != ret)
        {
            req.tv_nsec = 10000;
            nanosleep(&req, NULL);
        }
    } while (0 != ret);
}

/*********************************************************************************
[function name] ExclusiveUnLock

[arguments]
spin			:	Spin locks for threads

[return value]
NONE

*********************************************************************************/
void ExclusiveUnLock(pthread_spinlock_t *spin)
{
    pthread_spin_unlock(spin);
}

/*********************************************************************************
[function name] FileInfoRelease

[arguments]
FileInfo			:	File information pointer

[return value]
NONE

*********************************************************************************/
void FileInfoRelease(struct TFD_ALL_t *FileInfo)
{
    if (NULL == FileInfo)
    {
        return;
    }
    ExclusiveLock(&FileInfo->exclusion.spin);

    if (NULL != FileInfo->Fd.pathname)
    {
        DEBUG_INFO("do free FileInfo->Fd.pathname");
        // free(FileInfo->Fd.pathname);
    }

    if (NULL != FileInfo->CacheInfo.cache_data)
    {
        DEBUG_INFO("do free FileInfo->CacheInfo.cache_data");
        free(FileInfo->CacheInfo.cache_data);
    }

    io_queue_release(FileInfo->ctx);

    FileInfo->Fd.pathname = NULL;
    FileInfo->Fd.fd = 0;
    FileInfo->used = 0;
    FileInfo->que_use_max = 0;
    FileInfo->que_use_cnt = 0;
    FileInfo->thread_rdy = 0;
    FileInfo->spec.offset = 0;
    FileInfo->spec.size = 0;
    FileInfo->spec.flags = 0;
    FileInfo->thread = 0;
    FileInfo->Err32Save = 0;
    FileInfo->CacheInfo.cache_max = 0;
    FileInfo->CacheInfo.cache_len = 0;
    FileInfo->CacheInfo.cache_top = 0;
    FileInfo->CacheInfo.cache_data = NULL;
    FileInfo->put = 0;
    FileInfo->get = 0;
    FileInfo->QueBlock.que_count = 0;
    FileInfo->QueBlock.que_size = 0;
    FileInfo->QueBlock.que_ptr = NULL;

    ExclusiveUnLock(&FileInfo->exclusion.spin);
}

/*********************************************************************************
[function name] GetFileInfo

[arguments]
pathname			:	Pointer to the pathname of the File to open

[return value]
Normal	:	File information pointer
ERROR   :   NULL

*********************************************************************************/
struct TFD_ALL_t *GetFileInfo(const char *pathname)
{
    int ret = 0;
    int32_t err = NO_ERROR;        // error code
    struct TFD_ALL_t *file = NULL; // Address of this File management information
    for (int i = 0; i < s_MaxFileNo; i++)
    {
        ExclusiveLock(&s_pFileInfo[i].exclusion.spin);
        if (0 != s_pFileInfo[i].used)
        {
            ret = memcmp(pathname, s_pFileInfo[i].Fd.pathname, strlen(pathname));
            if (0 != ret)
            {
                err = FILE_EXCLUSION_ERROR;
            }
        }
        else
        {
            if (NULL == file)
            {
                file = &s_pFileInfo[i];
                s_pFileInfo[i].Fd.pathname = pathname;
                s_pFileInfo[i].used = 1; // in use
            }
        }
        ExclusiveUnLock(&s_pFileInfo[i].exclusion.spin);

        if (NO_ERROR != err)
        {
            if (NULL != file)
            {
                FileInfoRelease(file);
                file = NULL;
            }
            break;
        }
    }

    if ((NO_ERROR == err) && (NULL == file))
    {
        err = FILE_OPEN_ERROR;
    }

    if(file != NULL)
    {
    	file->Err32Save = err;
    }
    return file;
}

/*********************************************************************************
[function name] GetBlockReq

[arguments]
FileInfo			:	File information pointer

[return value]
Normal	:	First address of this cube lock
ERROR   :   NULL

*********************************************************************************/
struct T_FIO_REQ_CMD *GetBlockReq(struct TFD_ALL_t *FileInfo)
{
    int32_t max = FileInfo->QueBlock.que_count;
    int32_t put = FileInfo->put;
    int32_t get = FileInfo->get;
    int32_t que_use_cnt = FileInfo->que_use_cnt;
    struct T_FIO_REQ_CMD *ret = NULL;

    if (NULL == FileInfo)
    {
        DEBUG_INFO("the FileInfo is NULL");
    }

    ExclusiveLock(&FileInfo->exclusion.spin);

    if (put != get)
    {
        // DEBUG_INFO("put != get");
        ret = GetCubeLock(FileInfo, get);
        get = (get + 1) % max;
        que_use_cnt -= 1;
        FileInfo->get = get;
        DEBUG_INFO("FileInfo->get = %d", FileInfo->get);
    }

    ExclusiveUnLock(&FileInfo->exclusion.spin);

    return ret;
}

/*********************************************************************************
[function name] CacheRangeDet

[arguments]
FileInfo			:	File information pointer
offset              :   Offset from the beginning of the data to be inspected
size                :   Size of the data to be inspected

[return value]
Judgment result (0:Out of range, 1:In range)

*********************************************************************************/
int32_t CacheRangeDet(struct TFD_ALL_t *FileInfo, const off_t offset, const size_t size)
{
    struct T_CACHE_INFO *Cache = &FileInfo->CacheInfo;
    size_t len = Cache->cache_len;
    off_t top = Cache->cache_top;
    int32_t ret = 0;

    DEBUG_INFO("=====================CacheRangeDet======================");
    DEBUG_INFO("the top of cache is %ld", top);
    DEBUG_INFO("the length of the cache is %ld", len);
    DEBUG_INFO("the offset is %ld", offset);
    DEBUG_INFO("the size is %ld", size);
    DEBUG_INFO("========================================================");
    if (0 != len)
    {
        if (top <= offset)
        {
            if ((top + len) >= (offset + size))
            {
                ret = 1;
                return ret;
            }
        }
    }

    ret = 0;
    return ret;
}

/*********************************************************************************
[function name] AsyIOWaitProcess

[arguments]
ctx                  ：    Asynchronous I/O Context
count                :      Read/write size


[return value]
error code

*********************************************************************************/
int32_t AsyIOWaitProcess(io_context_t ctx, size_t *count)
{
    struct io_event evt; // Structure for asynchronous I/O events
    int rc;              // Return value of io_getevents
    int32_t err;         // error code

    DEBUG_INFO("AsyIOWaitProcess..........");
    rc = io_getevents(ctx, 1, 1, &evt, NULL);

    if (0 > rc)
    {
        err = rc;
    }
    else
    {
        *count = evt.res;
        err = NO_ERROR;
    }

    return err;
}

/*********************************************************************************
[function name] AsyReadProgress

[arguments]
fd			         :	    file descriptor
ctx                  ：    Asynchronous I/O Context
pData                :      read data pointer
size                 :      read request size
offset               :      Read file offset position
ret_size             :      Pointer to the read size (result) storage variable

[return value]
error code

*********************************************************************************/
int32_t AsyReadProgress(int fd, io_context_t ctx, void *pData, size_t size, off_t offset, size_t *ret_size)
{
    struct iocb Iocb;   // Structure for I/O requests
    struct iocb *pIocb = &Iocb; // Iocb address
    int err = NO_ERROR; // Error code
    // int iRet = 0;

    if (0 != ((intptr_t)pData % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    if (0 != (size % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    if (0 != (offset % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    DEBUG_INFO("the fd is %d", fd);
    if (NULL == pData)
    {
        DEBUG_INFO("the pData is NULL");
    }
    DEBUG_INFO("the size is %ld", size);
    DEBUG_INFO("the offset is %ld", offset);

    io_prep_pread(&Iocb, fd, pData, size, offset);
    io_submit(ctx, 1, &pIocb);
    err = AsyIOWaitProcess(ctx, ret_size);
    return err;
}

/*********************************************************************************
[function name] CacheRefreshProcess

[arguments]
FileInfo			:	File information pointer
offset              ： Offset position of the data to be read/written
size                :   Size of the data to be read/written

[return value]
error code

*********************************************************************************/
int32_t CacheRefreshProcess(struct TFD_ALL_t *FileInfo, off_t offset, size_t size)
{
    struct T_CACHE_INFO *Cache = &FileInfo->CacheInfo;
    off_t new_offset;  // Offset after aligning to the boundary
    size_t new_size;   // Size after fitting the boundary
    size_t ret_size;   // Readout size (result)
    uint8_t *new_data; // Top address of allocated area
    int32_t err;       // error code

    DEBUG_INFO("Cache Refresh Process");
    if (0 == (offset % ALIGN_BLK))
    {
        new_offset = offset;
    }
    else
    {
        new_offset = (offset / ALIGN_BLK) * ALIGN_BLK;
        size += (offset % ALIGN_BLK);
    }

    new_size = (size / ALIGN_BLK) * ALIGN_BLK;

    if (0 != (size % ALIGN_BLK))
    {
        new_size += ALIGN_BLK;
    }

    if (Cache->cache_max < new_size)
    {
        new_data = (uint8_t *)aligned_alloc(ALIGN_BLK, new_size);
        if (NULL == new_data)
        {
            err = OUT_RANGE_ERROR;
            return err;
        }
        else
        {
            free(Cache->cache_data);
            Cache->cache_data = new_data;
            Cache->cache_max = new_size;
        }
    }

    Cache->cache_len = new_size;
    Cache->cache_top = new_offset;
    memset(Cache->cache_data, 0, Cache->cache_len);

    err = AsyReadProgress(FileInfo->Fd.fd, FileInfo->ctx, Cache->cache_data, Cache->cache_len, Cache->cache_top, &ret_size);

    return err;
}

/*********************************************************************************
[function name] GetMemBoundaryParam

[arguments]
CacheInfo			:	File information pointer
ReqOff              ： Write offset position
ReqSize             :   Write request data size
ppRetData           :   Write data pointer (Corrected)
RetOff              :   Write file offset position (corrected)
RetSize             :   Write request size (corrected)


[return value]
NONE

*********************************************************************************/
void GetMemBoundaryParam(const struct T_CACHE_INFO CacheInfo, const off_t ReqOff, const size_t ReqSize, uint8_t **ppRetData, off_t *RetOff, size_t *RetSize)
{
    off_t off;   // Offset position
    size_t size; // Write request data size

    off = ReqOff - CacheInfo.cache_top;
    size = ReqSize;

    if (0 != (off % ALIGN_BLK))
    {
        size += (off % ALIGN_BLK);
        off = (off / ALIGN_BLK) * ALIGN_BLK;
    }

    if (0 != (size % ALIGN_BLK))
    {
        size += (ALIGN_BLK - (size % ALIGN_BLK));
    }

    // *ppRetData = (CacheInfo.cache_data + off);
    *RetOff = off + CacheInfo.cache_top;
    *RetSize = size;
}

/*********************************************************************************
[function name] AsyWriteProcess

[arguments]
fd			        :	file descriptor
ctx                 ： Asynchronous I/O Context
pData               :   write data pointer
size                :   write request size
offset              :   Write file offset position
ret_size            :   Pointer to the variable that stores the write size (result)

[return value]
error code

*********************************************************************************/
int32_t AsyWriteProcess(int fd, io_context_t ctx, void *pData, size_t size, off_t offset, size_t *ret_size)
{
    struct iocb Iocb;   // Structure for I/O requests
    struct iocb *pIocb = &Iocb; // Iocb address
    int err = NO_ERROR; // error code
    // int iRet = 0;

    if (0 != ((intptr_t)pData % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    if (0 != (size % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    if (0 != (offset % ALIGN_BLK))
    {
        err = PARAM_ERROR;
        return err;
    }

    DEBUG_INFO("the ret of pData[3] is %d", ((unsigned char *)pData)[3]);
    DEBUG_INFO("the ret of size is %ld", size);
    DEBUG_INFO("the ret of offset is %ld", offset);
    io_prep_pwrite(&Iocb, fd, pData, size, offset);
    io_submit(ctx, 1, &pIocb);
    DEBUG_INFO("the ret_size is %ld", *ret_size);
    err = AsyIOWaitProcess(ctx, ret_size);
    return err;
}

/*********************************************************************************
[function name] WriteMainProcess

[arguments]
FileInfo			:	File information pointer
Req                 ： First address of this cube lock

[return value]
NONE

*********************************************************************************/
void WriteMainProcess(struct TFD_ALL_t *FileInfo, struct T_FIO_REQ_CMD *Req)
{
    int32_t ret;                                // Cache range judgment result (0:out of range, 1:in range)
    int32_t err = NO_ERROR;                     // Error code
    uint8_t *pData;                             // Top address of cache_data
    off_t off;                                  // Write offset position
    // size_t count;                               // Write size (result)
    // uint8_t *pReqData;                          // Write data pointer (memory boundary corrected)
    off_t ReqOff;                               // Write file offset position (memory boundary corrected)
    size_t ReqSize;                             // Write request size (corrected for memory boundaries)
    uint8_t *pWriteData = (uint8_t *)(Req + 1); // The first address of the write data area

    DEBUG_INFO("Write main process");
    ret = CacheRangeDet(FileInfo, Req->offset, Req->count);

    if (0 == ret)
    {
        err = CacheRefreshProcess(FileInfo, Req->offset, Req->count);

        if (NO_ERROR != err)
        {
            if (NO_ERROR == FileInfo->Err32Save)
            {
                FileInfo->Err32Save = err;
            }

            Req->cmd = REQ_IDLE;
            return;
        }
    }

    pData = FileInfo->CacheInfo.cache_data;
    off = Req->offset - FileInfo->CacheInfo.cache_top;
    memcpy(pData + off, pWriteData, Req->count);

    DEBUG_INFO("pData[5] = %d", pData[5]);
    DEBUG_INFO("pData[65] = %d", pData[65]);

    GetMemBoundaryParam(FileInfo->CacheInfo, Req->offset, Req->count, &pData, &ReqOff, &ReqSize);
    DEBUG_INFO("pData[5] = %d", pData[5]);
    DEBUG_INFO("pData[65] = %d", pData[65]);
    DEBUG_INFO("Req->offset = %ld, Req->count = %ld", Req->offset, Req->count);
    err = AsyWriteProcess(FileInfo->Fd.fd, FileInfo->ctx, pData, ReqSize, ReqOff, &Req->count);
    DEBUG_INFO("finish AsyWriteProcess");
    if ((NO_ERROR != err) && (NO_ERROR == FileInfo->Err32Save))
    {
        FileInfo->Err32Save = err;
    }

    Req->cmd = REQ_IDLE;
}

/*********************************************************************************
[function name] CloseMainProcess

[arguments]
FileInfo			:	File information pointer
Req                 ： First address of this cube lock

[return value]
NONE

*********************************************************************************/
void CloseMainProcess(struct TFD_ALL_t *FileInfo, struct T_FIO_REQ_CMD *Req)
{
    int rc = 0;
    if ((FileInfo->spec.flags & O_RDWR) != 0)
    {
        rc = ftruncate(FileInfo->Fd.fd, Req->fsize);

        if (0 > rc)
        {
            rc = -errno;
            close(FileInfo->Fd.fd);
            Req->cmd = REQ_IDLE;
            Req->ret = rc;
            return;
        }
    }

    rc = close(FileInfo->Fd.fd);

    if (0 > rc)
    {
        rc = -errno;
    }

    Req->cmd = REQ_IDLE;
    Req->ret = rc;
}

/*********************************************************************************
[function name] FileIOFunc

[arguments]
FileInfo			:	File information pointer

[return value]
NONE

*********************************************************************************/
void *FileIOFunc(void *args)
{
    struct TFD_ALL_t *FileInfo = (struct TFD_ALL_t *)args;
    int ret = 0;
    int thread_loop_flag = TRUE;
    int32_t lastcmd;           // I/O request command
    struct T_FIO_REQ_CMD *Req; // First address of this cube lock
    struct sched_param sch_param;

    /* init sched_param */
    memset(&sch_param, 0, sizeof(sch_param));
    sch_param.sched_priority = sched_get_priority_min(SCHED_FIFO);

    FileInfo->CacheInfo.cache_data = (uint8_t *)aligned_alloc(ALIGN_BLK, CACHE_MAX);
    FileInfo->CacheInfo.cache_max = CACHE_MAX;
    FileInfo->CacheInfo.cache_len = 0;
    FileInfo->CacheInfo.cache_top = 0;

    DEBUG_INFO("start to init io queue");
    ret = io_queue_init(1, &FileInfo->ctx);
    DEBUG_INFO("the ret of io_queue_init is %d", ret);

    FileInfo->thread_rdy = 1;

    DEBUG_INFO("start to set thread schedparam");
    DEBUG_INFO("the thread_rdy = %d", FileInfo->thread_rdy);
    ret = pthread_setschedparam(FileInfo->thread, SCHED_FIFO, &sch_param);
    if (0 != ret)
    {
        FileInfo->Err32Save = GENERAL_ERROR;
    }

    lastcmd = REQ_IDLE;

    while (TRUE == thread_loop_flag)
    {
        // DEBUG_INFO("Get block req");
        Req = GetBlockReq(FileInfo);

        if (NULL == Req)
        {
            req.tv_nsec = 1000000;
            nanosleep(&req, NULL);
        }
        else
        {
            lastcmd = Req->cmd;
            switch (Req->cmd)
            {
            case REQ_WRITE:
            {
                if (0 < Req->count)
                {
                    DEBUG_INFO("write main process");
                    WriteMainProcess(FileInfo, Req);
                }
                Req->cmd = REQ_IDLE;
                break;
            }

            case REQ_CLOSE_NBLK:
            case REQ_CLOSE_BLK:
            {
                DEBUG_INFO("close main process");
                CloseMainProcess(FileInfo, Req);
                Req->cmd = REQ_IDLE;
                thread_loop_flag = FALSE;
                break;
            }

            default:
                Req->cmd = REQ_IDLE;
            }
        }
    }

    if (REQ_CLOSE_NBLK == lastcmd)
    {
        FileInfoRelease(FileInfo);
    }

    pthread_exit(NULL);
    return NULL; /* Warning measures for static analysis tools */ 
}

/*********************************************************************************
[function name] t_open

[arguments]
pathname			:	Pointer to the pathname of the File to open
flags               :   Option Flag for File open
que_size            :   Byte size of one cube-lock
que_count           :   Number of cube locks to use
que_ptr             :   First address of the cube lock area
err                 :   Error code storage pointer

[return value]
Normal	:	File information pointer
ERROR   :   NULL

*********************************************************************************/
struct TFD_t *t_open(const char *pathname, int32_t flags, size_t que_size, int32_t que_count, void *que_ptr, int32_t *err)
{
    int32_t Err;
    int32_t append; // Whether O_APPEND is specified or not (0: not specified, 1: specified)
    mode_t mode;    // File permissions given to the third argument of open
    int fd;         // File descriptor
    int ret;
    struct TFD_ALL_t *FileInfo;
    struct stat filestat;

    Err = NO_ERROR;
    FileInfo = NULL;

    if (NULL == err)
    {
        return NULL;
    }

    if (0 == s_Apilnit)
    {
        Err = FILE_INIT_ERROR;
        DEBUG_INFO("s_Apilnit error");
        goto t_open_end;
    }

    if (((O_RDWR | O_APPEND | O_CREAT) != flags) && ((O_RDWR | O_APPEND) != flags) && ((O_RDWR | O_CREAT) != flags) && (O_RDWR != flags) && (O_RDONLY != flags) && ((O_RDONLY | O_APPEND | O_CREAT) != flags) && ((O_RDONLY | O_APPEND) != flags) && ((O_RDONLY | O_CREAT) != flags))
    {
        Err = PARAM_ERROR;
        DEBUG_INFO("flag error");
        goto t_open_end;
    }

    if ((QUE_WRITE_1024 != que_size) && (QUE_WRITE_512 != que_size) && (QUE_WRITE_2048 != que_size) && (QUE_WRITE_4096 != que_size))
    {
        Err = PARAM_ERROR;
        DEBUG_INFO("que_size error");
        goto t_open_end;
    }

    if (0 >= que_count)
    {
        Err = PARAM_ERROR;
        DEBUG_INFO("que_count error");
        goto t_open_end;
    }

    if (NULL == que_ptr)
    {
        Err = PARAM_ERROR;
        DEBUG_INFO("que_ptr error");
        goto t_open_end;
    }
    DEBUG_INFO("GetFileInfo exe");
    FileInfo = GetFileInfo(pathname);

    if (NULL == FileInfo)
    {
        Err = FILE_MANAGE_INFO_ERROR;
        DEBUG_INFO("FileInfo error");
        goto t_open_end;
    }

    DEBUG_INFO("start to init queblock");
    FileInfo->QueBlock.que_size = que_size;
    FileInfo->QueBlock.que_count = que_count;
    FileInfo->QueBlock.que_ptr = que_ptr;

    if (((O_RDWR | O_APPEND | O_CREAT) == flags) || ((O_RDWR | O_APPEND) == flags) || ((O_RDONLY | O_APPEND | O_CREAT) == flags) || ((O_WRONLY | O_APPEND) == flags))
    {
        flags &= 0xFFFFFBFF;
        DEBUG_INFO("O_APPEND exist");
        append = 1;
    }
    else
    {
        append = 0;
    }

    mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH;
    DEBUG_INFO("start to open");
    fd = open(pathname, flags | O_DIRECT, mode);

    if (0 >= fd)
    {
        printf("open error\n");
        Err = FILE_OPEN_ERROR;
        goto t_open_end;
    }

    FileInfo->Fd.fd = fd;
    FileInfo->spec.flags = flags;
    DEBUG_INFO("start to fstat");
    ret = fstat(fd, &filestat);
    DEBUG_INFO(" fstat over");
    if (0 > ret)
    {
        Err = GENERAL_ERROR;
        close(fd);
        goto t_open_end;
    }

    FileInfo->spec.size = filestat.st_size;

    if (1 == append)
    {
        FileInfo->spec.offset = filestat.st_size;
    }

    ret = pthread_create(&FileInfo->thread, NULL, FileIOFunc, FileInfo);

    if (0 != ret)
    {
        Err = GENERAL_ERROR;
        close(fd);
        goto t_open_end;
    }

    do
    {
        req.tv_nsec = 1000000;
        nanosleep(&req, NULL);
        DEBUG_INFO("the thread_rdy = %d", FileInfo->thread_rdy);
    } while (0 == FileInfo->thread_rdy);

t_open_end:
    if (NULL == FileInfo)
    {
        DEBUG_INFO("the FileInfo = NULL");
        return NULL;
    }

    if (NO_ERROR != Err)
    {
        FileInfoRelease(FileInfo);
        DEBUG_INFO("the Err = %d", Err);
        *err = Err;
        return NULL;
    }

    *err = Err;
    return &FileInfo->Fd;
}

/*********************************************************************************
[function name] PutBlockAcqProcess

[arguments]
FileInfo			    :	Address of this File management information


[return value]
Normal	:	First address of the obtained cube lock
ERROR   :   NULL

*********************************************************************************/
struct T_FIO_REQ_CMD *PutBlockAcqProcess(struct TFD_ALL_t *FileInfo)
{
    struct T_FIO_REQ_CMD *ret = NULL;
    ExclusiveLock(&FileInfo->exclusion.spin);

    ret = GetCubeLock(FileInfo, FileInfo->put);

    ExclusiveUnLock(&FileInfo->exclusion.spin);

    return ret;
}

/*********************************************************************************
[function name] PutBlockProgress

[arguments]
FileInfo			:	Address of this File management information

[return value]
Normal	:	error code

*********************************************************************************/
int32_t PutBlockProgress(struct TFD_ALL_t *FileInfo)
{
    int32_t ret = 0;
    int32_t next; // Next cube lock number
    int32_t max_io = FileInfo->QueBlock.que_count;
    struct T_FIO_REQ_CMD *pFio; // First address of this cube lock

    ExclusiveLock(&FileInfo->exclusion.spin);

    next = (FileInfo->put + 1) % max_io;

    if (next == FileInfo->get)
    {
        ret = 1;
        FileInfo->que_use_max = FileInfo->QueBlock.que_count - 1;
        ExclusiveUnLock(&FileInfo->exclusion.spin);
        return ret;
    }

    pFio = GetCubeLock(FileInfo, next);

    if (REQ_IDLE != pFio->cmd)
    {
        ret = 1;
        FileInfo->que_use_max = FileInfo->QueBlock.que_count - 1;
        ExclusiveUnLock(&FileInfo->exclusion.spin);
        return ret;
    }

    FileInfo->put = next;
    FileInfo->que_use_cnt++;

    if (FileInfo->que_use_cnt > FileInfo->que_use_max)
    {
        FileInfo->que_use_max = FileInfo->que_use_cnt;
    }

    ExclusiveUnLock(&FileInfo->exclusion.spin);

    return ret;
}

/*********************************************************************************
[function name] t_close

[arguments]
File			    :	File information pointer of the File to be closed.
flag                :   close control flag (0: CLOSE_NONBLK, 1: CLOSE_BLOCK)

[return value]
Normal	:	error code

*********************************************************************************/
int32_t t_close(struct TFD_t *File, int32_t flag)
{
    int32_t Err = NO_ERROR;     // Error code
    struct TFD_ALL_t *FileInfo; // Address of this File management information
    struct T_FIO_REQ_CMD *pReq; // First address of this cube lock
    int32_t rc;                 // Queue progress result (0:Success, 1:Failure)

    if ((CLOSE_NONBLK != flag) && (CLOSE_BLOCK != flag))
    {
        Err = PARAM_ERROR;
        return Err;
    }

    FileInfo = (struct TFD_ALL_t *)File;
    pReq = PutBlockAcqProcess(FileInfo);

    if (REQ_IDLE != pReq->cmd)
    {
        do
        {
            rc = PutBlockProgress(FileInfo);
            if (0 != rc)
            {
                req.tv_nsec = 100000;
                nanosleep(&req, NULL);
            }
        } while (rc != 0);
        pReq = PutBlockAcqProcess(FileInfo);
    }

    if (CLOSE_NONBLK == flag)
    {
        pReq->cmd = REQ_CLOSE_NBLK;
    }
    else
    {
        pReq->cmd = REQ_CLOSE_BLK;
    }

    pReq->fsize = FileInfo->spec.size;

    do
    {
        rc = PutBlockProgress(FileInfo);
        if (0 != rc)
        {
            req.tv_nsec = 100000;
            nanosleep(&req, NULL);
        }
    } while (rc != 0);

    if (CLOSE_NONBLK == flag)
    {
        DEBUG_INFO("do pthread_detach");
        s_Apilnit = 0;
        pthread_detach(FileInfo->thread);
        return Err;
    }
    else
    {
        DEBUG_INFO("do pthread_join");
        s_Apilnit = 0;
        pthread_join(FileInfo->thread, NULL);
        if (0 > pReq->ret)
        {
            Err = pReq->ret;
        }
        DEBUG_INFO("do FileInfoRelease");
        FileInfoRelease(FileInfo);
        return Err;
    }
}

/*********************************************************************************
[function name] t_write

[arguments]
File			    :	File information pointer of the File to write
buf                 :   Pointer to write data
count               :   Byte size to write
err                 :   Pointer to the variable that stores the error code

[return value]
write success: Byte size written, write failure: -1


*********************************************************************************/
ssize_t t_write(struct TFD_t *File, const void *buf, size_t count, int32_t *err)
{
    ssize_t ret = -1;
    struct TFD_ALL_t *FileInfo; // Address of this File management information
    struct T_FIO_REQ_CMD *pFio; // First address of this cube lock
    int32_t rc;                 // Queue progress result (0:Success, 1:Failure)
    uint8_t *pBuf = (uint8_t *)buf;
    uint8_t *pWriteData; // First address of write data area
    size_t cnt;          // Byte size for writing to the write data area of the cube lock
    size_t MaxWriteLen;  // Byte size of write data area for one cube-lock

    if (NULL == err)
    {
        DEBUG_INFO("the err is NULL");
        return ret;
    }

    if ((NULL == File))
    {
        *err = PARAM_ERROR;
        DEBUG_INFO("the File is NULL");
        return ret;
    }
    if ((NULL == buf))
    {
        *err = PARAM_ERROR;
        DEBUG_INFO("the  buf is NULL");
        return ret;
    }
    if ((NULL == File) || (NULL == buf))
    {
        *err = PARAM_ERROR;
        DEBUG_INFO("the File or buf is NULL");
        return ret;
    }

    if (0 == count)
    {
        *err = NO_ERROR;
        DEBUG_INFO("the count = 0");
        ret = 0;
        return ret;
    }

    FileInfo = (struct TFD_ALL_t *)File;
    MaxWriteLen = FileInfo->QueBlock.que_size - QUE_CTRL_SIZE;

    if (NO_ERROR != FileInfo->Err32Save)
    {
        *err = FileInfo->Err32Save;
        DEBUG_INFO("error exist, error = %d", FileInfo->Err32Save);
        return ret;
    }

    DEBUG_INFO("start to put block acq process");
    pFio = PutBlockAcqProcess(FileInfo);
    *err = NO_ERROR;
    DEBUG_INFO("the pFio->cmd = %d", pFio->cmd);
    switch (pFio->cmd)
    {
    case REQ_IDLE:
    {
        ret = 0;
        DEBUG_INFO("enter the REQ_IDLE state");
        while (1)
        {
            DEBUG_INFO("enter while");
            pWriteData = (uint8_t *)(pFio + 1);

            pFio->cmd = REQ_WRITE;
            pFio->offset = FileInfo->spec.offset;
            pFio->count = 0;

            DEBUG_INFO("the count is %ld", count);
            if (MaxWriteLen < count)
            {
                cnt = MaxWriteLen;
            }
            else
            {
                cnt = count;
            }
            memcpy(pWriteData, pBuf, cnt);
            memcpy(FileInfo->CacheInfo.cache_data, pBuf, cnt);
            pFio->count += cnt;
            DEBUG_INFO("cnt = %ld\n", cnt);
            DEBUG_INFO("pFio->count = %ld\n", pFio->count);
            DEBUG_INFO("FileInfo->CacheInfo.cache_data[5] = %d\n", FileInfo->CacheInfo.cache_data[5]);
            DEBUG_INFO("FileInfo->CacheInfo.cache_data[55] = %d\n", FileInfo->CacheInfo.cache_data[55]);

            FileInfo->spec.offset += cnt;

            if (FileInfo->spec.size < FileInfo->spec.offset)
            {
                FileInfo->spec.size = FileInfo->spec.offset;
            }

            ret += cnt;
            pBuf += cnt;
            count -= cnt;

            DEBUG_INFO("MaxWriteLen = %ld\n", MaxWriteLen);
            DEBUG_INFO("pFio->count = %ld\n", pFio->count);
            if (MaxWriteLen <= pFio->count)
            {
                rc = PutBlockProgress(FileInfo);

                if (0 != rc)
                {
                    break;
                }
                else
                {
                    pFio = PutBlockAcqProcess(FileInfo);
                }
            }
            else
            {
                // DEBUG_INFO("start to join pthread");
                // pthread_join(FileInfo->thread, NULL);
                break;
            }
            // DEBUG_INFO("start to join pthread");
            // pthread_join(FileInfo->thread, NULL);
        }
        break;
    }

    case REQ_WRITE:
    {
        ret = 0;
        while (1)
        {
            pWriteData = (uint8_t *)(pFio + 1);
            DEBUG_INFO("MaxWriteLen = %ld\n", MaxWriteLen);
            DEBUG_INFO("pFio->count + count = %ld\n", pFio->count + count);
            if (MaxWriteLen <= (pFio->count + count))
            {
                cnt = MaxWriteLen - (pFio->count);
                DEBUG_INFO("the cnt = %ld\n", cnt);
                if (0 < cnt)
                {
                    memcpy(&pWriteData[pFio->count], pBuf, cnt);
                    pFio->count += cnt;
                    FileInfo->spec.offset += cnt;

                    if (FileInfo->spec.size < FileInfo->spec.offset)
                    {
                        FileInfo->spec.size = FileInfo->spec.offset;
                    }

                    ret += cnt;
                    pBuf += cnt;
                    count -= cnt;
                    rc = PutBlockProgress(FileInfo);

                    if (0 != rc)
                    {
                        break;
                    }

                    pFio = PutBlockAcqProcess(FileInfo);
                    pFio->cmd = REQ_WRITE;
                    pFio->offset = FileInfo->spec.offset;
                    pFio->count = 0;
                }
                else
                {
                    if (0 >= ret)
                    {
                        *err = REQUEST_BLOCK_FULL_ERROR;
                        ret = -1;
                    }

                    PutBlockProgress(FileInfo);
                    break;
                }
            }
            else
            {
                memcpy(&pWriteData[pFio->count], pBuf, count);
                pFio->count += count;
                FileInfo->spec.offset += count;
                if (FileInfo->spec.size < FileInfo->spec.offset + count)
                {
                    FileInfo->spec.size = FileInfo->spec.offset;
                }

                ret += count;
                break;
            }
            // pthread_join(FileInfo->thread, NULL);
        }
        break;
    }

    default:
        *err = REQUEST_BLOCK_FULL_ERROR;
    }

    return ret;
}

/*********************************************************************************
[function name] t_lseek

[arguments]
File			    :	File information pointer of the target File.
buf                 :   Byte size to offset * 0 or more is valid.
count               :   offset reference position *Only SEEK_SET can be specified.
err                 :   Pointer to the variable that stores the error code

[return value]
Success: offset position, Failure: -1


*********************************************************************************/
off_t t_lseek(struct TFD_t *File, off_t offset, int32_t whence, int32_t *err)
{
    off_t ret;
    struct TFD_ALL_t *FileInfo;
    struct T_FIO_REQ_CMD *pReq;
    int32_t rc;

    if (NULL == err)
    {
        printf("Param error\n");
        return -1;
    }

    if ((NULL == File) || (offset < 0))
    {
        *err = PARAM_ERROR;
        printf("Param error\n");
        return -1;
    }

    if (SEEK_SET != whence)
    {
        printf("Param error\n");
        *err = PARAM_ERROR;
        return -1;
    }

    FileInfo = (struct TFD_ALL_t *)File;

    if (NO_ERROR != FileInfo->Err32Save)
    {
        *err = FileInfo->Err32Save;
        return -1;
    }

    pReq = PutBlockAcqProcess(FileInfo);

    if (REQ_IDLE != pReq->cmd)
    {
        rc = PutBlockProgress(FileInfo);

        if (0 != rc)
        {
            *err = REQUEST_LOCK_FULL;
            return -1;
        }
    }

    FileInfo->spec.offset = offset;

    if (FileInfo->spec.size < FileInfo->spec.offset)
    {
        FileInfo->spec.size = FileInfo->spec.offset;
    }

    *err = NO_ERROR;
    ret = offset;
    return ret;
}

/*********************************************************************************
[function name] t_quests_get

[arguments]
File			    :	File information pointer of the target File.
current             :   Variable pointer (current number of cube locks used)
max                 :   Variable pointer (largest number of cube locks ever used)


[return value]
error code

*********************************************************************************/
int32_t t_quests_get(struct TFD_t *File, int32_t *current, int32_t *max)
{
    int32_t err;                // error code
    struct TFD_ALL_t *FileInfo; // Address of this File management information

    if ((NULL == File) || (NULL == current) || (NULL == max))
    {
        err = PARAM_ERROR;
        return err;
    }

    FileInfo = (struct TFD_ALL_t *)File;

    if (0 != FileInfo->used)
    {
        *current = FileInfo->que_use_cnt;
        *max = FileInfo->que_use_max;
    }

    err = NO_ERROR;

    return err;
}
