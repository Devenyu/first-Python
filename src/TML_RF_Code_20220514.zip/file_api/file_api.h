/*******************************************************************************
**	File name		: file_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

#ifndef __FILE_API_H__
#define __FILE_API_H__

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <pthread.h>
#include <stdio.h>
#include <sched.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
// #define __USE_GNU 1
#include <fcntl.h>
#include <libaio.h>


#include "Err32_def_api.h"

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct FILE_ST
{
    // sem_t *lock;
    int fd;
    unsigned int buffer_size;
    unsigned char *ptr;
    _Bool stop_flag;
} file_st;

typedef struct TFD_t
{
    int32_t fd;     // File descriptor
    const char *pathname; // the name of file
} tfd_t;

typedef struct T_FILE_SPEC
{
    off_t offset;  // File offset position (unit: Byte)
    off_t size;    // File overall size (in bytes)
    int32_t flags; // Optional Flag for File open
} t_file_spec;

typedef struct T_THREAD_EXCLUSION
{
    pthread_mutex_t mutex;   // File management intelligence excludes mutex *not used
    pthread_spinlock_t spin; // File Management Intelligence Exclusion with spinlock
} t_thread_exclusion;

typedef struct T_CACHE_INFO
{
    size_t cache_max;    // Maximum cache length
    size_t cache_len;    // Cache size
    off_t cache_top;     // Cache head position
    uint8_t *cache_data; // Cache Pointer
} t_cache_info;

typedef struct T_QUE_BLOCK
{
    int32_t que_count; // Number of cube locks to use
    size_t que_size;   // Byte size of one cubelock
    void *que_ptr;     // First address of cube-locked area
} t_que_block;

typedef struct T_FIO_REQ_CMD
{
    int32_t cmd;  // I/O request command
    int32_t ret;  // I/O request execution result
    off_t offset; // Write offset position
    size_t count; // Write request data size
    off_t fsize;  // File size at close
} t_fio_req_cmd;

typedef struct TFD_ALL_t
{
    struct TFD_t Fd;                     // File Information Part 1
    int32_t used;                 // Flag in use for this structure (0: not in use, 1: in use)
    int32_t que_use_max;          // Largest number of cube locks ever used
    int32_t que_use_cnt;          // Current number of cube locks used
    int32_t thread_rdy;           // Readiness Flag of the generated FileI/O thread (0: in preparation, 1: ready)
    struct T_FILE_SPEC spec;             // File Information Part 2
    pthread_t thread;             // Identifier of the FileI/O thread that was created.
    struct T_THREAD_EXCLUSION exclusion; // Thread Exclusion Information
    int32_t Err32Save;            // Error result of the last FileI/O request
    struct T_CACHE_INFO CacheInfo;       // cache information
    io_context_t ctx;             // Asynchronous I/O Context
    int32_t put;                  // Ring buffer 0 鈮?X 鈮?que_count - 1 * Proceed with t_write
    int32_t get;                  // Ring buffer 0 鈮?X 鈮?que_count - 1 * Proceed with acquisition by FileI/O thread.
    struct T_QUE_BLOCK QueBlock;         // Cubelock Information
} tfd_all_t;

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define TRUE 1
#define FALSE 0
#define CLOSE_NONBLK (0)
#define CLOSE_BLOCK (1)
#define QUE_CTRL_SIZE (32)
#define QUE_WRITE_512 (QUE_CTRL_SIZE + 512)
#define QUE_WRITE_1024 (QUE_CTRL_SIZE + 1024)
#define QUE_WRITE_2048 (QUE_CTRL_SIZE + 2048)
#define QUE_WRITE_4096 (QUE_CTRL_SIZE + 4096)
#define ALIGN_BLK (4096)
#define CACHE_MAX (ALIGN_BLK << 1)
// #define _GNU_SOURCE
enum
{
    REQ_IDLE = 0,  // process completion
    REQ_WRITE,     // write request
    REQ_CLOSE_BLK, // Close request (blocking)
    REQ_CLOSE_NBLK // Close request (non-blocking)
};
/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int32_t t_file_api_init(int32_t files);
extern struct T_FIO_REQ_CMD *GetCubeLock(struct TFD_ALL_t *FileInfo, int32_t idx);
extern void ExclusiveLock(pthread_spinlock_t *spin);
extern void ExclusiveUnLock(pthread_spinlock_t *spin);
extern void FileInfoRelease(struct TFD_ALL_t *FileInfo);
extern struct TFD_ALL_t *GetFileInfo(const char *pathname);
extern struct T_FIO_REQ_CMD *GetBlockReq(struct TFD_ALL_t *FileInfo);
extern int32_t CacheRangeDet(struct TFD_ALL_t *FileInfo, const off_t offset, const size_t size);
extern int32_t AsyIOWaitProcess(io_context_t ctx, size_t *count);
extern int32_t AsyReadProgress(int fd, io_context_t ctx, void *pData, size_t size, off_t offset, size_t *ret_size);
extern int32_t CacheRefreshProcess(struct TFD_ALL_t *FileInfo, off_t offset, size_t size);
extern void GetMemBoundaryParam(const struct T_CACHE_INFO CacheInfo, const off_t ReqOff, const size_t ReqSize, uint8_t **ppRetData, off_t *RetOff, size_t *RetSize);
extern int32_t AsyWriteProcess(int fd, io_context_t ctx, void *pData, size_t size, off_t offset, size_t *ret_size);
extern void WriteMainProcess(struct TFD_ALL_t *FileInfo, struct T_FIO_REQ_CMD *Req);
extern void CloseMainProcess(struct TFD_ALL_t *FileInfo, struct T_FIO_REQ_CMD *Req);
extern void *FileIOFunc(void *args);
extern struct TFD_t *t_open(const char *pathname, int32_t flags, size_t que_size, int32_t que_count, void *que_ptr, int32_t *err);
extern struct T_FIO_REQ_CMD *PutBlockAcqProcess(struct TFD_ALL_t *FileInfo);
extern int32_t PutBlockProgress(struct TFD_ALL_t *FileInfo);
extern int32_t t_close(struct TFD_t *File, int32_t flag);
extern ssize_t t_write(struct TFD_t *File, const void *buf, size_t count, int32_t *err);
extern off_t t_lseek(struct TFD_t *File, off_t offset, int32_t whence, int32_t *err);
extern int32_t t_quests_get(struct TFD_t *File, int32_t *current, int32_t *max);

#endif /* __FILE_API_H__*/