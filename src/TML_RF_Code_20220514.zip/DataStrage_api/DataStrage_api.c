/*******************************************************************************
**	File name		: DataStrage_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>

#include "common.h"
#include "mem_map.h"
#include "Err32_def_api.h"
#include "DataStrage_api.h"

uint32_t start_index = 0;
uint32_t end_index = 0;
_Bool Store_Data_Flag = FALSE;
_Bool Store_Past_Data_Flag = FALSE;
AD_DATA_STRUCT *ad_temp_data = NULL;

int putString2Csv(char *str, char *filename, int mode)
{
    FILE *_fp;
    // try to open file
    if ((_fp = fopen(filename, "a")) == NULL)
    {
        printf("fopen called error");
        return FILE_OPEN_ERROR;
    }

    int _mode = mode;

    switch (_mode)
    {
    case ECWM_ONELINE:
    {
        fputs(str, _fp);
        fputs(",", _fp);
    }
    break;
    case ECWM_OTHERLINE:
    {
        fputs("\n", _fp);
    }
    break;
    default:
        break;
    }
    if (fclose(_fp) != 0)
    {
        printf("fclose called error");
        return FILE_OPEN_ERROR;
    }

    return NO_ERROR;
}

int SetRegister(unsigned long long reg_VirthBaseAddr, int offset, int val)
{
    *((unsigned *)(reg_VirthBaseAddr + offset)) = val;
    return NO_ERROR;
}

int GetRegister(unsigned long long reg_VirthBaseAddr, int offset, int *val)
{
    *val = *((unsigned *)(reg_VirthBaseAddr + offset));
    return NO_ERROR;
}

int AutoInitReg(int mode)
{
    uint32_t iRet = 0;
    unsigned long long reg_VirthBaseAddr;
    // DEBUG_INFO("mem_map BASEADDR");
    iRet = mem_mmap(BASEADDR, REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    SetRegister(reg_VirthBaseAddr, 0x200, 0xaaaaaaaa);
    SetRegister(reg_VirthBaseAddr, 0x0, 0x0);
    SetRegister(reg_VirthBaseAddr, 0x194, 0x0);
    SetRegister(reg_VirthBaseAddr, 0x198, 0x0);
    SetRegister(reg_VirthBaseAddr, 0x19c, 0x0);
    SetRegister(reg_VirthBaseAddr, 0x0080, 0x00000032);
    SetRegister(reg_VirthBaseAddr, 0x0084, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x0088, 0x00004E20);
    SetRegister(reg_VirthBaseAddr, 0x0090, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x0090, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x1440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x2440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x3440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x5440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x6440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x7440, 0x00008000);
    SetRegister(reg_VirthBaseAddr, 0x0180, DATA_START_ADDR);
    SetRegister(reg_VirthBaseAddr, 0x0184, DATA_END_ADDR);
    SetRegister(reg_VirthBaseAddr, 0x0188, 0x00100000);
    SetRegister(reg_VirthBaseAddr, 0x0190, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x0190, 0x00000000);
    SetRegister(reg_VirthBaseAddr, 0x0194, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x0198, mode);
    SetRegister(reg_VirthBaseAddr, 0x0000, 0x00000001);
    SetRegister(reg_VirthBaseAddr, 0x019c, 0x00000001);

    usleep(1000000);
    mem_unmap(reg_VirthBaseAddr, REG_SIZE);
    usleep(1000000);
    // DEBUG_INFO("write reg over");

    return NO_ERROR;
}

void *thread_save_data(void *args)
{
    // uint32_t iRet = 0;
    uint32_t iAD_Count = 0;
    // uint16_t iAD_Timeuse = 0;
    uint32_t iAD_Offset = 0;
    struct timeval AD_current_time;
    unsigned long long reg_VirthBaseAddr_Temp;
    AutoInitReg(8);
    // DEBUG_INFO("map the base address");
    mem_mmap(DATA_START_ADDR, MAX_AD_OFFSET, &reg_VirthBaseAddr_Temp);
    // DEBUG_INFO("begin to read the data");

    do
    {
        gettimeofday(&AD_current_time, NULL);
        ad_temp_data[iAD_Count].now_time = (long long)AD_current_time.tv_sec * (long long)1000000 + (long long)AD_current_time.tv_usec;
        // DEBUG_INFO("begin to memcpy");
        // DEBUG_INFO("the offset is 0x%08x", iAD_Offset);
        memcpy(ad_temp_data[iAD_Count].data, (uint32_t *)(reg_VirthBaseAddr_Temp + iAD_Offset), sizeof(uint32_t) * 6);
#if 0
            DEBUG_INFO("ad_temp_data[%d].time = %lld", iAD_Count, ad_temp_data[iAD_Count].now_time);
            for (int i = 0; i < 6; i++)
            {
                DEBUG_INFO("ad_temp_data[%d].data = 0x%08x", iAD_Count, ad_temp_data[iAD_Count].data[i]);
            }
#endif
        end_index = iAD_Count;
        iAD_Count++;
        iAD_Offset += 24;
        if (iAD_Count >= MAX_AD_BUF_SIZE)
        {
            iAD_Count = 0;
        }
        if (iAD_Offset >= MAX_AD_OFFSET)
        {
            iAD_Offset = 0;
        }

        // DEBUG_INFO("");
    } while (FALSE != Store_Past_Data_Flag);

    mem_unmap(reg_VirthBaseAddr_Temp, MAX_AD_OFFSET);
    pthread_exit(NULL);
    return NULL; /* Warning measures for static analysis tools */
}

int StoreData(_Bool flag)
{

    pthread_t thread;
    pthread_attr_t attr = {0};
    Store_Past_Data_Flag = flag;

    if (TRUE == flag)
    {
        pthread_attr_init(&attr);
        ad_temp_data = (AD_DATA_STRUCT *)malloc(sizeof(AD_DATA_STRUCT) * MAX_AD_BUF_SIZE);
        pthread_create(&thread, &attr, thread_save_data, NULL);
    }

    return NO_ERROR;
}

int StoreAllData(char *fileName)
{
    uint8_t cBuf[256];
    uint32_t iBuf[6];
    uint32_t iTemp = 0;

    DEBUG_INFO("StoreAllData");
    DEBUG_INFO("the start_index is %d", start_index);
    DEBUG_INFO("the end_index is %d", end_index);
    if (start_index > end_index)
    {
        for (iTemp = start_index; iTemp < MAX_AD_BUF_SIZE; iTemp++)
        {
            memcpy(iBuf, ad_temp_data[iTemp].data, sizeof(uint32_t) * 6);
            sprintf((char *)cBuf, "%d", iBuf[0]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[1]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[2]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[3]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[4]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[5]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            putString2Csv("", fileName, ECWM_OTHERLINE);
        }
        for (iTemp = 0; iTemp <= end_index; iTemp++)
        {
            memcpy(iBuf, ad_temp_data[iTemp].data, sizeof(uint32_t) * 6);
            sprintf((char *)cBuf, "%d", iBuf[0]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[1]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[2]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[3]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[4]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            sprintf((char *)cBuf, "%d", iBuf[5]);
            putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
            putString2Csv("", fileName, ECWM_OTHERLINE);
        }
    }

    for (iTemp = start_index; iTemp <= end_index; iTemp++)
    {
        memcpy(iBuf, ad_temp_data[iTemp].data, sizeof(uint32_t) * 6);
        sprintf((char *)cBuf, "%d", iBuf[0]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        sprintf((char *)cBuf, "%d", iBuf[1]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        sprintf((char *)cBuf, "%d", iBuf[2]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        sprintf((char *)cBuf, "%d", iBuf[3]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        sprintf((char *)cBuf, "%d", iBuf[4]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        sprintf((char *)cBuf, "%d", iBuf[5]);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        putString2Csv("", fileName, ECWM_OTHERLINE);
    }
    free(ad_temp_data);
    return NO_ERROR;
}

int GetRawData(int milisec, int beforesec, char *fileName)
{
    uint8_t ch;
    // uint8_t cBuf[256];
    uint8_t cName[256] = {"V(high)AD Data,I(high)AD Data,P(high)AD Data,V(low)AD Data,I(low)AD Data,P(low)AD Data"};
    time_t timep;
    struct tm *p;
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    // uint32_t iTemp = 0;
    uint32_t iCount = 1;
    uint32_t timeuse = 0;
    uint32_t iBuf[256];
    FILE *tempFp = NULL;
    // unsigned long long reg_VirthBaseAddr;
    long long us_time = 0;
    long long past_time = 0;
    struct timeval start_tv;
    struct timeval end_tv;
    // struct timeval tresult;
    // uint32_t timeu[2] = {0};

    /* judge the parameters */
    if (NULL == fileName)
    {
        printf("the name of the file is NULL\n");
        return PARAM_ERROR;
    }
    if ((MIN_TIME_RANGE > milisec) || (MAX_TIME_RANGE < milisec))
    {
        printf("the milisec is not in the range\n");
        return PARAM_ERROR;
    }
    if ((0 > beforesec) || (MAX_TIME_RANGE < beforesec))
    {
        printf("the beforesec is not in the range\n");
        return PARAM_ERROR;
    }

    time(&timep);
    p = localtime(&timep);
    iBuf[0] = 1900 + p->tm_year;
    iBuf[1] = 1 + p->tm_mon;
    iBuf[2] = p->tm_mday;
    iBuf[3] = iCount;

    DEBUG_INFO("judge the file is whether exist");
    iRet = access(TEMP_FILE_NAME, 0);
    DEBUG_INFO("the iRet is %d", iRet);
    DEBUG_INFO("judge successfully");
    if (0 == iRet)
    {
        /* in order to rename the file, judge there is how much csv file */
        DEBUG_INFO("open the file");
        tempFp = fopen(TEMP_FILE_NAME, "rb");
        if (NULL == tempFp)
        {
            // fclose(tempFp);
            return OPEN_ERROR;
        }
        DEBUG_INFO("start to read");
        // fwrite(&iCount, sizeof(uint32_t), 1,tempFp);
        fseek(tempFp, 0, SEEK_SET);
        ch = fread(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
        DEBUG_INFO("ch = %d", ch);
        DEBUG_INFO("the iBuf[0] is %d", iBuf[0]);
        DEBUG_INFO("the iBuf[1] is %d", iBuf[1]);
        DEBUG_INFO("the iBuf[2] is %d", iBuf[2]);
        DEBUG_INFO("the iBuf[3] is %d", iBuf[3]);
        iCount = iBuf[3];
        if (ch != 0)
        {
            iCount++;
        }

        if (MAX_FILE_NUM == iCount)
        {
            iCount = 1;
        }
        if ((iBuf[0] != (1900 + p->tm_year)) || (iBuf[1] != (1 + p->tm_mon)) || (iBuf[2] != p->tm_mday))
        {
            iCount = 1;
        }
        fclose(tempFp);
    }
    DEBUG_INFO("open the file");
    tempFp = fopen(TEMP_FILE_NAME, "wb+");
    if (tempFp == NULL)
    {
        return OPEN_ERROR;
    }
    iBuf[0] = 1900 + p->tm_year;
    iBuf[1] = 1 + p->tm_mon;
    iBuf[2] = p->tm_mday;
    iBuf[3] = iCount;
    fseek(tempFp, 0, SEEK_SET);
    fwrite(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
    fseek(tempFp, 0, SEEK_SET);
    fread(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
    DEBUG_INFO("the iBuf[0] is %d", iBuf[0]);
    DEBUG_INFO("the iBuf[1] is %d", iBuf[1]);
    DEBUG_INFO("the iBuf[2] is %d", iBuf[2]);
    DEBUG_INFO("the iBuf[3] is %d", iBuf[3]);
    fclose(tempFp);

    sprintf(fileName, "%d%02d%02d%02d%02d%02d_%03d.csv", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec, iCount);
    putString2Csv((char *)cName, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    //…calculating…
    AutoInitReg(8);
    // mem_mmap(0x40000000, REG_SIZE, &reg_VirthBaseAddr);

    gettimeofday(&start_tv, NULL);
    printf("start_time:%ld\n", start_tv.tv_sec * 1000000 + start_tv.tv_usec);
    us_time = (long long)start_tv.tv_sec * (long long)1000000 + (long long)start_tv.tv_usec;
    past_time = us_time - (beforesec * 1000);
    DEBUG_INFO("past time is %lld\n", past_time);
    // if (0 != beforesec)
    // {
    do
    {
        gettimeofday(&end_tv, NULL);
        // printf("current_time:%ld\n", end_tv.tv_sec * 1000000 + end_tv.tv_usec);
        // us_time = 1000000 * (end_tv.tv_sec - start_tv.tv_sec) + end_tv.tv_usec - start_tv.tv_usec;
        // printf("time: %d us\n", us_time);
        timeuse = (end_tv.tv_sec - start_tv.tv_sec) * 1000000 + end_tv.tv_usec - start_tv.tv_usec;
        // timeu[0] += timeuse;
        // printf("signale leakage's time: %lldus\n", timeuse);
    } while (timeuse < (milisec - beforesec) * 1000);

    for (int i = 0; i < MAX_AD_BUF_SIZE; i++)
    {
        if (past_time <= ad_temp_data[i].now_time)
        {
            DEBUG_INFO("the num is %d", i);
            DEBUG_INFO("the time is %lld", ad_temp_data[i].now_time);
            if (0 == i)
            {
                for (int j = 999999; j >= 0; j--)
                {
                    if (past_time >= ad_temp_data[j].now_time)
                    {
                        start_index = j;
                    }
                    break;
                }
            }
            else
            {
                start_index = i;
            }
            break;
        }
    }
    Store_Past_Data_Flag = FALSE;
    StoreAllData(fileName);
    Store_Past_Data_Flag = TRUE;
    StoreData(Store_Past_Data_Flag);

    return NO_ERROR;
}

int GetStableRawDate(int recipeNum, int stepNum, char *fileName)
{
    uint32_t iValue;
    // uint32_t iRet = 0;
    uint32_t iCount = 1;
    // FILE *tempFp = NULL;
    uint8_t cBuf[256];
    // uint8_t ch;
    uint8_t cName[256] = {"V(high)AD Data,I(high)AD Data,P(high)AD Data,V(low)AD Data,I(low)AD Data,P(low)AD Data"};
    time_t timep;
    struct tm *p;
    unsigned long long reg_VirthBaseAddr;
    Store_Data_Flag = TRUE;

    /* judge the parameters */
    if (NULL == fileName)
    {
        printf("the name of the file is NULL\n");
        return PARAM_ERROR;
    }
    if ((MIN_RECIPENUM > recipeNum) || (MAX_RECIPENUM < recipeNum))
    {
        printf("the num of recipe num is not in the range\n");
        return PARAM_ERROR;
    }

    time(&timep);
    p = localtime(&timep);

    sprintf(fileName, "RawData_%d%02d%02d%02d%02d%02d_%05d_%03d.csv", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec, recipeNum, stepNum);
    putString2Csv((char *)cName, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);

    AutoInitReg(8);
    mem_mmap(DATA_START_ADDR, REG_SIZE, &reg_VirthBaseAddr);

    DEBUG_INFO("-DDR Read-----------------");
    for (iCount = 0; iCount < (recipeNum * 6); iCount++)
    {
        if (0 == (iCount % 6))
        {
            DEBUG_INFO("-Data %d--------------", (iCount / 6));
        }
        GetRegister(reg_VirthBaseAddr, iCount * 4, (int *)&iValue);
        sprintf((char *)cBuf, "%d", iValue);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        DEBUG_INFO("the val of 0x%08x is 0x%08x", (DATA_START_ADDR + (iCount * 4)), iValue);

        if (0 == ((iCount + 1) % 6))
        {
            putString2Csv("", fileName, ECWM_OTHERLINE);
        }
    }
    mem_unmap(reg_VirthBaseAddr, REG_SIZE);
    Store_Data_Flag = FALSE;
    return NO_ERROR;
}

int GetAdcRawData(int count, char *fileName)
{
    uint32_t iValue;
    uint32_t iRet = 0;
    uint32_t iCount = 1;
    uint32_t iBuf[256];
    uint8_t cName[256] = {"V(high)AD Data,I(high)AD Data,P(high)AD Data,V(low)AD Data,I(low)AD Data,P(low)AD Data"};
    FILE *tempFp = NULL;
    uint8_t cBuf[256];
    uint8_t ch;
    time_t timep;
    struct tm *p;
    unsigned long long reg_VirthBaseAddr;
    Store_Data_Flag = TRUE;

    /* judge the parameters */
    if (NULL == fileName)
    {
        printf("the name of the file is NULL\n");
        return PARAM_ERROR;
    }
    if ((MIN_COUNT > count) || (MAX_COUNT < count))
    {
        printf("the num of data is not in the range\n");
        return PARAM_ERROR;
    }

    time(&timep);
    p = localtime(&timep);
    iBuf[0] = 1900 + p->tm_year;
    iBuf[1] = 1 + p->tm_mon;
    iBuf[2] = p->tm_mday;
    iBuf[3] = iCount;

    DEBUG_INFO("judge the file is whether exist");
    iRet = access(TEMP_FILE_NAME, 0);
    DEBUG_INFO("the iRet is %d", iRet);
    DEBUG_INFO("judge successfully");
    if (0 == iRet)
    {
        /* in order to rename the file, judge there is how much csv file */
        DEBUG_INFO("open the file");
        tempFp = fopen(TEMP_FILE_NAME, "rb");
        if (NULL == tempFp)
        {
            // fclose(tempFp);
            return OPEN_ERROR;
        }
        DEBUG_INFO("start to read");
        // fwrite(&iCount, sizeof(uint32_t), 1,tempFp);
        fseek(tempFp, 0, SEEK_SET);
        ch = fread(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
        DEBUG_INFO("ch = %d", ch);
        DEBUG_INFO("the iBuf[0] is %d", iBuf[0]);
        DEBUG_INFO("the iBuf[1] is %d", iBuf[1]);
        DEBUG_INFO("the iBuf[2] is %d", iBuf[2]);
        DEBUG_INFO("the iBuf[3] is %d", iBuf[3]);
        iCount = iBuf[3];
        if (ch != 0)
        {
            iCount++;
        }

        if (MAX_FILE_NUM == iCount)
        {
            iCount = 1;
        }
        if ((iBuf[0] != (1900 + p->tm_year)) || (iBuf[1] != (1 + p->tm_mon)) || (iBuf[2] != p->tm_mday))
        {
            iCount = 1;
        }
        fclose(tempFp);
    }
    DEBUG_INFO("open the file");
    tempFp = fopen(TEMP_FILE_NAME, "wb+");
    if(tempFp == NULL)
    {
        return OPEN_ERROR;
    }
    iBuf[0] = 1900 + p->tm_year;
    iBuf[1] = 1 + p->tm_mon;
    iBuf[2] = p->tm_mday;
    iBuf[3] = iCount;
    fseek(tempFp, 0, SEEK_SET);
    fwrite(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
    fseek(tempFp, 0, SEEK_SET);
    fread(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
    DEBUG_INFO("the iBuf[0] is %d", iBuf[0]);
    DEBUG_INFO("the iBuf[1] is %d", iBuf[1]);
    DEBUG_INFO("the iBuf[2] is %d", iBuf[2]);
    DEBUG_INFO("the iBuf[3] is %d", iBuf[3]);
    fclose(tempFp);

    sprintf(fileName, "AdcRawData_%d%02d%02d%02d%02d%02d_%03d.csv", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec, iCount);
    putString2Csv((char *)cName, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);

    AutoInitReg(8);
    DEBUG_INFO("mem_map 0x40000000");
    mem_mmap(DATA_START_ADDR, MAX_AD_OFFSET, &reg_VirthBaseAddr);

    DEBUG_INFO("-DDR Read-----------------");
    for (iCount = 0; iCount < (count * 6); iCount++)
    {
        if (0 == (iCount % 6))
        {
            DEBUG_INFO("-Data %d--------------", (iCount / 6));
        }
        GetRegister(reg_VirthBaseAddr, iCount * 4, (int *)&iValue);
        sprintf((char *)cBuf, "%d", iValue);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        DEBUG_INFO("the val of 0x%08x is 0x%08x", (DATA_START_ADDR + (iCount * 4)), iValue);

        if (0 == ((iCount + 1) % 6))
        {
            putString2Csv("", fileName, ECWM_OTHERLINE);
        }
    }
    mem_unmap(reg_VirthBaseAddr, MAX_AD_OFFSET);
    Store_Data_Flag = FALSE;
    return NO_ERROR;
}

int DeleteAllRawData()
{
    uint32_t iCount = 0;
    uint32_t iTemp = 0;
    uint32_t iRet = 0;
    uint32_t iBuf[256];
    uint8_t cmd[256];
    FILE *tempFp = NULL;

    if (Store_Data_Flag == TRUE)
    {
        DEBUG_INFO("judge the file is whether exist");
        iRet = access(TEMP_FILE_NAME, 0);
        DEBUG_INFO("the iRet is %d", iRet);
        DEBUG_INFO("judge successfully");
        if (0 == iRet)
        {
            /* in order to rename the file, judge there is how much csv file */
            DEBUG_INFO("open the file");
            tempFp = fopen(TEMP_FILE_NAME, "rb");
            if (NULL == tempFp)
            {
                // fclose(tempFp);
                return OPEN_ERROR;
            }
            DEBUG_INFO("start to read");
            // fwrite(&iCount, sizeof(uint32_t), 1,tempFp);
            fseek(tempFp, 0, SEEK_SET);
            fread(iBuf, sizeof(uint32_t) * 4, 1, tempFp);
            DEBUG_INFO("the iBuf[0] is %d", iBuf[0]);
            DEBUG_INFO("the iBuf[1] is %d", iBuf[1]);
            DEBUG_INFO("the iBuf[2] is %d", iBuf[2]);
            DEBUG_INFO("the iBuf[3] is %d", iBuf[3]);
            iCount = iBuf[3];
            fclose(tempFp);
        }
        for (iTemp = 0; iTemp < 1000; iTemp++)
        {
            if (iCount != iTemp)
            {
                sprintf((char *)cmd, "rm -rf *%03d.csv", iTemp);
                system((char *)cmd);
            }
        }
    }
    else
    {
        system("rm -rf *.csv");
        sprintf((char *)cmd, "rm -rf %s", TEMP_FILE_NAME);
        system((char *)cmd);
    }

    return NO_ERROR;
}

int get_system_tf_free(double *free)
{
    if (free == NULL)
    {
        return PARAM_ERROR;
    }
    struct statfs diskInfo;
    statfs("/", &diskInfo);
    unsigned long long totalBlocks = diskInfo.f_bsize;
    unsigned long long freeDisk = diskInfo.f_bfree * totalBlocks;

    *free = freeDisk;
    return NO_ERROR;
}

int FreeUpStrageInRawData()
{
    double freeSpace;
    uint8_t cmd[256];
    FILE *tempFp = NULL;

    get_system_tf_free(&freeSpace);
    printf("the free space is %f\n", freeSpace);
    if (freeSpace <= MIN_FREE_SPACE)
    {
        tempFp = fopen(BASH_FILE_NAME, "w+");
        if (tempFp == NULL)
        {
            return OPEN_ERROR;
        }
        fputs("OldFile=$(ls -rt *.csv|head -1)\nrm -f $OldFile", tempFp);
        fclose(tempFp);
        sprintf((char *)cmd, "chmod 777 %s", BASH_FILE_NAME);
        system((char *)cmd);
        sprintf((char *)cmd, "./%s", BASH_FILE_NAME);
        system((char *)cmd);
    }

    return NO_ERROR;
}
