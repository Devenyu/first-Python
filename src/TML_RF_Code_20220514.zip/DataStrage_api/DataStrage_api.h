/*******************************************************************************
**	File name		: DataStorage_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

#ifndef __DATASTORAGE_API_H__
#define __DATASTORAGE_API_H__

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdint.h>
#include <sys/vfs.h>
#include <pthread.h>
#include "common.h"

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define BASEADDR 0x80000000
#define REG_SIZE 0x7FFF
#define DATA_START_ADDR 0x60000000
#define DATA_END_ADDR 0x6ff00000
#define TEMP_FILE_NAME ".temp.bin"
#define BASH_FILE_NAME "free.sh"
#define MAX_FILE_NUM 999
#define MAX_COUNT 20000
#define MIN_COUNT 1
#define MIN_TIME_RANGE 1
#define MAX_TIME_RANGE 1000
#define MAX_RECIPENUM 20000
#define MIN_RECIPENUM 100
#define MIN_FREE_SPACE 4903874816
#define FALSE 0
#define TRUE 1


/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
enum  eCsvWriteMode
{
	ECWM_ONELINE=1,
	ECWM_OTHERLINE,
};

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int putString2Csv(char *str, char *filename, int mode);
extern int SetRegister(unsigned long long reg_VirthBaseAddr, int offset, int val);
extern int GetRegister(unsigned long long reg_VirthBaseAddr, int offset, int *val);
extern int AutoInitReg(int mode);
extern int StoreData(_Bool flag);
extern int GetRawData(int milisec, int beforesec, char *fileName);
extern int GetStableRawDate(int recipeNum, int stepNum, char *fileName);
extern int GetAdcRawData(int count, char *fileName);
extern int DeleteAllRawData();
extern int FreeUpStrageInRawData();

#endif
