/*******************************************************************************
**	File name		: spi.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include "../include/spi.h"
#include "../include/Err32_def_api.h"

#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>


//======================================================================
// Variable Definition
//======================================================================

SPI_InitTypeDef SPI_InitStruct;
static uint8_t bits = 8;
struct spi_ioc_transfer spi_ioc_transfer_InitStruct;
static int SPI_SetBitOrder(SPIBitOrder Order);
static int SPI_SetSpeed(uint32_t speed);
static int SPI_Mode(SPIMode mode);
static int SPI_ChipSelect(SPIChipSelect CS_Mode);
static void SPI_SetDataInterval(uint16_t us);
// static int SPI_SetBusMode(BusMode mode);


/*************************************************************************************************
*Function prototype :   int SPI_SetBitOrder(SPIBitOrder Order)
*Function summary   :  	Sets the SPI bit order
*Function name      :   SPI_SetBitOrder

*arguments          ：	Order	      [input]      Big and small end settings
                    
*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_ChipSelect(SPI_BIT_ORDER_LSBFIRST)        
****************************************************************************************************/

static int SPI_SetBitOrder(SPIBitOrder Order)
{

    int ret = 0;

    if (Order == SPI_BIT_ORDER_LSBFIRST)
    {
        SPI_InitStruct.mode |= SPI_LSB_FIRST;
    }
    else if (Order == SPI_BIT_ORDER_MSBFIRST)
    {
        SPI_InitStruct.mode &= ~SPI_LSB_FIRST;
    }

    // printf("SPI_InitStruct.mode = 0x%02x\r\n", SPI_InitStruct.mode);
    ret = ioctl(SPI_InitStruct.fd, SPI_IOC_WR_MODE, &SPI_InitStruct.mode);

    if (ret < NO_ERROR)
    {
        printf("can't set spi SPI_LSB_FIRST\r\n");
        return GENERAL_ERROR;
    }
    return NO_ERROR;
}

/*************************************************************************************************
*Function prototype :   void SPI_Init(char *SPI_device, SPIMode mode, uint32_t speed)
*Function summary   :  	Initialize SPI
*Function name      :   SPI_Init

*arguments          :   SPI_device    [input]       enter spi device name
                    ：  mode          [input]       mode of spi 
                    ：	speed	      [input]       speed of spi

*return value       :   NONE

*example            :   SPI_Init("/dev/spidev4.0",SPI_MODE0,1000000)        
****************************************************************************************************/

int SPI_Init(char *SPI_device, SPIMode mode, uint32_t speed)
{
    int ret = 0;
    SPI_InitStruct.mode = 0;

    if ((SPI_InitStruct.fd = open(SPI_device, O_RDWR)) < NO_ERROR)
    {
        printf("Failed to open SPI device.\n");
        return SPI_OPEN_ERROR;
    }
    else
    {
        // printf("open : %s\r\n", SPI_device);
    }

    ret = ioctl(SPI_InitStruct.fd, SPI_IOC_WR_BITS_PER_WORD, &bits);

    if (ret < NO_ERROR)
    {
        printf("can't set bits per word\r\n");
        return SPI_WRITE_ERROR;
    }

    ret = ioctl(SPI_InitStruct.fd, SPI_IOC_RD_BITS_PER_WORD, &bits);

    if (ret < NO_ERROR)
    {
        printf("can't get bits per word\r\n");
        return SPI_READ_ERROR;
    }

    SPI_Mode(mode);
    SPI_ChipSelect(SPI_CS_Mode_HIGH);
    SPI_SetSpeed(speed);
    SPI_SetDataInterval(0);
    SPI_SetBitOrder(SPI_BIT_ORDER_MSBFIRST);
    return NO_ERROR;
}

/*************************************************************************************************
*Function prototype :   void SPI_End(void)
*Function summary   :  	SPI device End
*Function name      :   SPI_End

*arguments          :   NONE

*return value       :   NONE

*example            :   SPI_End()       

****************************************************************************************************/

int SPI_End(void)
{
    SPI_InitStruct.mode = 0;

    if (close(SPI_InitStruct.fd) != 0)
    {
        printf("Failed to close SPI device\r\n");
        perror("Failed to close SPI device.\n");
        return SPI_CLOSE_ERROR;
    }
    return NO_ERROR;
}

/*************************************************************************************************
*Function prototype :   int SPI_SetSpeed(uint32_t speed)
*Function summary   :  	Set SPI speed
*Function name      :   SPI_SetSpeed

*arguments          ：	speed	      [input]       speed of spi
                    
*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_SetSpeed(5000000)        
****************************************************************************************************/

static int SPI_SetSpeed(uint32_t speed)
{
    uint32_t speed1 = SPI_InitStruct.speed;

    SPI_InitStruct.speed = speed;

    //Write speed
    if (ioctl(SPI_InitStruct.fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed) < NO_ERROR)
    {
        printf("can't set max speed hz\r\n");
        SPI_InitStruct.speed = speed1; //Setting failure rate unchanged
        return GENERAL_ERROR;
    }

    //Read the speed of just writing
    if (ioctl(SPI_InitStruct.fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed) < NO_ERROR)
    {
        printf("can't get max speed hz\r\n");
        SPI_InitStruct.speed = speed1; //Setting failure rate unchanged
        return GENERAL_ERROR;
    }
    SPI_InitStruct.speed = speed;
    spi_ioc_transfer_InitStruct.speed_hz = SPI_InitStruct.speed;
    return NO_ERROR;
}

/*************************************************************************************************
*Function prototype :   int SPI_Mode(SPIMode mode)
*Function summary   :  	Set SPI Mode
*Function name      :   SPI_Mode

*arguments          ：	mode	      [input]       speed of mode
                    
*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_Mode(SPI_MODE0)        
****************************************************************************************************/

static int SPI_Mode(SPIMode mode)
{
    SPI_InitStruct.mode &= 0xfC; //Clear low 2 digits
    SPI_InitStruct.mode |= mode; //Setting mode

    //Write device
    if (ioctl(SPI_InitStruct.fd, SPI_IOC_WR_MODE, &SPI_InitStruct.mode) == -1)
    {
        printf("can't set spi mode\r\n");
        return GENERAL_ERROR;
    }
    return NO_ERROR;
}


/*************************************************************************************************
*Function prototype :   int SPI_ChipSelect(SPIChipSelect CS_Mode)
*Function summary   :  	Chip Select
*Function name      :   SPI_ChipSelect

*arguments          ：	CS_Mode	      [input]       cs mode
                    
*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_ChipSelect(SPI_CS_Mode_HIGH)        
****************************************************************************************************/

static int SPI_ChipSelect(SPIChipSelect CS_Mode)
{
    if (CS_Mode == SPI_CS_Mode_HIGH)
    {
        SPI_InitStruct.mode |= SPI_CS_HIGH;
        SPI_InitStruct.mode &= ~SPI_NO_CS;
        // printf("CS HIGH \r\n");
    }
    else if (CS_Mode == SPI_CS_Mode_LOW)
    {
        SPI_InitStruct.mode &= ~SPI_CS_HIGH;
        SPI_InitStruct.mode &= ~SPI_NO_CS;
    }
    else if (CS_Mode == SPI_CS_Mode_NONE)
    {
        SPI_InitStruct.mode |= SPI_NO_CS;
    }

    if (ioctl(SPI_InitStruct.fd, SPI_IOC_WR_MODE, &SPI_InitStruct.mode) == -1)
    {
        printf("can't set spi mode\r\n");
        return GENERAL_ERROR;
    }
    return NO_ERROR;
}



/*************************************************************************************************
*Function prototype :   void SPI_SetDataInterval(uint16_t us)
*Function summary   :  	Time interval after transmission of one byte during continuous transmission   
*Function name      :   SPI_SetDataInterval

*arguments          ：	us	      [input]    transmission time
                    
*return value       :   NONE

*example            :   SPI_ChipSelect(SPI_4WIRE_Mode)        
****************************************************************************************************/

static void SPI_SetDataInterval(uint16_t us)
{
    SPI_InitStruct.delay = us;
    spi_ioc_transfer_InitStruct.delay_usecs = SPI_InitStruct.delay;
}

/*******************************************************************************************************
*Function prototype :   int SPI_SendAndReceive(const uint8_t *txBuf, uint8_t *rxBuf, uint32_t len)
*Function summary   :  	Receive and send data synchronously   
*Function name      :   SPI_SendAndReceive

*arguments          ：	txBuf	      [input]    first address of sending data
                    :   rxBuf         [output]   receive data buffer
                    :   len           [input]    data length

*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_SendAndReceive(txbuff,rxbuff,10)        
***********************************************************************************************************/

int SPI_SendAndReceive(const uint8_t *txBuf, uint8_t *rxBuf, uint32_t len)
{
    spi_ioc_transfer_InitStruct.len = len;
    spi_ioc_transfer_InitStruct.tx_buf = (unsigned long)txBuf;
    spi_ioc_transfer_InitStruct.rx_buf = (unsigned long)rxBuf;

    //ioctl Operation, transmission of data
    if (ioctl(SPI_InitStruct.fd, SPI_IOC_MESSAGE(1), &spi_ioc_transfer_InitStruct) < 1)
    {
        printf("can't send spi message\r\n");
        return GENERAL_ERROR;
    }
    return NO_ERROR;
}
/*******************************************************************************************************
*Function prototype :   int SPI_SendData(uint8_t *txBuf,  int32_t len)
*Function summary   :  	send data    
*Function name      :   SPI_SendData

*arguments          ：	txBuf	      [input]    first address of sending data
                    :   len           [input]    data length

*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_SendData(txbuff,10)        
***********************************************************************************************************/

int SPI_SendData(uint8_t *txBuf, int32_t len)
{
    int ret = 0;

    ret = write(SPI_InitStruct.fd, txBuf, len);

    if (ret < NO_ERROR)
    {
        printf("can't set spi SPI_LSB_FIRST\r\n");
        return SPI_WRITE_ERROR;
    }
    return NO_ERROR;
}

/*******************************************************************************************************
*Function prototype :   int SPI_ReceiveData(uint8_t *txBuf,  int32_t len)
*Function summary   :  	send data    
*Function name      :   SPI_ReceiveData

*arguments          ：	txBuf	      [input]    first address of sending data
                    :   len           [input]    data length

*return value       :   1       Return 1 success
                    :   -1      Return -1 failed

*example            :   SPI_ReceiveData(txbuff,rxbuff,10)        
***********************************************************************************************************/

int SPI_ReceiveData(uint8_t *rxBuf, int32_t len)
{
    int ret = 0;

    ret = read(SPI_InitStruct.fd, rxBuf, len);

    if (ret < NO_ERROR)
    {
        printf("can't set spi SPI_LSB_FIRST\r\n");
        return SPI_READ_ERROR;
    }
    return NO_ERROR;
}

void Delay_Ms(unsigned int i)
{
	usleep(1000 * i);
}

uint8_t Get_CheckSum(uint8_t *buff , int len)
{
    // int len = 11;/*Records the length of the buff*/
	int sum = 0;/*Record the sum of hexadecimal sums*/
	uint8_t checksum ;/*Define a string to store CC*/
	short int right;/*Define a variable of two bytes length to store the low eight bits*/

	/*Calculate the checksum*/
	for (int i = 0; i < len; i++)
	{
		sum = sum+buff[i];
	}

	right = sum & 0x00ff; // Take eight right
	right = 0xFF - right + 0x01;
	right = right & 0x00ff; // Take eight right
	checksum = right;
    return checksum;
}
