/*******************************************************************************
**	File name		: Communication_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

#ifndef __COMMUNICATION_API_H__
#define __COMMUNICATION_API_H__

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdint.h>
#include "common.h"

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/

#define SPI_DEV_ECAT "/dev/spidev3.0"
#define CAN_DEV_DNET "can0"
#define SPI_SPEED 100000000
#define PDO_TX_DATASIZE 12
#define SDO_TX_DATASIZE 12
#define FOE_TX_DATASIZE 12
#define DIPSW_TX_DATASIZE 12
#define DIPSW_RX_DATASIZE 8
#define FOE_RX_START_DATASIZE 10
#define FOE_RX_DATA_DATASIZE 24
#define PDO_RX_DATASIZE 8
#define PDO_TX_READS_DATA_DATASIZE 8
#define SDO_RX_DATASIZE 8
#define CC_LENGTH 10
#define CC_ERROR_LENGTH 6
#define FALSE 0
#define TRUE 1
#define DELAY_TIME 100
#define SPI_HEADER 0x7AA7
#define PDO_READ_CMD 0x01
#define SDO_READ_CMD 0x06
#define DIPSW_READ_CMD 0x09
#define PDO_WRITE_START_CMD 0x02
#define PDO_WRITE_DATA_CMD 0x03
#define PDO_WRITE_FINISH_FLAG 0x01
#define FOE_READ_START_CMD 0x04
#define FOE_READ_DATA_CMD 0x05
#define SDO_READ_CMD 0x06
#define UNDETERMINATE 0x0
#define SPI_TRAILER 0x04
#define NO_DATA 0x00
#define PDO_READ_DATASIZE 24
#define SDO_READ_DATASIZE 24
#define SDO_WRITE_START_CMD 0x07
#define SDO_WRITE_DATA_CMD 0x08
#define SDO_WRITE_FINISH_FLAG 0x01
#define SDO_TX_READS_DATA_DATASIZE 8
#define PDO_WRITE_DATASIZE 20
#define SDO_WRITE_DATASIZE 20
#define PDO_READ_SUCCESS_FLAG 0x01
#define SDO_READ_SUCCESS_FLAG 0x01
#define PDO_READ_FAIL_FLAG 0x00
#define WRITE_CMD 1
#define READ_CMD 0
#define MAXSIZE 90
#define ERROR_DATASIZE 8
#define ERROR_SEND_CMD 0x00
#define ERROR_DEALY_TIME 5
#define ERROR_TIMES 20
#define PDO_TYPE 0
#define SDO_TYPE 1
#define INSTANCE_REQ_ID 4
#define INSTANCE_ACK_ID 5
#define GROUP3_UCMM_EXPLICIT_REQ 0x1E
#define GROUP3_UCMM_EXPLICIT_ACK 0x1D
#define UCMM_EXPLICIT_REQ_DATASIZE 0x04
#define UCMM_EXPLICIT_CLOSE_ACK_DATASIZE 0x02
#define DNET_READ_SEGMENT_REQ_DATASIZE 0x08
#define DNET_READ_SEGMENT_ACK_DATASIZE 0x03
#define DNET_WRITE_SEGMENT_REQ_DATASIZE 0x08
#define DNET_WRITE_SEGMENT_ACK_DATASIZE 0x03
#define DNET_POLLING_SEGMENT_ACK_DATASIZE 0x08
#define UCMM_EXPLICIT_ACK_DATASIZE 0x03
#define OPEN_EXPLICIT_CONNECT_REQ_SERVICE_ID 0x4B
#define OPEN_EXPLICIT_CONNECT_SCK_SERVICE_ID 0xCB
#define GET_ATTRIBUTE_SINGLE_REQ_SERVICE_ID 0x0E
#define GET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID 0x8E
#define SET_ATTRIBUTE_SINGLE_REQ_SERVICE_ID 0x10
#define SET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID 0x90
#define CLOSE_EXPLICIT_CONNECT_REQ_SERVICE_ID 0x4C
#define CLOSE_EXPLICIT_CONNECT_SCK_SERVICE_ID 0xCC
#define POLLING_SERVICE_ID 0x1C
#define ERROR_SERVICE_ID 0x14
#define INVALID_ATTRIBUTE_ACK 0x09
#define DEVICENET_MES_STRUCT_8_8 0x00
#define DEVICENET_MES_STRUCT_8_16 0x01
#define DEVICENET_MES_STRUCT_16_16 0x02
#define DEVICENET_MES_STRUCT_16_8 0x03
#define DEVICENET_FIRST_SEGMENT 0x00
#define DEVICENET_MIDDLE_SEGMENT 0x01
#define DEVICENET_END_SEGMENT 0x02
#define DEVICENET_ACK_SEGMENT 0x03
#define DEVICENET_ACK_SEGMENT_SUCCESS 0x00
#define DEVICENET_GROUP_1 0x01
#define DEVICENET_GROUP_2 0x02
#define DEVICENET_GROUP_3 0x03
#define DEVICENET_BASE_ADDR 0x51600000
#define DEVICENET_BASE_SIZE 0xB8000
#define DEVICENET_DATA_SIZE 0x10
#define DEVICENET_POLLING_BLOCK_OFFSET 33
#define DEVICENET_POLLING_DATASIZE 136
#define DEVICENET_IDENTIFY_EEPROM_ADDR 0x00000020
#define DEVICENET_IDENTIFY_EEPROM_DATASIZE 14
#define DEVICENET_COMM_EEPROM_ADDR 0x00000060
#define DEVICENET_COMM_EEPROM_DATASIZE 9
#define DEVICENET_DATASUM_SIZE_MAX 100
#define DEVICENET_DATASIZE_MAX 124
#define DNET_POLLING_REQ 1
#define DNET_CON_EXPLICIT_REQ 2
#define DNET_DISCON_EXPLICIT_REQ 3
#define DNET_SET_ATTRIBUTE_REQ 4
#define DNET_GET_ATTRIBUTE_REQ 5
/* DNet Status */
#define DNET_MSG_CONN_STATUS 0x01
#define DNET_POLLING_CONN_STATUS 0x02
#define DNET_MSG_POLL_CONN_STATUS 0x03
#define DNET_DISCONN_STATUS 0x00

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef union
{
    uint16_t datasize;
    uint16_t result;
    uint32_t foe_datasize;
} ADD_RES;

typedef struct
{
    uint16_t header;
    uint16_t cmd;
    ADD_RES address_result;
} RXBUFF_HEADER;

typedef struct
{
    uint32_t write_address;
    uint16_t write_datasize;
    uint32_t write_value[MAXSIZE];
    uint32_t read_address;
    uint16_t read_datasize;
    uint32_t read_value[MAXSIZE];
    uint8_t type;
} PDO_SDO_BUFFER;

typedef struct
{
    uint8_t serviceId;
    uint8_t classId;
    uint8_t instanceId;
    uint8_t attributeId;
    uint8_t address;
    uint8_t dataSize;
    uint8_t *val;
} DnetAccessObject;

typedef struct
{
    // uint8_t rev[16];
    uint8_t send[136];
    uint8_t d_msgId;
    uint8_t s_msgId;
    uint8_t s_macId;
} DnetPollingObject;

typedef struct
{
    int IdentifyObjectRevision;        // Identify Object Revision
    int Vendor;                        // Vendor
    int DeviceType;                    // Device type
    int ProductCode;                   // Product code
    int Revision;                      // Revision 1
    int Status;                        // Status
    int SerialNumber;                  // Serial number
    char ProductName[14];              // Product name F1T_VIMC
    int State;                         // State
    int ConfigurationConsistencyValue; // Configuration Consistency Value 1(未使用)
    int HeartbeatInterval;             // Heartbeat Interval 1(未使用)
} DnetIdentifyObject;

typedef struct
{
    int NodeAddress;              //現在有効なMac ID(ノードアドレス) 0～63から指定可能
    int BaudRate;                 //現在有効なBaud rate(125,250,500[kbps]から選択可能)   500
    int BusOffInterruption;       // Bus-off Interruption  0 (未使用)
    int BusOffCounter;            // Bus-off counter 0 (未使用)
    int AllocationInformation;    // Allocation information  0 (未使用)
    int NodeAddressSwitchChanged; // Mac ID switch changed   0 (未使用)
    int BaudRateSwitchChanged;    // Baud rate switch changed    0 (未使用)
    int NodeAddressSwitchValue;   // MAC ID switch value 0 (未使用)
    int BaudRateSwitchValue;      // Baud rate switch value  0 (未使用)
} DnetCommunicationSetting;

typedef struct Dnet_Access_Object
{
    uint8_t s_macId;
    uint8_t d_macId;
    uint8_t s_mesId;
    uint8_t groupId;
    uint8_t message_struct;
    uint8_t d_mesId;
    uint8_t serviceId;
    uint8_t classId;
    uint8_t attributeId;
    uint8_t instanceId;
    uint8_t msg_alloc;
    uint8_t index;
    uint8_t dataSize;
    uint8_t val[DEVICENET_DATASIZE_MAX];
} DnetCommObject;

typedef struct 
{
    uint8_t serviceId;
    uint8_t classId;
    uint8_t instanceId;
    uint8_t attributeId;
    uint8_t datasize;
    uint8_t data[DEVICENET_DATASIZE_MAX];
}DNET_DATA;

typedef struct 
{
    uint8_t serviceId;
    uint8_t classId;
    uint8_t instanceId;
    uint8_t attributeId;
    uint8_t connstatus;
}DNET_TEMP;

typedef enum 
{
    DNET_IDTY_MSG_ID_OBJ_REV = 0,
    DNET_IDTY_MSG_VENDOR_ID,
    DNET_IDTY_MSG_DEV_TYPE,
    DNET_IDTY_MSG_PRO_CODE,
    DNET_IDTY_MSG_REVISION,
    DNET_IDTY_MSG_STATUS,
    DNET_IDTY_MSG_SERIAL_NUM,
    DNET_IDTY_MSG_PRO_NAME,
    DNET_IDTY_MSG_STATE,
    DNET_IDTY_MSG_CONF_CONSIS_VAL,
    DNET_IDTY_MSG_HBEAT_INT,
    DNET_IDTY_MSG_MAC_ID,
    DNET_IDTY_MSG_BAUD_RATE,
    DNET_IDTY_MSG_BUS_OFF_ITR,
    DNET_IDTY_MSG_BUS_OFF_CONT,
    DNET_IDTY_MSG_ALLOC_INFOR,
    DNET_IDTY_MSG_MAC_ID_SW_CHANGED,
    DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED,
    DNET_IDTY_MSG_MAC_ID_SW_VAL,
    DNET_IDTY_MSG_BAUD_RATE_SW_VAL,
    DNET_EXP_MSG_MOD_NO,
    DNET_EXP_MSG_DISP_DET_INFOR_NO,
    DNET_EXP_MSG_TIME_SET,
    DNET_EXP_MSG_LF_RF_POW_UP_LM,
    DNET_EXP_MSG_LF_RF_POW_LW_LM,
    DNET_EXP_MSG_LF2_RF_POW_UP_LM,
    DNET_EXP_MSG_LF2_RF_POW_LW_LM,
    DNET_EXP_MSG_REC_INFOR,
    DNET_EXP_MSG_LF_RF_CAL_TAB,
    DNET_EXP_MSG_LF_RF2_CAL_TAB,
    DNET_EXP_MSG_SELF_CHE_STAR,
    DNET_EXP_MSG_SELF_CHE_ABT,
    DNET_EXP_MSG_LF_RF_HEAD_NUM,
    DNET_EXP_MSG_LF_RF2_HEAD_NUM,
    DNET_EXP_MSG_BRD_NUM,
    DNET_EXP_MSG_DIG_BRD_HW_VER,
    DNET_EXP_MSG_HW_BRD_HW_VER,
    DNET_EXP_MSG_FIRM_VER,
    DNET_EXP_MSG_FPGA_VER,
    DNET_EXP_MSG_BRD_CHECK_NUM1,
    DNET_EXP_MSG_BRD_CHECK_NUM2,
    DNET_EXP_MSG_TR_CHK_NUM,
    DNET_EXP_MSG_ERR_REQ,
    DNET_EXP_MSG_SELF_CALC_REQ,
    DNET_MSG_MAX_NUM

}DNET_ENUM;
/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int ExIoAreaRead(int Address, short DataSize, int *val);
extern int ExIoAreaWrite(int Address, short DataSize, int *val);
extern int ExIoAreaFoERead();
extern int DNetInit();
extern int DNetRead(DnetAccessObject *dneObject, DNET_ENUM dNetENum);
extern int DNetWrite(DnetAccessObject *dneObject, DNET_ENUM dNetENum);
extern int DNetPollingWrite(DnetPollingObject *dnePollingObject);
extern int DNetPollingRead(DnetPollingObject *dnePollingObject);
extern int DNetGetIdentifyParameter(DnetIdentifyObject *identifyParam);
extern int DNetSetIdentifyParameter(DnetIdentifyObject *identifyParam);
extern int DNetGetDnetParameter(DnetCommunicationSetting *dnetParam);
extern int DNetSetDnetParameter(DnetCommunicationSetting *dnetParam);
extern int DNetCommuThread(struct timeval *time);
extern int OrderSpecificData(int *Address, short *DataSize, int *val, char *type, int num, int cmd, PDO_SDO_BUFFER *pdo_sdo_buffer);
extern int GetExIoSpecificData(int num, int *val, PDO_SDO_BUFFER *pdo_sdo_buffer);
extern int SetExIoSpecificData(int num, PDO_SDO_BUFFER *pdo_sdo_buffer);
extern int ResetCommunication();
extern int ECAT_DipSwRead(uint16_t *value);

DNET_DATA gDNetData[DEVICENET_DATASUM_SIZE_MAX];

#endif
