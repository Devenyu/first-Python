/*******************************************************************************
**	File name		: Communication_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <sys/time.h>
#include <linux/can/raw.h>
#include <stdint.h>
#include <pthread.h>
#include <semaphore.h>

#include "Communication_api.h"
// #include "timer.h"
#include "mem_map.h"
#include "RF_list.h"
#include "eeprom_api.h"
#include "spi.h"
#include "Err32_def_api.h"

struct sockaddr_can addr;
struct ifreq ifr;
struct can_frame frame;
// static pthread_cond_t cond;
static pthread_mutex_t mutex;
_Bool DeviceNet_Init_Flag = FALSE;
_Bool DNET_Commu_Flag = FALSE;
_Bool DNET_Polliong_Flag = FALSE;
pthread_t DNET_thread;
struct timeval timeout;
long timeout_usec;
long timeout_sec;
/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] ExIoAreaRead

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int ExIoAreaRead(int Address, short DataSize, int *val)
{
    uint8_t txbuffer[PDO_TX_DATASIZE]; /* the  transfer data */
    uint8_t checksum;                  /* define a buffer to store the data which is used to calculate the checksum */
    // uint8_t rxbuffer[PDO_RX_DATASIZE + DataSize]; /* the  receive data */
    uint8_t *rxbuffer = NULL;  /* the  receive data */
    RXBUFF_HEADER *rx_pointer; /* define a struct pointer to analysis the receive data more quickly */
    uint16_t header = SPI_HEADER;
    uint16_t read_result = PDO_READ_SUCCESS_FLAG;
    uint16_t pdo_read_cmd = PDO_READ_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint8_t end = SPI_TRAILER;
    uint32_t pdo_read_list;
    uint8_t error_num = 0;
    uint8_t count = 0;
    uint8_t ret = 0;
    _Bool Serval_Read_Flag = FALSE;
    _Bool Receive_End_Flag = FALSE;
    _Bool pdo_rd_address_flag = FALSE;

    // printf("address: %x\n", Address);
    /* judge the validity of parameters */
    for (pdo_read_list = 0; pdo_read_list < readpdo_listnum; pdo_read_list++)
    {
        // printf("%x\n", RF_read_pdo_area[pdo_read_list].address);
        if (Address == RF_read_pdo_area[pdo_read_list].address)
        {
            pdo_rd_address_flag = TRUE;
        }

        if (pdo_rd_address_flag == TRUE)
        {
            if ((DataSize > RF_read_pdo_area[pdo_read_list].datasize) || (DataSize < 0))
            {
                printf("the datasize is not in the range\n");
                return PARAM_ERROR;
            }
        }
        if (pdo_rd_address_flag == TRUE)
            break;
    }
    if (FALSE == pdo_rd_address_flag)
    {
        printf("the address is wrong\n");
        return PARAM_ERROR;
    }
    if (NULL == val)
    {
        printf("the point is wrong\n");
        return PARAM_ERROR;
    }

    if (PDO_READ_DATASIZE > DataSize)
    {
        rxbuffer = (uint8_t *)malloc(PDO_RX_DATASIZE + DataSize + 1);
        if (rxbuffer == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
    }
    else
    {
        rxbuffer = (uint8_t *)malloc(PDO_RX_DATASIZE + PDO_READ_DATASIZE + 1);
        if (rxbuffer == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
        count = DataSize / PDO_READ_DATASIZE;
        if (0 != DataSize % PDO_READ_DATASIZE)
        {
            Receive_End_Flag = TRUE;
        }

        Serval_Read_Flag = TRUE;
    }

    /* intialize SPI */
    ret = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED); // ??
    if (NO_ERROR != ret)
    {
        SPI_End();
        free(rxbuffer);
        return ret;
    }

    while (ERROR_TIMES > error_num)
    {
        /* store the transfer data */
        memcpy(txbuffer, &header, sizeof(header));
        memcpy(&txbuffer[2], &pdo_read_cmd, sizeof(pdo_read_cmd));
        memcpy(&txbuffer[4], &Address, sizeof(Address));
        memcpy(&txbuffer[8], &DataSize, sizeof(DataSize));
        checksum = Get_CheckSum(txbuffer, CC_LENGTH);
        memcpy(&txbuffer[10], &checksum, sizeof(checksum));
        memcpy(&txbuffer[11], &end, sizeof(end));

        ret = SPI_SendData(txbuffer, PDO_TX_DATASIZE); /* transfer the buffer */
                                                       /////////////////////////
#if 1
        /* print the header of receiver */
        DEBUG_INFO("send:\n");
        for (int i = 0; i < PDO_TX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", txbuffer[i]);
        }
        printf("\n");
#endif
        if (NO_ERROR != ret)
        {
            SPI_End();
            free(rxbuffer);
            return ret;
        }

        usleep(DELAY_TIME); /* delay 62.5 us */

        if (TRUE != Serval_Read_Flag)
        {
            ret = SPI_ReceiveData(rxbuffer, PDO_RX_DATASIZE + DataSize); /* receive the header */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < PDO_RX_DATASIZE + DataSize; i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (pdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (DataSize != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + DataSize);

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[PDO_RX_DATASIZE + DataSize - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[PDO_RX_DATASIZE + DataSize - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                printf("output data\r\n");
                memcpy(val, rxbuffer + 6, DataSize);
                free(rxbuffer);
                SPI_End();
                return NO_ERROR;
            }
        }
        else
        {
            // rxbuffer = (uint8_t *)malloc(PDO_RX_DATASIZE + PDO_READ_DATASIZE);
            ret = SPI_ReceiveData(rxbuffer, PDO_RX_DATASIZE + PDO_READ_DATASIZE); /* receive the header */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < PDO_RX_DATASIZE + PDO_READ_DATASIZE; i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif
            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (pdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (PDO_READ_DATASIZE != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + PDO_READ_DATASIZE);

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[PDO_RX_DATASIZE + PDO_READ_DATASIZE - 2])
            {
                printf("the checksum is invalid");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[PDO_RX_DATASIZE + PDO_READ_DATASIZE - 1])
            {
                printf("the end is wrong");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                memcpy(val, rxbuffer + 6, PDO_READ_DATASIZE);
                memset(rxbuffer, 0, PDO_RX_DATASIZE + PDO_READ_DATASIZE);
            }

            for (int i = 0; i < count - 1; i++)
            {
                /* store the transfer data */
                memcpy(txbuffer, &header, sizeof(header));
                memcpy(&txbuffer[2], &pdo_read_cmd, sizeof(pdo_read_cmd));
                memcpy(&txbuffer[4], &read_result, sizeof(read_result));
                checksum = Get_CheckSum(txbuffer, 6);
                memcpy(&txbuffer[6], &checksum, sizeof(checksum));
                memcpy(&txbuffer[7], &end, sizeof(end));

                usleep(DELAY_TIME); /* delay 62.5 us */

                ret = SPI_SendData(txbuffer, PDO_TX_READS_DATA_DATASIZE); /* transfer the buffer */

#if 1
                /* print the header of receiver */
                DEBUG_INFO("send:\n");
                for (int i = 0; i < PDO_TX_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", txbuffer[i]);
                }
                printf("\n");
#endif

                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }

                usleep(DELAY_TIME); /* delay 62.5 us */

                ret = SPI_ReceiveData(rxbuffer, PDO_RX_DATASIZE + PDO_READ_DATASIZE);

                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }

#if 1 /* print the header of receiver */
                DEBUG_INFO("receive:\n");
                for (int i = 0; i < PDO_RX_DATASIZE + PDO_READ_DATASIZE; i++)
                {
                    // ccbuffer[i] = rxbuffer_1[i];
                    DEBUG_INFO("%02x  ", rxbuffer[i]);
                }
                printf("\n");
#endif
                rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

                /* judge whether the receive data is correct */
                if (header != rx_pointer->header)
                {
                    printf("the header is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                if (error_recv_cmd == rx_pointer->cmd)
                {
                    Receive_End_Flag = FALSE;
                    error_num++;
                    break;
                }
                else if (pdo_read_cmd != rx_pointer->cmd)
                {
                    printf("the cmd is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (PDO_READ_DATASIZE != rx_pointer->address_result.datasize)
                {
                    printf("the DataSize is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                checksum = Get_CheckSum(rxbuffer, 6 + PDO_READ_DATASIZE);

                /* judge whether the end of the receiver is valid */
                if (checksum != rxbuffer[PDO_RX_DATASIZE + PDO_READ_DATASIZE - 2])
                {
                    printf("the checksum is invalid");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                else if (end != rxbuffer[PDO_RX_DATASIZE + PDO_READ_DATASIZE - 1])
                {
                    printf("the end is wrong");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else
                {
                    memcpy(val + ((i + 1) * (PDO_READ_DATASIZE / 4)), &rxbuffer[6], PDO_READ_DATASIZE);
                    memset(rxbuffer, 0, PDO_RX_DATASIZE + PDO_READ_DATASIZE);
                }
            }
            // free(rxbuffer); // free
        }
        if (TRUE == Receive_End_Flag)
        {
            // rxbuffer = (uint8_t *)malloc(PDO_RX_DATASIZE + (DataSize % PDO_READ_DATASIZE));
            /* store the transfer data */
            memcpy(txbuffer, &header, sizeof(header));
            memcpy(&txbuffer[2], &pdo_read_cmd, sizeof(pdo_read_cmd));
            memcpy(&txbuffer[4], &read_result, sizeof(read_result));
            checksum = Get_CheckSum(txbuffer, 6);
            memcpy(&txbuffer[6], &checksum, sizeof(checksum));
            memcpy(&txbuffer[7], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_SendData(txbuffer, PDO_TX_READS_DATA_DATASIZE); /* transfer the buffer */

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < PDO_TX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", txbuffer[i]);
            }
            printf("\n");
#endif

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_ReceiveData(rxbuffer, PDO_RX_DATASIZE + (DataSize % PDO_READ_DATASIZE));

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < PDO_RX_DATASIZE + (DataSize % PDO_READ_DATASIZE); i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif
            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            usleep(DELAY_TIME); /* delay 62.5 us */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (pdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if ((DataSize % PDO_READ_DATASIZE) != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + (DataSize % PDO_READ_DATASIZE));

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[PDO_RX_DATASIZE + (DataSize % PDO_READ_DATASIZE) - 2])
            {
                printf("the checksum is invalid");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[PDO_RX_DATASIZE + (DataSize % PDO_READ_DATASIZE) - 1])
            {
                printf("the end is wrong");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                memcpy(val + (count * (PDO_READ_DATASIZE / 4)), rxbuffer + 6, (DataSize % PDO_READ_DATASIZE));
                memset(rxbuffer, 0, PDO_RX_DATASIZE + PDO_READ_DATASIZE);
            }
        }
        SPI_End();
        free(rxbuffer);
        return NO_ERROR;
    }
    /* Unreachable processing */
    free(rxbuffer);
    return NO_ERROR;
}

/*********************************************************************************
[function name] ExIoAreaWrite

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	write data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/

int ExIoAreaWrite(int Address, short DataSize, int *val)
{
    uint8_t txbuf_start[PDO_TX_DATASIZE]; /* the  transfer data */
    // uint8_t txbuf_data[PDO_TX_DATASIZE + DataSize];
    uint8_t *txbuf_data = NULL; /* the transfer data */
    uint8_t *val_array = NULL;
    uint8_t checksum;                     /* define a buffer to store the data which is used to calculate the checksum */
    uint8_t rxbuf_start[PDO_RX_DATASIZE]; /* the  receive data */
    uint8_t rxbuf_data[PDO_RX_DATASIZE];
    RXBUFF_HEADER *rx_pointer; /* define a struct pointer to analysis the receive data more quickly */
    uint16_t header = SPI_HEADER;
    uint16_t pdo_write_start_cmd = PDO_WRITE_START_CMD;
    uint16_t pdo_write_data_cmd = PDO_WRITE_DATA_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint16_t pdo_write_datasize = PDO_WRITE_DATASIZE;
    uint16_t pdo_write_finish_flag = PDO_WRITE_FINISH_FLAG;
    uint32_t pdo_write_list;
    uint8_t end = SPI_TRAILER;
    uint8_t ret = 0;
    uint8_t count = 0;
    uint8_t error_num = 0;
    _Bool Serval_Write_Flag = FALSE;
    _Bool Write_End_Flag = FALSE;
    _Bool pdo_wt_address_flag = FALSE;

    /* judge the validity of parameters */
    for (pdo_write_list = 0; pdo_write_list < writepdo_listnum; pdo_write_list++)
    {
        if (Address == RF_write_pdo_area[pdo_write_list].address)
        {
            pdo_wt_address_flag = TRUE;
        }

        if (pdo_wt_address_flag == TRUE)
        {
            if ((DataSize > RF_write_pdo_area[pdo_write_list].datasize) || (DataSize < 0))
            {
                printf("the datasize is not in the range\n");
                return PARAM_ERROR;
            }
        }
        if (pdo_wt_address_flag == TRUE)
            break;
    }
    if (FALSE == pdo_wt_address_flag)
    {
        printf("the address is wrong\n");
        return PARAM_ERROR;
    }
    // if (0 == val)
    // {
    //     printf("the point is wrong");
    //     return PARAM_ERROR;
    // }

    if (PDO_WRITE_DATASIZE > DataSize)
    {
        txbuf_data = (uint8_t *)malloc(PDO_TX_DATASIZE + DataSize + 1);
        if (txbuf_data == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
    }
    else
    {
        txbuf_data = (uint8_t *)malloc(PDO_TX_DATASIZE + PDO_WRITE_DATASIZE + 1);
        if (txbuf_data == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
        count = DataSize / PDO_WRITE_DATASIZE;
        Serval_Write_Flag = TRUE;
        if (0 != DataSize % PDO_WRITE_DATASIZE)
        {
            Write_End_Flag = TRUE;
        }
    }
    val_array = (uint8_t *)malloc(DataSize * sizeof(uint8_t) + 1);
    if (val_array == NULL)
    {
        printf("malloc error\n");
        free(txbuf_data);
        return MALLOC_ERROR;
    }
    memcpy(val_array, val, DataSize);

    /* intialize SPI */
    ret = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED);
    if (NO_ERROR != ret)
    {
        SPI_End();
        free(txbuf_data);
        free(val_array);
        return ret;
    }

    while (ERROR_TIMES > error_num)
    {
        /* store the transfer data */
        memcpy(txbuf_start, &header, sizeof(header));
        memcpy(&txbuf_start[2], &pdo_write_start_cmd, sizeof(pdo_write_start_cmd));
        memcpy(&txbuf_start[4], &Address, sizeof(Address));
        memcpy(&txbuf_start[8], &DataSize, sizeof(DataSize));
        checksum = Get_CheckSum(txbuf_start, CC_LENGTH);
        memcpy(&txbuf_start[10], &checksum, sizeof(checksum));
        memcpy(&txbuf_start[11], &end, sizeof(end));

        ret = SPI_SendData(txbuf_start, PDO_TX_DATASIZE); /* transfer the buffer */

        if (NO_ERROR != ret)
        {
            SPI_End();
            free(txbuf_data);
            free(val_array);
            return ret;
        }

#if 1
        /* print the header of receiver */
        DEBUG_INFO("send:\n");
        for (int i = 0; i < PDO_TX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", txbuf_start[i]);
        }
        printf("\n");
#endif

        usleep(DELAY_TIME); /* delay 62.5 us */

        ret = SPI_ReceiveData(rxbuf_start, PDO_RX_DATASIZE); /* receive the header */
        if (NO_ERROR != ret)
        {
            SPI_End();
            free(txbuf_data);
            free(val_array);
            return ret;
        }

#if 1
        /* print the header of receiver */
        DEBUG_INFO("receive:\n");
        for (int i = 0; i < PDO_RX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", rxbuf_start[i]);
        }
        printf("\n");
#endif
        rx_pointer = (RXBUFF_HEADER *)rxbuf_start; /* pointer to receive cache */

        /* judge whether the receive data is correct */
        if (header != rx_pointer->header)
        {
            printf("the header is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }

        if (error_recv_cmd == rx_pointer->cmd)
        {
            error_num++;
            continue;
        }
        else if (pdo_write_start_cmd != rx_pointer->cmd)
        {
            printf("the cmd is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else if (Get_CheckSum(rxbuf_start, PDO_RX_DATASIZE - 2) != rxbuf_start[PDO_RX_DATASIZE - 2])
        {
            printf("the checksum is invalid\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else if (end != rxbuf_start[PDO_RX_DATASIZE - 1])
        {
            printf("the end is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else
        {
            printf("start to write\n");
        }

        if (TRUE != Serval_Write_Flag)
        {
            memcpy(txbuf_data, &header, sizeof(header));
            memcpy(&txbuf_data[2], &pdo_write_data_cmd, sizeof(pdo_write_data_cmd));
            memcpy(&txbuf_data[4], &Address, sizeof(Address));
            memcpy(&txbuf_data[8], &DataSize, sizeof(DataSize));
            memcpy(&txbuf_data[10], val, DataSize);
            checksum = Get_CheckSum(txbuf_data, PDO_TX_DATASIZE + DataSize - 2);
            memcpy(&txbuf_data[PDO_TX_DATASIZE + DataSize - 2], &checksum, sizeof(checksum));
            memcpy(&txbuf_data[PDO_TX_DATASIZE + DataSize - 1], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_SendData(txbuf_data, PDO_TX_DATASIZE + DataSize); /* transfer the data */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < PDO_TX_DATASIZE + DataSize; i++)
            {
                DEBUG_INFO("%02x  ", txbuf_data[i]);
            }
            printf("\n");
#endif

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_ReceiveData(rxbuf_data, PDO_RX_DATASIZE);
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }

#if 1
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < PDO_RX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (pdo_write_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (pdo_write_finish_flag != rx_pointer->address_result.result)
            {
                printf("the result is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (Get_CheckSum(rxbuf_data, PDO_RX_DATASIZE - 2) != rxbuf_data[PDO_RX_DATASIZE - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (end != rxbuf_data[PDO_RX_DATASIZE - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                printf("write successfully!\n");
                SPI_End();
                free(val_array);
                free(txbuf_data);
                return NO_ERROR;
            }
        }
        else
        {
            // txbuf_data = (uint8_t *)malloc(PDO_TX_DATASIZE + PDO_WRITE_DATASIZE);
            for (int i = 0; i < count; i++)
            {

                memcpy(txbuf_data, &header, sizeof(header));
                memcpy(&txbuf_data[2], &pdo_write_data_cmd, sizeof(pdo_write_data_cmd));
                memcpy(&txbuf_data[4], &Address, sizeof(Address));
                memcpy(&txbuf_data[8], &pdo_write_datasize, sizeof(pdo_write_datasize));
                memcpy(&txbuf_data[10], (val_array + (i * PDO_WRITE_DATASIZE)), PDO_WRITE_DATASIZE);
                checksum = Get_CheckSum(txbuf_data, PDO_TX_DATASIZE + PDO_WRITE_DATASIZE - 2);
                memcpy(&txbuf_data[PDO_TX_DATASIZE + PDO_WRITE_DATASIZE - 2], &checksum, sizeof(checksum));
                memcpy(&txbuf_data[PDO_TX_DATASIZE + PDO_WRITE_DATASIZE - 1], &end, sizeof(end));

                usleep(DELAY_TIME); /* delay 62.5 us */

                SPI_SendData(txbuf_data, PDO_TX_DATASIZE + PDO_WRITE_DATASIZE); /* transfer the data */

#if 1
                /* print the header of receiver */
                DEBUG_INFO("send:\n");
                for (int i = 0; i < PDO_TX_DATASIZE + PDO_WRITE_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", txbuf_data[i]);
                }
                printf("\n");
#endif

                usleep(DELAY_TIME); /* delay 62.5 us */

                SPI_ReceiveData(rxbuf_data, PDO_RX_DATASIZE);

#if 1
                /* print the header of receiver */
                DEBUG_INFO("receive:\n");
                for (int i = 0; i < PDO_RX_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", rxbuf_data[i]);
                }
                printf("\n");
#endif

                rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

                /* judge whether the receive data is correct */
                if (header != rx_pointer->header)
                {
                    printf("the header is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                if (error_recv_cmd == rx_pointer->cmd)
                {
                    Write_End_Flag = FALSE;
                    error_num++;
                    break;
                }
                else if (pdo_write_data_cmd != rx_pointer->cmd)
                {
                    printf("the cmd is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (pdo_write_finish_flag != rx_pointer->address_result.result)
                {
                    printf("the result is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (Get_CheckSum(rxbuf_data, PDO_RX_DATASIZE - 2) != rxbuf_data[PDO_RX_DATASIZE - 2])
                {
                    printf("the checksum is invalid\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (end != rxbuf_data[PDO_RX_DATASIZE - 1])
                {
                    printf("the end is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else
                {
                    memset(txbuf_data, 0, PDO_TX_DATASIZE + PDO_WRITE_DATASIZE);
                }
            }
            // free(txbuf_data);
        }
        if (TRUE == Write_End_Flag)
        {
            pdo_write_datasize = DataSize % PDO_WRITE_DATASIZE;
            // txbuf_data = (uint8_t *)malloc(PDO_TX_DATASIZE + pdo_write_datasize);

            memcpy(txbuf_data, &header, sizeof(header));
            memcpy(&txbuf_data[2], &pdo_write_data_cmd, sizeof(pdo_write_data_cmd));
            memcpy(&txbuf_data[4], &Address, sizeof(Address));
            memcpy(&txbuf_data[8], &pdo_write_datasize, sizeof(pdo_write_datasize));
            memcpy(&txbuf_data[10], (val_array + (count * PDO_WRITE_DATASIZE)), pdo_write_datasize);
            checksum = Get_CheckSum(txbuf_data, PDO_TX_DATASIZE + pdo_write_datasize - 2);
            printf("checksum: %x\n", checksum);
            memcpy(&txbuf_data[PDO_TX_DATASIZE + pdo_write_datasize - 2], &checksum, sizeof(checksum));
            memcpy(&txbuf_data[PDO_TX_DATASIZE + pdo_write_datasize - 1], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            SPI_SendData(txbuf_data, PDO_TX_DATASIZE + pdo_write_datasize); /* transfer the data */

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < (PDO_TX_DATASIZE + pdo_write_datasize); i++)
            {
                DEBUG_INFO("%02x  ", txbuf_data[i]);
            }
            printf("\n");
#endif

            usleep(DELAY_TIME); /* delay 62.5 us */

            SPI_ReceiveData(rxbuf_data, PDO_RX_DATASIZE);

#if 1
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < PDO_RX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (pdo_write_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (pdo_write_finish_flag != rx_pointer->address_result.result)
            {
                printf("the result is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (Get_CheckSum(rxbuf_data, PDO_RX_DATASIZE - 2) != rxbuf_data[PDO_RX_DATASIZE - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (end != rxbuf_data[PDO_RX_DATASIZE - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
        }
        SPI_End();
        free(val_array);
        free(txbuf_data);
        return NO_ERROR;
    }
    /* Unreachable processing */
    free(txbuf_data);
    free(val_array);
    return NO_ERROR;
}

/*********************************************************************************
[function name] log_file

[arguments]
buffer			        :	First address of buffer
len			            :	the length of buffer
filename		      	:	the name of file

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int32_t log_file(char *buffer, uint32_t len, char *filename)
{
#if 1
    FILE *fp;
    int32_t ret = NO_ERROR;
    // printf("*****log file [%s]\r\n", filename);
    printf("\r\n");
    fp = fopen(filename, "w");
    if (fp == NULL)
    {
        printf("open file failed!!!\r\n");
        ret = FILE_OPEN_ERROR;
        return ret;
    }
    fwrite(buffer, len, 1, fp);
    fclose(fp);
    return ret;
#endif
}

/*********************************************************************************
[function name] systemCall

[arguments]
pCmd			        :	First address of buffer
pRecv		            :	the length of buffer
sizeRecv		      	:	the name of file
bDisplayRecv            :

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int systemCall(char *pCmd, char *pRecv, int sizeRecv, _Bool bDisplayRecv)
{
    int res = 0;
    FILE *stream = popen(pCmd, "r");

    if (stream == NULL)
        return -1;

    if (pRecv != NULL)
    {
        memset(pRecv, 0x00, sizeRecv);
        res = (int)fread(pRecv, sizeof(char), sizeRecv, stream);
        if (res < 0)
        {
            printf("An error occurred while fread a system call");
            return GENERAL_ERROR;
        }

        if (TRUE == bDisplayRecv)
            printf("@Server_output>>\n%s", pRecv);
    }

    pclose(stream);

    return res;
}

int update_image()
{
    int iRet = 0;
    char cmdBuf[128] = {0};
    // char recvBuf[128] = {0};

    sprintf(cmdBuf, "chmod 777 foe_firm.tar.gz");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf /media/sd-mmcblk0p1/foe_firm.tar.gz");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    usleep(100000);
    sprintf(cmdBuf, "cp foe_firm.tar.gz /mnt/sd-mmcblk0p1/");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf foe_firm.tar.gz");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf /media/sd-mmcblk0p1/BOOT.BIN");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf /media/sd-mmcblk0p1/image.ub");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf /media/sd-mmcblk0p1/boot.scr");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    usleep(100000);
    sprintf(cmdBuf, "sudo tar --no-same-owner -zxvf /mnt/sd-mmcblk0p1/foe_firm.tar.gz -C /mnt/sd-mmcblk0p1/");
    system(cmdBuf);
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "rm -rf /media/sd-mmcblk0p1/foe_firm.tar.gz");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }
    memset(cmdBuf, 0x00, sizeof(cmdBuf));
    sprintf(cmdBuf, "sync");
    iRet = systemCall(cmdBuf, NULL, 0, FALSE);
    if (iRet < 0)
    {
        return iRet;
    }

    return NO_ERROR;
}

/*********************************************************************************
[function name] ExIoAreaFoERead

[arguments]
 NULL


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int ExIoAreaFoERead()
{
    uint8_t txbuf_start[FOE_TX_DATASIZE];
    uint8_t txbuf_data[FOE_TX_DATASIZE];
    uint8_t checksum;
    // uint8_t ret = 0;
    uint8_t error_num = 0;
    uint8_t rxbuf_start[FOE_RX_START_DATASIZE]; /* the  receive data */
    uint8_t rxbuf_data[FOE_RX_DATA_DATASIZE + 8];
    RXBUFF_HEADER *rx_pointer; /* define a struct pointer to analysis the receive data more quickly */
    uint16_t header = SPI_HEADER;
    uint32_t address = UNDETERMINATE;
    uint16_t datasize = UNDETERMINATE;
    uint16_t foe_read_start_cmd = FOE_READ_START_CMD;
    uint16_t foe_read_data_cmd = FOE_READ_DATA_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint16_t no_data = NO_DATA;
    uint8_t end = SPI_TRAILER;
    uint32_t foe_datasize;
    uint32_t count;
    float nowPercentage;
    _Bool receive_end = FALSE;
    // _Bool receive_data = FALSE;
    char *buffer = NULL;
    int iRet = 0;

    /* intialize SPI */
    iRet = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED);
    if (NO_ERROR != iRet)
    {
        goto end;
    }

    while (ERROR_TIMES > error_num)
    {
        /* store the transfer data */
        memcpy(txbuf_start, &header, sizeof(header));
        memcpy(&txbuf_start[2], &foe_read_start_cmd, sizeof(foe_read_start_cmd));
        memcpy(&txbuf_start[4], &address, sizeof(address));
        memcpy(&txbuf_start[8], &datasize, sizeof(datasize));
        checksum = Get_CheckSum(txbuf_start, CC_LENGTH);
        memcpy(&txbuf_start[10], &checksum, sizeof(checksum));
        memcpy(&txbuf_start[11], &end, sizeof(end));

        iRet = SPI_SendData(txbuf_start, FOE_TX_DATASIZE); /* transfer the buffer */
        if (NO_ERROR != iRet)
        {
            goto end;
        }

        usleep(DELAY_TIME * 4); /* delay 62.5 us */

        iRet = SPI_ReceiveData(rxbuf_start, FOE_RX_START_DATASIZE); /* receive the header */
        if (NO_ERROR != iRet)
        {
            goto end;
        }

#if 0
        /* print the header of receiver */
        DEBUG_INFO("receive:\n");
        for (int i = 0; i < FOE_RX_START_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", rxbuf_start[i]);
        }
        printf("\n");
#endif

        rx_pointer = (RXBUFF_HEADER *)rxbuf_start; /* pointer to receive cache */

        /* judge whether the receive data is correct */
        if (header != rx_pointer->header)
        {
            printf("the header is wrong\n");
            printf("reset the Communication_api\n");
            iRet = ResetCommunication();
            if (NO_ERROR != iRet)
            {
                goto end;
            }
            error_num++;
            continue;
        }

        if (error_recv_cmd == rx_pointer->cmd)
        {
            error_num++;
            continue;
        }
        else if (foe_read_start_cmd != rx_pointer->cmd)
        {
            printf("the cmd is wrong\n");
            printf("reset the Communication_api\n");
            iRet = ResetCommunication();
            if (NO_ERROR != iRet)
            {
                goto end;
            }
            error_num++;
            continue;
        }
        else if (Get_CheckSum(rxbuf_start, FOE_RX_START_DATASIZE - 2) != rxbuf_start[FOE_RX_START_DATASIZE - 2])
        {
            // printf("cc:%x\n", Get_CheckSum(rxbuf_start, FOE_RX_START_DATASIZE - 2));
            // printf("cc2:%x\n", rxbuf_start[FOE_RX_START_DATASIZE - 2]);
            printf("the checksum is invalid\n");
            printf("reset the Communication_api\n");
            iRet = ResetCommunication();
            if (NO_ERROR != iRet)
            {
                goto end;
            }
            error_num++;
            continue;
        }
        else if (end != rxbuf_start[FOE_RX_START_DATASIZE - 1])
        {
            printf("the end is wrong\n");
            printf("reset the Communication_api\n");
            iRet = ResetCommunication();
            if (NO_ERROR != iRet)
            {
                goto end;
            }
            error_num++;
            continue;
        }
        else if (no_data == rx_pointer->address_result.foe_datasize)
        {
            printf("receive nothing!\n");
            iRet = NO_ERROR;
            goto end;
        }
        else
        {
            memcpy(&foe_datasize, &rxbuf_start[4], 4);
            count = foe_datasize / FOE_RX_DATA_DATASIZE;
            if (buffer != NULL)
            {
                free(buffer);
            }
            buffer = (char *)malloc(foe_datasize + 1);
            if (buffer == NULL)
            {
                printf("malloc error\n");
                iRet = MALLOC_ERROR;
                goto end;
            }
            if (0 != foe_datasize % FOE_RX_DATA_DATASIZE)
            {
                receive_end = TRUE;
            }
        }

        usleep(DELAY_TIME); /* delay 62.5 us */
        usleep(DELAY_TIME);

        for (int i = 0; i < count; i++)
        {
            nowPercentage = ((long double)i / (long double)count) * 100;
            printf("\r- Current process  ---------------%2.2f %%-----------------", nowPercentage);
            /* store the transfer data */
            memcpy(txbuf_data, &header, sizeof(header));
            memcpy(&txbuf_data[2], &foe_read_data_cmd, sizeof(foe_read_data_cmd));
            address = FOE_RX_DATA_DATASIZE * i;
            memcpy(&txbuf_data[4], &address, sizeof(address));
            datasize = FOE_RX_DATA_DATASIZE;
            memcpy(&txbuf_data[8], &datasize, sizeof(datasize));
            checksum = Get_CheckSum(txbuf_data, FOE_RX_START_DATASIZE);
            memcpy(&txbuf_data[10], &checksum, sizeof(checksum));
            memcpy(&txbuf_data[11], &end, sizeof(end));

            iRet = SPI_SendData(txbuf_data, FOE_TX_DATASIZE); /* transfer the buffer */
            if (NO_ERROR != iRet)
            {
                goto end;
            }

            usleep(DELAY_TIME); /* delay 62.5 us */

            iRet = SPI_ReceiveData(rxbuf_data, FOE_RX_DATA_DATASIZE + 8); /* receive the data */
            if (NO_ERROR != iRet)
            {
                goto end;
            }

#if 0
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < FOE_RX_DATA_DATASIZE + 8; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");

#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header of data is wrong\n");
                printf("reset the Communication_api\n");
                receive_end = FALSE;
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                break;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                receive_end = FALSE;
                error_num++;
                break;
            }
            else if (foe_read_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd of data is wrong\n");
                printf("reset the Communication_api\n");
                receive_end = FALSE;
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                break;
            }
            else if (Get_CheckSum(rxbuf_data, FOE_RX_DATA_DATASIZE + 6) != rxbuf_data[FOE_RX_DATA_DATASIZE + 6])
            {
                printf("the checksum of data is invalid\n");
                printf("reset the Communication_api\n");
                receive_end = FALSE;
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                break;
            }
            else if (end != rxbuf_data[FOE_RX_DATA_DATASIZE + 7])
            {
                printf("the end of data is wrong\n");
                printf("reset the Communication_api\n");
                receive_end = FALSE;
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                break;
            }
            else
            {
                for (int j = 0; j < FOE_RX_DATA_DATASIZE; j++)
                {
                    buffer[i * FOE_RX_DATA_DATASIZE + j] = rxbuf_data[j + 6];
                }
            }

            usleep(DELAY_TIME); /* delay 62.5 us */
        }

        if (TRUE == receive_end)
        {
            address = FOE_RX_DATA_DATASIZE * count;
            memcpy(&txbuf_data[4], &address, sizeof(address));
            datasize = foe_datasize % FOE_RX_DATA_DATASIZE;
            memcpy(&txbuf_data[8], &datasize, sizeof(datasize));
            checksum = Get_CheckSum(txbuf_data, FOE_RX_START_DATASIZE);
            memcpy(&txbuf_data[10], &checksum, sizeof(checksum));
            SPI_SendData(txbuf_data, FOE_TX_DATASIZE); /* transfer the buffer */

            usleep(DELAY_TIME); /* delay 62.5 us */

            SPI_ReceiveData(rxbuf_data, (foe_datasize % FOE_RX_DATA_DATASIZE) + 8); /* receive the data */

#if 0
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < (foe_datasize % FOE_RX_DATA_DATASIZE) + 8; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header of data is wrong\n");
                printf("reset the Communication_api\n");
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                continue;
            }
            else if (foe_read_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd of data is wrong\n");
                printf("reset the Communication_api\n");
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                continue;
            }
            else if (Get_CheckSum(rxbuf_data, (foe_datasize % FOE_RX_DATA_DATASIZE) + 6) != rxbuf_data[(foe_datasize % FOE_RX_DATA_DATASIZE) + 6])
            {
                printf("the checksum of data is invalid\n");
                printf("reset the Communication_api\n");
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                continue;
            }
            else if (end != rxbuf_data[(foe_datasize % FOE_RX_DATA_DATASIZE) + 7])
            {
                printf("the end of data is wrong\n");
                printf("reset the Communication_api\n");
                iRet = ResetCommunication();
                if (NO_ERROR != iRet)
                {
                    goto end;
                }
                error_num++;
                continue;
            }
            else
            {
                address = foe_datasize;
                memcpy(&txbuf_data[4], &address, sizeof(address));
                datasize = 0;
                memcpy(&txbuf_data[8], &datasize, sizeof(datasize));
                checksum = Get_CheckSum(txbuf_data, FOE_RX_START_DATASIZE);
                memcpy(&txbuf_data[10], &checksum, sizeof(checksum));
                SPI_SendData(txbuf_data, FOE_TX_DATASIZE); /* transfer the buffer */

                for (int j = 0; j < (foe_datasize % FOE_RX_DATA_DATASIZE); j++)
                {
                    buffer[count * FOE_RX_DATA_DATASIZE + j] = rxbuf_data[j + 6];
                }
                SPI_End();
                receive_end = TRUE;
            }
        }

        buffer[foe_datasize] = '\0';
#if 0
        for (int i = 0; i < foe_datasize; i++)
        {
            DEBUG_INFO("%02x  ", buffer[i]);
            if ((i % 10) == 0)
            {
                printf("\n");
            }
        }
#endif
        log_file(buffer, foe_datasize, "foe_firm.tar.gz");
        iRet = update_image();
        free(buffer);
        return iRet;
    }
end:
    SPI_End();
    free(buffer);
    return iRet;
}

/*********************************************************************************
[function name] DNetWrite

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DNetInit()
{
    int iRet = 0;
    unsigned long long reg_VirthBaseAddr;

    gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].instanceId = 0x00;
    gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].attributeId = 0x01;
    gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_ID_OBJ_REV].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_VENDOR_ID].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_VENDOR_ID].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_VENDOR_ID].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_VENDOR_ID].attributeId = 0x01;
    gDNetData[DNET_IDTY_MSG_VENDOR_ID].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_VENDOR_ID].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_DEV_TYPE].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_DEV_TYPE].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_DEV_TYPE].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_DEV_TYPE].attributeId = 0x02;
    gDNetData[DNET_IDTY_MSG_DEV_TYPE].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_DEV_TYPE].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_PRO_CODE].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_PRO_CODE].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_PRO_CODE].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_PRO_CODE].attributeId = 0x03;
    gDNetData[DNET_IDTY_MSG_PRO_CODE].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_PRO_CODE].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_REVISION].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_REVISION].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_REVISION].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_REVISION].attributeId = 0x04;
    gDNetData[DNET_IDTY_MSG_REVISION].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_REVISION].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_STATUS].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_STATUS].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_STATUS].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_STATUS].attributeId = 0x05;
    gDNetData[DNET_IDTY_MSG_STATUS].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_STATUS].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_SERIAL_NUM].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_SERIAL_NUM].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_SERIAL_NUM].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_SERIAL_NUM].attributeId = 0x06;
    gDNetData[DNET_IDTY_MSG_SERIAL_NUM].datasize = 4;
    memset(&gDNetData[DNET_IDTY_MSG_SERIAL_NUM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_PRO_NAME].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_PRO_NAME].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_PRO_NAME].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_PRO_NAME].attributeId = 0x07;
    gDNetData[DNET_IDTY_MSG_PRO_NAME].datasize = 14;
    memset(&gDNetData[DNET_IDTY_MSG_PRO_NAME].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_STATE].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_STATE].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_STATE].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_STATE].attributeId = 0x08;
    gDNetData[DNET_IDTY_MSG_STATE].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_STATE].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].attributeId = 0x09;
    gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_CONF_CONSIS_VAL].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_HBEAT_INT].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_HBEAT_INT].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_HBEAT_INT].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_HBEAT_INT].attributeId = 0x0A;
    gDNetData[DNET_IDTY_MSG_HBEAT_INT].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_HBEAT_INT].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_MAC_ID].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_MAC_ID].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_MAC_ID].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_MAC_ID].attributeId = 0x01;
    gDNetData[DNET_IDTY_MSG_MAC_ID].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_MAC_ID].data, 0, DEVICENET_DATASIZE_MAX);
    gDNetData[DNET_IDTY_MSG_MAC_ID].data[0] = 0x21;

    gDNetData[DNET_IDTY_MSG_BAUD_RATE].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE].attributeId = 0x02;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_BAUD_RATE].data, 0, DEVICENET_DATASIZE_MAX);
    gDNetData[DNET_IDTY_MSG_BAUD_RATE].data[0] = 0x02;

    gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].attributeId = 0x03;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_BUS_OFF_ITR].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].attributeId = 0x04;
    gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_BUS_OFF_CONT].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].attributeId = 0x05;
    gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_ALLOC_INFOR].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].attributeId = 0x06;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_MAC_ID_SW_CHANGED].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].attributeId = 0x07;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].datasize = 1;
    memset(&gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_CHANGED].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].classId = 0x03;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].attributeId = 0x08;
    gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_MAC_ID_SW_VAL].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].serviceId = 0x0E;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].classId = 0x01;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].instanceId = 0x01;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].attributeId = 0x09;
    gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].datasize = 2;
    memset(&gDNetData[DNET_IDTY_MSG_BAUD_RATE_SW_VAL].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_MOD_NO].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_MOD_NO].classId = 0x10;
    gDNetData[DNET_EXP_MSG_MOD_NO].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_MOD_NO].attributeId = 0x03;
    gDNetData[DNET_EXP_MSG_MOD_NO].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_MOD_NO].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].classId = 0x10;
    gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].attributeId = 0x04;
    gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_DISP_DET_INFOR_NO].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_TIME_SET].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_TIME_SET].classId = 0x10;
    gDNetData[DNET_EXP_MSG_TIME_SET].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_TIME_SET].attributeId = 0x05;
    gDNetData[DNET_EXP_MSG_TIME_SET].datasize = 8;
    memset(&gDNetData[DNET_EXP_MSG_TIME_SET].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].classId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].attributeId = 0x06;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF_POW_UP_LM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].classId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].attributeId = 0x07;
    gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF_POW_LW_LM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].classId = 0x10;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].attributeId = 0x08;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_LF2_RF_POW_LW_LM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].classId = 0x10;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].attributeId = 0x09;
    gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_LF2_RF_POW_UP_LM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_REC_INFOR].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_REC_INFOR].classId = 0x64;
    gDNetData[DNET_EXP_MSG_REC_INFOR].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_REC_INFOR].attributeId = 0x01;
    gDNetData[DNET_EXP_MSG_REC_INFOR].datasize = 96;
    memset(&gDNetData[DNET_EXP_MSG_REC_INFOR].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].classId = 0x64;
    gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].attributeId = 0x02;
    gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].datasize = 72;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF_CAL_TAB].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].classId = 0x64;
    gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].attributeId = 0x03;
    gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].datasize = 72;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF2_CAL_TAB].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].classId = 0x64;
    gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].attributeId = 0x04;
    gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_SELF_CHE_STAR].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].serviceId = 0x10;
    gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].classId = 0x64;
    gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].attributeId = 0x05;
    gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_SELF_CHE_ABT].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].classId = 0x65;
    gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].attributeId = 0x01;
    gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF_HEAD_NUM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].classId = 0x65;
    gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].attributeId = 0x02;
    gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_LF_RF2_HEAD_NUM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_BRD_NUM].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_BRD_NUM].classId = 0x65;
    gDNetData[DNET_EXP_MSG_BRD_NUM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_BRD_NUM].attributeId = 0x03;
    gDNetData[DNET_EXP_MSG_BRD_NUM].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_BRD_NUM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].classId = 0x65;
    gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].attributeId = 0x04;
    gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_DIG_BRD_HW_VER].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].classId = 0x65;
    gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].attributeId = 0x05;
    gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_HW_BRD_HW_VER].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_FIRM_VER].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_FIRM_VER].classId = 0x65;
    gDNetData[DNET_EXP_MSG_FIRM_VER].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_FIRM_VER].attributeId = 0x06;
    gDNetData[DNET_EXP_MSG_FIRM_VER].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_FIRM_VER].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_FPGA_VER].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_FPGA_VER].classId = 0x65;
    gDNetData[DNET_EXP_MSG_FPGA_VER].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_FPGA_VER].attributeId = 0x07;
    gDNetData[DNET_EXP_MSG_FPGA_VER].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_FPGA_VER].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].classId = 0x65;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].attributeId = 0x08;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM1].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].classId = 0x65;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].attributeId = 0x09;
    gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_BRD_CHECK_NUM2].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_TR_CHK_NUM].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_TR_CHK_NUM].classId = 0x65;
    gDNetData[DNET_EXP_MSG_TR_CHK_NUM].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_TR_CHK_NUM].attributeId = 0x10;
    gDNetData[DNET_EXP_MSG_TR_CHK_NUM].datasize = 16;
    memset(&gDNetData[DNET_EXP_MSG_TR_CHK_NUM].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_ERR_REQ].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_ERR_REQ].classId = 0x65;
    gDNetData[DNET_EXP_MSG_ERR_REQ].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_ERR_REQ].attributeId = 0x11;
    gDNetData[DNET_EXP_MSG_ERR_REQ].datasize = 4;
    memset(&gDNetData[DNET_EXP_MSG_ERR_REQ].data, 0, DEVICENET_DATASIZE_MAX);

    gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].serviceId = 0x0E;
    gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].classId = 0x65;
    gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].instanceId = 0x00;
    gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].attributeId = 0x12;
    gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].datasize = 0;
    memset(&gDNetData[DNET_EXP_MSG_SELF_CALC_REQ].data, 0, DEVICENET_DATASIZE_MAX);

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    *((unsigned *)(reg_VirthBaseAddr)) = 0;

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);

    // Initialize the timer
    system("ip link set can0 down");
    // sleep(1);
    system("ip link set can0 type can bitrate 500000");
    // sleep(1);
    system("ip link set can0 up");
    // sleep(1);
    DeviceNet_Init_Flag = TRUE;
    return NO_ERROR;
}

int DNetWrite(DnetAccessObject *dneObject, DNET_ENUM dNetENum)
{
    int iTemp = 0;
    if (FALSE == DeviceNet_Init_Flag)
    {
        printf("please init the DeviceNet firstly\n");
        return GENERAL_ERROR;
    }
    if (NULL == dneObject)
    {
        printf("the parameters is wrong\n");
        return DNET_WRITE_ERROR;
    }
    if (DEVICENET_DATASIZE_MAX < dneObject->dataSize)
    {
        printf("the DeviceNet Datasize is out of range\n");
        return DNET_SIZE_ERROR;
    }

    /* Write the memory */
    for (iTemp = 0; iTemp < dneObject->dataSize; iTemp++)
    {
        DEBUG_INFO("the dneObject->val[%d] is 0x%x", iTemp, dneObject->val[iTemp]);
        gDNetData[dNetENum].data[iTemp] = dneObject->val[iTemp];
    }

    return NO_ERROR;
}

int DNetRead(DnetAccessObject *dneObject, DNET_ENUM dNetENum)
{
    int iTemp = 0;
    if (FALSE == DeviceNet_Init_Flag)
    {
        printf("please init the DeviceNet firstly\n");
        return GENERAL_ERROR;
    }
    if (NULL == dneObject)
    {
        printf("the parameters is wrong\n");
        return DNET_WRITE_ERROR;
    }
    if (DEVICENET_DATASIZE_MAX < dneObject->dataSize)
    {
        printf("the DeviceNet Datasize is out of range\n");
        return DNET_SIZE_ERROR;
    }

    dneObject->serviceId = gDNetData[dNetENum].serviceId;
    dneObject->classId = gDNetData[dNetENum].classId;
    dneObject->instanceId = gDNetData[dNetENum].instanceId;
    dneObject->attributeId = gDNetData[dNetENum].attributeId;
    for (iTemp = 0; iTemp < dneObject->dataSize; iTemp++)
    {
        dneObject->val[iTemp] = gDNetData[dNetENum].data[iTemp];
        DEBUG_INFO("the dneObject->val[%d] is 0x%x", iTemp, dneObject->val[iTemp]);
    }

    return NO_ERROR;
}

int DNetPollingWrite(DnetPollingObject *dnePollingObject)
{
    int iRet = 0;
    uint8_t *pReg_addr;
    uint32_t iOffset = 0;
    unsigned long long reg_VirthBaseAddr;

    if (NULL == dnePollingObject)
    {
        printf("the parameters is wrong\n");
        return DNET_WRITE_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    iOffset = DEVICENET_POLLING_BLOCK_OFFSET * DEVICENET_DATA_SIZE;

    /* Write the memory */
    DEBUG_INFO("the iOffset is 0x%x", iOffset);

    pReg_addr = (uint8_t *)(reg_VirthBaseAddr + iOffset);

    for (int i = 0; i < DEVICENET_POLLING_DATASIZE; i++)
    {
        *(pReg_addr + i) = dnePollingObject->send[i];
    }

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
    return NO_ERROR;
}

int DNetPollingRead(DnetPollingObject *dnePollingObject)
{
    int iRet = 0;
    uint8_t *pReg_addr;
    uint32_t iOffset = 0;
    unsigned long long reg_VirthBaseAddr;

    /* judge whether the parameters are in range*/
    if (NULL == dnePollingObject)
    {
        printf("the parameters is wrong\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    iOffset = DEVICENET_POLLING_BLOCK_OFFSET * DEVICENET_DATA_SIZE;
    DEBUG_INFO("the iOffset is 0x%x", iOffset);
    /* Read the memory */
    pReg_addr = (uint8_t *)(reg_VirthBaseAddr + iOffset);
    for (int i = 0; i < DEVICENET_POLLING_DATASIZE; i++)
    {
        dnePollingObject->send[i] = *(pReg_addr + i);
    }
    // memcpy(dneObject->val, (uint8_t *)(reg_VirthBaseAddr + iOffset + 0x3 + dneObject->address), dneObject->dataSize);

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
    return NO_ERROR;
}

int DNetGetIdentifyParameter(DnetIdentifyObject *identifyParam)
{
    int iRet = 0;
    int val[DEVICENET_IDENTIFY_EEPROM_DATASIZE];
    iRet = EepromRead(DEVICENET_IDENTIFY_EEPROM_ADDR, DEVICENET_IDENTIFY_EEPROM_DATASIZE * sizeof(int), val);
    if (NO_ERROR != iRet)
    {
        return EEPROM_READ_ERROR;
    }
    memcpy(identifyParam, val, sizeof(int) * 7);
    memcpy(&identifyParam->ProductName, val + 7, sizeof(char) * 14);
    memcpy(&identifyParam->State, val + 11, sizeof(int) * 3);
    return NO_ERROR;
}
int DNetSetIdentifyParameter(DnetIdentifyObject *identifyParam)
{
    int iRet = 0;
    int val[DEVICENET_IDENTIFY_EEPROM_DATASIZE];
    memcpy(val, identifyParam, sizeof(int) * 7);
    memcpy(val + 7, &identifyParam->ProductName, sizeof(char) * 14);
    memcpy(val + 11, &identifyParam->State, sizeof(int) * 3);
    iRet = EepromWrite(DEVICENET_IDENTIFY_EEPROM_ADDR, 8 * sizeof(int), val);
    if (NO_ERROR != iRet)
    {
        return EEPROM_WRITE_ERROR;
    }
    usleep(2000);
    iRet = EepromWrite(DEVICENET_IDENTIFY_EEPROM_ADDR + 32, 6 * sizeof(int), &val[8]);
    if (NO_ERROR != iRet)
    {
        return EEPROM_WRITE_ERROR;
    }

    return NO_ERROR;
}
int DNetGetDnetParameter(DnetCommunicationSetting *dnetParam)
{
    int iRet = 0;
    int val[DEVICENET_COMM_EEPROM_DATASIZE];
    iRet = EepromRead((int)DEVICENET_COMM_EEPROM_ADDR, DEVICENET_COMM_EEPROM_DATASIZE * sizeof(int), val);
    if (NO_ERROR != iRet)
    {
        return EEPROM_READ_ERROR;
    }
    memcpy(dnetParam, val, DEVICENET_COMM_EEPROM_DATASIZE * sizeof(int));
    return NO_ERROR;
}

int DNetSetDnetParameter(DnetCommunicationSetting *dnetParam)
{
    int iRet = 0;
    int val[DEVICENET_COMM_EEPROM_DATASIZE];
    memcpy(val, dnetParam, DEVICENET_COMM_EEPROM_DATASIZE * sizeof(int));
    iRet = EepromWrite((int)DEVICENET_COMM_EEPROM_ADDR, 8 * sizeof(int), val);
    if (NO_ERROR != iRet)
    {
        return EEPROM_WRITE_ERROR;
    }
    usleep(2000); // eeprom page write delay
    iRet = EepromWrite((int)DEVICENET_COMM_EEPROM_ADDR + 32, sizeof(int), &val[8]);
    if (NO_ERROR != iRet)
    {
        return EEPROM_WRITE_ERROR;
    }

    return NO_ERROR;
}

int DNetSaveStatus(DnetCommObject *dneComObject)
{
    int iRet = 0;
    uint8_t cClassId = 0;
    uint8_t cInstanceId = 0;
    uint8_t iNum = 0;
    uint32_t iTemp = 0;
    uint32_t iOffset = 0;

    _Bool search_flag = FALSE;
    unsigned long long reg_VirthBaseAddr;

    if (NULL == dneComObject)
    {
        printf("the parameters is wrong\n");
        return DNET_WRITE_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    /* the num of data */
    iNum = *(unsigned *)(reg_VirthBaseAddr);
    DEBUG_INFO("the num of data is %d", iNum);

    /* judge whether the data already exist in the memory */
    for (iTemp = 0; iTemp < iNum; iTemp++)
    {
        cClassId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x0);
        cInstanceId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x1);
        if ((cClassId == dneComObject->classId) && (cInstanceId == dneComObject->instanceId))
        {
            search_flag = TRUE;
            iOffset = (DEVICENET_DATA_SIZE * (iTemp + 1));
            break;
        }
    }
    if (FALSE == search_flag)
    {
        if (iNum != 0xFF)
        {
            iNum++;
            *((unsigned *)(reg_VirthBaseAddr)) = iNum;
        }
        iOffset = (DEVICENET_DATA_SIZE * iNum);
    }

    /* Write the memory */
    DEBUG_INFO("the iOffset is 0x%x", iOffset);
    // *((uint8_t *)(reg_VirthBaseAddr + iOffset)) = dneComObject->serviceId;
    *((uint8_t *)(reg_VirthBaseAddr + iOffset)) = dneComObject->classId;
    *((uint8_t *)(reg_VirthBaseAddr + iOffset + 0x1)) = dneComObject->instanceId;
    *((uint8_t *)(reg_VirthBaseAddr + iOffset + 0x2)) = dneComObject->msg_alloc;
    DEBUG_INFO("msg_alloc is 0x%x", dneComObject->msg_alloc);

    if ((dneComObject->msg_alloc & 0x02) == 0x02)
    {
        DNET_Polliong_Flag = TRUE;
    }

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
    return NO_ERROR;
}

int DNetDeleteStatus(DnetCommObject *dneComObject)
{
    int iRet = 0;
    uint8_t cClassId = 0;
    uint8_t cInstanceId = 0;
    uint8_t cConnStatus = 0;
    uint8_t iNum = 0;
    uint32_t iTemp = 0;
    uint32_t iOffset = 0;

    _Bool search_flag = FALSE;
    unsigned long long reg_VirthBaseAddr;

    if (NULL == dneComObject)
    {
        printf("the parameters is wrong\n");
        return DNET_WRITE_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    /* the num of data */
    iNum = *(unsigned *)(reg_VirthBaseAddr);
    DEBUG_INFO("the num of data is %d", iNum);

    /* judge whether the data already exist in the memory */
    for (iTemp = 0; iTemp < iNum; iTemp++)
    {
        cClassId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x0);
        cInstanceId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x1);
        if ((cClassId == dneComObject->classId) && (cInstanceId == dneComObject->instanceId))
        {
            search_flag = TRUE;
            iOffset = (DEVICENET_DATA_SIZE * (iTemp + 1));
            break;
        }
    }
    if (FALSE == search_flag)
    {
        return DNET_READ_ERROR;
    }

    /* Write the memory */
    DEBUG_INFO("the iOffset is 0x%x", iOffset);
    // *((uint8_t *)(reg_VirthBaseAddr + iOffset)) = dneComObject->serviceId;
    *((uint8_t *)(reg_VirthBaseAddr + iOffset)) = dneComObject->classId;
    *((uint8_t *)(reg_VirthBaseAddr + iOffset + 0x1)) = dneComObject->instanceId;
    cConnStatus = *((uint8_t *)(reg_VirthBaseAddr + iOffset + 0x2));
    *((uint8_t *)(reg_VirthBaseAddr + iOffset + 0x2)) = cConnStatus & (~dneComObject->msg_alloc);
    DEBUG_INFO("msg_alloc is 0x%x", dneComObject->msg_alloc);

    if ((dneComObject->msg_alloc & 0x02) == 0x02)
    {
        DNET_Polliong_Flag = FALSE;
    }

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
    return NO_ERROR;
}

int DNetCheckStatus(DnetCommObject *dneComObject)
{
    int iRet = 0;
    uint8_t cClassId = 0;
    uint8_t cInstanceId = 0;
    uint8_t cConnStatus = 0;
    uint32_t iNum = 0;
    uint32_t iTemp = 0;
    uint32_t iOffset = 0;
    _Bool search_flag = FALSE;
    unsigned long long reg_VirthBaseAddr;

    /* judge whether the parameters are in range*/
    if (NULL == dneComObject)
    {
        printf("the parameters is wrong\n");
        return PARAM_ERROR;
    }

    /* map the mode register address */
    iRet = mem_mmap(DEVICENET_BASE_ADDR, DEVICENET_BASE_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    /* the num of data */
    iNum = *(uint8_t *)(reg_VirthBaseAddr);

    /* judge whether the data already exist in the memory */
    for (iTemp = 0; iTemp < iNum; iTemp++)
    {
        cClassId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x0);
        cInstanceId = *(uint8_t *)(reg_VirthBaseAddr + (DEVICENET_DATA_SIZE * (iTemp + 1)) + 0x1);
        if ((cClassId == dneComObject->classId) && (cInstanceId == dneComObject->instanceId))
        {
            search_flag = TRUE;
            iOffset = (DEVICENET_DATA_SIZE * (iTemp + 1));
            break;
        }
    }
    if (FALSE == search_flag)
    {
        return DNET_READ_ERROR;
    }

    /* Read the memory */
    cConnStatus = *(uint8_t *)(reg_VirthBaseAddr + iOffset + 0x2);
    DEBUG_INFO("Conn Status = 0x%x", cConnStatus);

    if (DNET_DISCONN_STATUS == cConnStatus)
    {
        iRet = DNET_NOCONN_ERROR;
    }
    else if (DNET_MSG_POLL_CONN_STATUS == (cConnStatus & 0x03))
    {
        iRet = DNET_MSG_POLL_CONN_STATUS;
        mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
        return iRet;
    }
    else if (DNET_POLLING_CONN_STATUS == (cConnStatus & 0x02))
    {
        iRet = DNET_POLLING_CONN_STATUS;
        mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
        return iRet;
    }
    else if (DNET_MSG_CONN_STATUS == (cConnStatus & 0x01))
    {
        iRet = DNET_MSG_CONN_STATUS;
        mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
        return iRet;
    }
    else
    {
        iRet = GENERAL_ERROR;
    }
    // memcpy(dneObject->val, (uint8_t *)(reg_VirthBaseAddr + iOffset + 0x3 + dneObject->address), dneObject->dataSize);

    mem_unmap(reg_VirthBaseAddr, DEVICENET_BASE_SIZE);
    return iRet;
}

int InitDataSize(DnetCommObject *dneComObject)
{
    int iTemp = 0;
    _Bool search_flag = FALSE;

    /* judge whether the data already exist in the memory */
    DEBUG_INFO("dneComObject->serviceId = 0x%x\n", dneComObject->serviceId);
    DEBUG_INFO("dneComObject->classId = 0x%x\n", dneComObject->classId);
    DEBUG_INFO("dneComObject->instanceId = 0x%x\n", dneComObject->instanceId);
    DEBUG_INFO("dneComObject->attributeId = 0x%x\n", dneComObject->attributeId);
    for (iTemp = 0; iTemp < DNET_MSG_MAX_NUM; iTemp++)
    {
        if ((gDNetData[iTemp].serviceId == dneComObject->serviceId) && (gDNetData[iTemp].classId == dneComObject->classId) && (gDNetData[iTemp].instanceId == dneComObject->instanceId) && (gDNetData[iTemp].attributeId == dneComObject->attributeId))
        {
            search_flag = TRUE;
            dneComObject->index = iTemp;
            dneComObject->dataSize = gDNetData[iTemp].datasize;
            break;
        }
    }
    if (FALSE == search_flag)
    {
        printf("the data is not in the range\n");
        return DNET_READ_ERROR;
    }

    return NO_ERROR;
}

int ReceiveRequest(DnetCommObject *dneComObject, DnetPollingObject *dnePollingObject, int32_t sock_fd)
{
    int iRet = 0;
    int nbytes;
    fd_set readfd;
    // struct timeval time_out;
    struct canfd_frame cfd;

    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // DEBUG_INFO("can0 can_ifindex = 0x%x", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

DNet_read:
    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }

    nbytes = read(sock_fd, &cfd, CANFD_MTU);

    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return DNET_CONNECT_ERROR;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (DEVICENET_GROUP_2 == (cfd.can_id >> 9))
    {
        if (dnePollingObject->s_macId == ((cfd.can_id >> 3) & 0x3F))
        {
            dneComObject->d_mesId = cfd.can_id & 0x07;
            dneComObject->d_macId = cfd.data[0] & 0x3F;
            if (OPEN_EXPLICIT_CONNECT_REQ_SERVICE_ID == cfd.data[1])
            {
                dneComObject->classId = cfd.data[2];
                dneComObject->instanceId = cfd.data[3];
                dneComObject->msg_alloc = cfd.data[4];
                return DNET_CON_EXPLICIT_REQ;
            }
            else if (GET_ATTRIBUTE_SINGLE_REQ_SERVICE_ID == cfd.data[1])
            {
                dneComObject->serviceId = cfd.data[1];
                dneComObject->classId = cfd.data[2];
                dneComObject->instanceId = cfd.data[3];
                dneComObject->attributeId = cfd.data[4];
                return DNET_GET_ATTRIBUTE_REQ;
            }
            else if (SET_ATTRIBUTE_SINGLE_REQ_SERVICE_ID == cfd.data[1])
            {
                dneComObject->serviceId = cfd.data[1];
                dneComObject->classId = cfd.data[2];
                dneComObject->instanceId = cfd.data[3];
                dneComObject->attributeId = cfd.data[4];
                iRet = DNetCheckStatus(dneComObject);
                if ((DNET_MSG_POLL_CONN_STATUS != iRet) && (DNET_MSG_CONN_STATUS != iRet))
                {
                    printf("the connect does not exist\n");
                    return iRet;
                }
                iRet = InitDataSize(dneComObject);
                if (NO_ERROR != iRet)
                {
                    return iRet;
                }

                if (dneComObject->dataSize < 3)
                {
                    memcpy(dneComObject->val, &cfd.data[5], dneComObject->dataSize);
                }
                else
                {
                    memcpy(dneComObject->val, &cfd.data[5], 3);
                }
                return DNET_SET_ATTRIBUTE_REQ;
            }
            else if (CLOSE_EXPLICIT_CONNECT_REQ_SERVICE_ID == cfd.data[1])
            {
                dneComObject->classId = cfd.data[2];
                dneComObject->instanceId = cfd.data[3];
                dneComObject->msg_alloc = cfd.data[4];
                return DNET_DISCON_EXPLICIT_REQ;
            }
            else
            {
                DEBUG_INFO("the service ID is invalid\n");
                goto DNet_read;
            }
        }
        else
        {
            printf("the source MacID is invalid\n");
            goto DNet_read;
        }
    }
    else
    {
        DEBUG_INFO("group Id is wrong\n");
        DEBUG_INFO("DNET_CONNECT_ERROR");
        goto DNet_read;
    }

    return NO_ERROR;
}

int MidSegmentRev(DnetCommObject *dneObject, int32_t sock_fd, int iNum)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    int iRet = 0;
    int nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
middle_segment_read:
    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = DNET_READ_SEGMENT_REQ_DATASIZE;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_MIDDLE_SEGMENT << 6) | iNum;
    memcpy(frame.data + 2, dneObject->val + 5 + (6 * (iNum - 1)), sizeof(uint8_t) * 6);

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return 1;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (((DEVICENET_ACK_SEGMENT << 6) | iNum) != cfd.data[1])
    {
        printf("the segment mesg is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (DEVICENET_ACK_SEGMENT_SUCCESS != cfd.data[2])
    {
        printf("the ack is invalid\ntry to send again\n");
        goto middle_segment_read;
    }

    return NO_ERROR;
}

int EndSegmentRev(DnetCommObject *dneObject, int32_t sock_fd, int iNum)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    int iRet = 0;
    int nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
end_segment_read:
    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = dneObject->dataSize - 5 + 2;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_END_SEGMENT << 6) | iNum;
    memcpy(frame.data + 2, dneObject->val + 5 + (6 * (iNum - 1)), sizeof(uint8_t) * (dneObject->dataSize - 5));

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return DNET_TRANSFER_ERROR;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (((DEVICENET_ACK_SEGMENT << 6) | iNum) != cfd.data[1])
    {
        printf("the segment mesg is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (DEVICENET_ACK_SEGMENT_SUCCESS != cfd.data[2])
    {
        printf("the ack is invalid\ntry to send again\n");
        goto end_segment_read;
    }

    return NO_ERROR;
}

int GetAttributeDateSegment(DnetCommObject *dneObject, int32_t sock_fd)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    int iRet = 0;
    int iCount = 0;
    int iNum = 0;
    int nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Judge the count of transfer */

    if (0 == ((dneObject->dataSize - 5) % 6))
    {
        iCount = ((dneObject->dataSize - 5) / 6) + 1;
    }
    else
    {
        iCount = ((dneObject->dataSize - 5) / 6) + 2;
    }

    DEBUG_INFO("the iCount is %d", iCount);
    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

first_segment_read:
    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = DNET_READ_SEGMENT_REQ_DATASIZE;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = DEVICENET_FIRST_SEGMENT;
    frame.data[2] = GET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID;
    memcpy(frame.data + 3, dneObject->val, sizeof(uint8_t) * 5);

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_CONNECT_ERROR;
    }

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return DNET_TRANSFER_ERROR;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (((DEVICENET_ACK_SEGMENT << 6) | DEVICENET_FIRST_SEGMENT) != cfd.data[1])
    {
        printf("the segment mesg is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (DEVICENET_ACK_SEGMENT_SUCCESS != cfd.data[2])
    {
        printf("the ack is invalid\ntry to send again\n");
        goto first_segment_read;
    }

    iNum++;

    if (2 == iCount)
    {
        iRet = EndSegmentRev(dneObject, sock_fd, iNum);
        if (NO_ERROR != iRet)
        {
            return DNET_TRANSFER_ERROR;
        }
        return NO_ERROR;
    }

    for (; iNum < (iCount - 1); iNum++)
    {
        iRet = MidSegmentRev(dneObject, sock_fd, iNum);
        if (NO_ERROR != iRet)
        {
            return DNET_TRANSFER_ERROR;
        }
    }

    iRet = EndSegmentRev(dneObject, sock_fd, iNum);
    if (NO_ERROR != iRet)
    {
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int GetAttributeDateSingle(DnetCommObject *dneComObject, int32_t sock_fd)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    // int iRet = 0;

    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (DEVICENET_GROUP_2 << 9) | (dneComObject->s_macId << 3) | (dneComObject->s_mesId & 0x03);
    frame.can_id = can_id;
    frame.can_dlc = 2 + dneComObject->dataSize;

    frame.data[0] = dneComObject->d_macId;
    frame.data[1] = GET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID;
    memcpy(frame.data + 2, dneComObject->val, sizeof(uint8_t) * dneComObject->dataSize);

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int RetErr(DnetCommObject *dneObject, int32_t sock_fd)
{
    uint16_t can_id;
    // int iRet = 0;
    ssize_t sszRet = 0;

    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = 4;

    frame.data[0] = dneObject->d_macId;
    frame.data[1] = (1 << 7) & ERROR_SERVICE_ID;
    frame.data[2] = INVALID_ATTRIBUTE_ACK;
    frame.data[3] = 0xFF;

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int ConnectExplicit(DnetCommObject *dneComObject, int32_t sock_fd)
{
    int iRet = 0;
    uint16_t can_id;
    ssize_t sszRet = 0;

    can_id = (DEVICENET_GROUP_2 << 9) | (dneComObject->s_macId << 3) | (dneComObject->s_mesId & 0x03);
    frame.can_id = can_id;
    frame.can_dlc = UCMM_EXPLICIT_ACK_DATASIZE;

    // DEBUG_INFO("dneObject->d_macId = 0x%2x", dneObject->d_macId);
    frame.data[0] = dneComObject->d_macId;
    // DEBUG_INFO("frame.data[0] = 0x%2x", frame.data[0]);
    frame.data[1] = OPEN_EXPLICIT_CONNECT_SCK_SERVICE_ID;
    frame.data[2] = DEVICENET_MES_STRUCT_8_8;
    // frame.data[3] = dneComObject->s_mesId;
    // frame.data[4] = dneObject->instanceId;

    iRet = DNetSaveStatus(dneComObject);
    if (NO_ERROR != iRet)
    {
        printf("fail to save DNET connect status\n");
    }

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_CONNECT_ERROR;
    }

    return iRet;
}

int DisconnectExplicit(DnetCommObject *dneComObject, int32_t sock_fd)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    int iRet = 0;

    iRet = DNetCheckStatus(dneComObject);
    if ((DNET_MSG_POLL_CONN_STATUS != iRet) && (DNET_MSG_CONN_STATUS != iRet) &&(DNET_POLLING_CONN_STATUS != iRet))
    {
        printf("the connect does not exist\n");
        return iRet;
    }
    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (DEVICENET_GROUP_2 << 9) | (dneComObject->s_macId << 3) | (dneComObject->s_mesId & 0x03);
    frame.can_id = can_id;
    frame.can_dlc = UCMM_EXPLICIT_CLOSE_ACK_DATASIZE;

    DEBUG_INFO("dneComObject->d_macId = 0x%2x", dneComObject->d_macId);
    frame.data[0] = dneComObject->d_macId;
    DEBUG_INFO("frame.data[0] = 0x%2x", frame.data[0]);
    frame.data[1] = CLOSE_EXPLICIT_CONNECT_SCK_SERVICE_ID;

    iRet = DNetDeleteStatus(dneComObject);
    if (NO_ERROR != iRet)
    {
        printf("fail to delete DNET connect status\n");
    }

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_DISCONNECT_ERROR;
    }

    return iRet;
}
/*********************************************************************************
[function name] DNetRead

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetAttributeDateSingle(DnetCommObject *dneComObject, int32_t sock_fd)
{
    uint16_t can_id;
    ssize_t sszRet = 0;

    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (DEVICENET_GROUP_2 << 9) | (dneComObject->s_macId << 3) | (dneComObject->s_mesId & 0x03);
    frame.can_id = can_id;
    if (dneComObject->dataSize > 3)
    {
        frame.can_dlc = 5;
    }
    else
    {
        frame.can_dlc = 2 + dneComObject->dataSize;
    }

    frame.data[0] = dneComObject->d_macId;
    frame.data[1] = SET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID;
    if (dneComObject->dataSize > 3)
    {
        memcpy(frame.data + 2, dneComObject->val, 3);
    }
    else
    {
        memcpy(frame.data + 2, dneComObject->val, sizeof(uint8_t) * dneComObject->dataSize);
    }

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        // close(sock_fd);
        return DNET_CONNECT_ERROR;
    }

    return NO_ERROR;
}

int FirstSegmentSend(DnetCommObject *dneObject, int32_t sock_fd, int iNum)
{
    uint16_t can_id;
    uint32_t iTmp;
    ssize_t sszRet = 0;
    uint32_t nbytes;
    struct canfd_frame cfd;

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = DNET_WRITE_SEGMENT_REQ_DATASIZE;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_FIRST_SEGMENT << 6) | iNum;
    for (iTmp = 0; iTmp < 6; iTmp++)
    {
        frame.data[iTmp + 2] = dneObject->val[iTmp + (6 * iNum)];
    }

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return 1;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf(" d_mesId error\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf(" d_macId error\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf(" s_macId error\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (DEVICENET_ACK_SEGMENT != (cfd.data[1] >> 6))
    {
        printf(" DEVICENET_ACK_SEGMENT error\n");
        return DNET_TRANSFER_ERROR;
    }

    if (iNum != (cfd.data[1] & 0x3F))
    {
        printf(" iNum error\n");
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int MidSegmentSend(DnetCommObject *dneObject, int32_t sock_fd, int iNum)
{
    uint16_t can_id;
    int iRet = 0;
    ssize_t sszRet = 0;
    uint32_t nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return 1;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (((DEVICENET_MIDDLE_SEGMENT << 6) | iNum) != cfd.data[1])
    {
        printf("the segment is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    memcpy(dneObject->val + (6 * iNum), cfd.data + 2, sizeof(uint8_t) * 6);

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = 3;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_ACK_SEGMENT << 6) | iNum;
    frame.data[2] = 0x00;

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int EndSegmentSend(DnetCommObject *dneObject, int32_t sock_fd, int iNum)
{
    uint16_t can_id;
    int iRet = 0;
    ssize_t sszRet = 0;
    uint32_t nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return DNET_TRANSFER_ERROR;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    /* Determine the type of segment
        bit0-bit5: the count of segment
        bit6-bit7: the type of segment:
            0b00: the first segment
            0b01: the middle segment
            0b10: the end segment
            0b11: the ack of segment*/
    if (((DEVICENET_END_SEGMENT << 6) | iNum) != cfd.data[1])
    {
        printf("the segment is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    DEBUG_INFO("start to memcpy");
    DEBUG_INFO("iNum = %d\n", iNum);
    DEBUG_INFO("dneObject->dataSize - 6 = %d\n", dneObject->dataSize - 6);
    memcpy(dneObject->val + (6 * iNum), cfd.data + 2, sizeof(uint8_t) * (dneObject->dataSize - 6));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = 3;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_ACK_SEGMENT << 6) | iNum;
    frame.data[2] = 0x00;

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    return NO_ERROR;
}

int SetAttributeDateSegment(DnetCommObject *dneObject, int32_t sock_fd)
{
    uint16_t can_id;
    ssize_t sszRet = 0;
    int iRet = 0;
    int iCount = 0;
    int iNum = 0;
    int nbytes;
    struct canfd_frame cfd;
    fd_set readfd;

    /* Judge the count of transfer */

    if (0 == (dneObject->dataSize % 6))
    {
        iCount = (dneObject->dataSize / 6);
    }
    else
    {
        iCount = (dneObject->dataSize / 6) + 1;
    }

    DEBUG_INFO("the iCount is %d", iCount);
    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    /* set the filter rules */
    // setsockopt(sock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = 2;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = SET_ATTRIBUTE_SINGLE_SCK_SERVICE_ID;

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_CONNECT_ERROR;
    }

    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);
    iRet = select(sock_fd + 1, &readfd, NULL, NULL, &timeout);
    if (0 >= iRet)
    {
        DEBUG_INFO("DeviceNet Connect timeout\n");
        return DNET_CONNECT_ERROR;
    }
    nbytes = read(sock_fd, &cfd, CANFD_MTU);
    if (nbytes == CANFD_MTU)
    {
        DEBUG_INFO("got CAN FD frame with length %d", cfd.len);
        /* cfd.flags contains valid data */
    }
    else if (nbytes == CAN_MTU)
    {
        DEBUG_INFO("got legacy CAN frame with length %d", cfd.len);
        /* cfd.flags is undefined */
    }
    else
    {
        fprintf(stderr, "read: invalid CAN(FD) frame\n");
        return DNET_TRANSFER_ERROR;
    }

    /* the content can be handled independently from the received MTU size */

    DEBUG_INFO("can_id: %X data length: %d data: ", cfd.can_id, cfd.len);
    for (int i = 0; i < cfd.len; i++)
    {
        DEBUG_INFO("%02X ", cfd.data[i]);
    }

    if (dneObject->d_mesId != (cfd.can_id >> 6))
    {
        printf("destination message ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->d_macId != (cfd.can_id & 0x3F))
    {
        printf("destination MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (dneObject->s_macId != (cfd.data[0] & 0x3F))
    {
        printf("Source MAC ID is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    if (DEVICENET_FIRST_SEGMENT != cfd.data[1])
    {
        printf("the segment is invalid\n");
        return DNET_TRANSFER_ERROR;
    }

    memcpy(dneObject->val, cfd.data + 2, sizeof(uint8_t) * 6);

    can_id = (dneObject->s_mesId << 6) | dneObject->s_macId;
    frame.can_id = can_id;
    frame.can_dlc = 3;

    frame.data[0] = dneObject->d_macId | 0x80;
    frame.data[1] = (DEVICENET_ACK_SEGMENT << 6) | DEVICENET_FIRST_SEGMENT;
    frame.data[2] = 0x00;

    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf(" can send error\n");
        close(sock_fd);
        return DNET_TRANSFER_ERROR;
    }

    iNum++;

    for (; iNum < iCount; iNum++)
    {
        if (iNum != iCount - 1)
        {
            iRet = MidSegmentSend(dneObject, sock_fd, iNum);
            if (NO_ERROR != iRet)
            {
                return DNET_TRANSFER_ERROR;
            }
        }
        else
        {
            iRet = EndSegmentSend(dneObject, sock_fd, iNum);
            if (NO_ERROR != iRet)
            {
                return DNET_TRANSFER_ERROR;
            }
        }
    }
    return NO_ERROR;
}

int DNetPolling(DnetPollingObject *dnePollingObject, int32_t sock_fd)
{
    ssize_t sszRet = 0;
    // int32_t iRet = 0;
    uint32_t iTemp = 0;
    uint32_t iSendCount = 0;

    // DNetInit();
    /* judge if the parameters are invalid */
    if (FALSE == DeviceNet_Init_Flag)
    {
        printf("please init the DeviceNet firstly\n");
        return GENERAL_ERROR;
    }
    if (NULL == dnePollingObject)
    {
        printf("the parameters is wrong\n");
        return PARAM_ERROR;
    }

    strncpy(ifr.ifr_name, CAN_DEV_DNET, sizeof(ifr.ifr_name));
    ioctl(sock_fd, SIOCGIFINDEX, &ifr);
    // printf("can0 can_ifindex = %x\n", ifr.ifr_ifindex);

    /* Setting the CAN protocol */
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    /* bind the socket to a CAN interface */
    bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr));

    frame.can_id = (DEVICENET_GROUP_1 << 9) | (dnePollingObject->s_msgId << 6) | (dnePollingObject->s_macId);

    for (iSendCount = 0; iSendCount < 19; iSendCount++)
    {

        frame.can_dlc = DNET_POLLING_SEGMENT_ACK_DATASIZE;
        if (0 == iSendCount)
        {
            frame.data[0] = (DEVICENET_FIRST_SEGMENT << 6) | iSendCount;
        }
        else
        {
            frame.data[0] = (DEVICENET_MIDDLE_SEGMENT << 6) | iSendCount;
        }
        // DEBUG_INFO("frame data[0] = %d\n", frame.data[0]);
        for (iTemp = 0; iTemp < 7; iTemp++)
        {
            frame.data[iTemp + 1] = dnePollingObject->send[iTemp + (iSendCount * 7)];
            usleep(1);
            // DEBUG_INFO("frame data[%d] = %d\n", iTemp + 1, frame.data[iTemp + 1]);
        }

        sszRet = write(sock_fd, &frame, sizeof(frame));
        if (sizeof(struct can_frame) > sszRet)
        {
            printf("the sszRet is %ld\n", sszRet);
            printf(" can send error\n");
            close(sock_fd);
            return DNET_POLLING_ERROR;
        }
        // usleep(10);
    }

    /* send the end data */
    frame.can_dlc = 0x04;
    frame.data[0] = (DEVICENET_END_SEGMENT << 6) | iSendCount;
    for (iTemp = 0; iTemp < 3; iTemp++)
    {
        frame.data[iTemp + 1] = dnePollingObject->send[iTemp + (iSendCount * 7)];
        usleep(1);
    }
    sszRet = write(sock_fd, &frame, sizeof(frame));
    if (sizeof(struct can_frame) > sszRet)
    {
        printf("the sszRet is %ld\n", sszRet);
        printf(" can send error\n");
        close(sock_fd);
        return DNET_POLLING_ERROR;
    }

    close(sock_fd);
    return NO_ERROR;
}

int GetAttributeComm(DnetCommObject *dneComObject, int32_t sock_fd)
{
    int iRet = 0;
    int iTemp = 0;

    iRet = DNetCheckStatus(dneComObject);
    if ((DNET_MSG_POLL_CONN_STATUS != iRet) && (DNET_MSG_CONN_STATUS != iRet))
    {
        printf("the connect does not exist\n");
        return iRet;
    }
    iRet = InitDataSize(dneComObject);
    if (NO_ERROR != iRet)
    {
        return iRet;
    }

    for (iTemp = 0; iTemp < dneComObject->dataSize; iTemp++)
    {
        dneComObject->val[iTemp] = gDNetData[dneComObject->index].data[iTemp];
    }
    if (6 >= dneComObject->dataSize)
    {
        iRet = GetAttributeDateSingle(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            close(sock_fd);
            return DNET_READ_ERROR;
        }
    }
    else
    {
        iRet = GetAttributeDateSegment(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            close(sock_fd);
            return DNET_READ_ERROR;
        }
    }

    return NO_ERROR;
}

int SetAttributeComm(DnetCommObject *dneComObject, int32_t sock_fd)
{
    int iRet = 0;
    int iTemp = 0;

    if (7 >= dneComObject->dataSize)
    {
        iRet = SetAttributeDateSingle(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            close(sock_fd);
            return DNET_READ_ERROR;
        }
    }
    else
    {
        iRet = SetAttributeDateSegment(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            close(sock_fd);
            return DNET_READ_ERROR;
        }
    }
    for (iTemp = 0; iTemp < dneComObject->dataSize; iTemp++)
    {
        gDNetData[dneComObject->index].data[iTemp] = dneComObject->val[iTemp];
    }

    return NO_ERROR;
}

int DNetComm(DnetCommObject *dneComObject, DnetPollingObject *dnePollingObject)
{
    int32_t sock_fd;
    int32_t iRet = 0;

    // DEBUG_INFO("DNetInit");
    // DNetInit();

    /* judge if the parameters are invalid */
    if (FALSE == DeviceNet_Init_Flag)
    {
        printf("please init the DeviceNet firstly\n");
        return GENERAL_ERROR;
    }
    if (NULL == dneComObject)
    {
        printf("the parameters is wrong\n");
        return PARAM_ERROR;
    }

    sock_fd = socket(PF_CAN, SOCK_RAW, CAN_RAW);

    // dneObject->serviceId = SET_ATTRIBUTE_SINGLE_REQ_SERVICE_ID;

    timeout.tv_usec = timeout_usec;
    timeout.tv_sec = timeout_sec;
    /* init the explicit message connection */
    iRet = ReceiveRequest(dneComObject, dnePollingObject, sock_fd);

    switch (iRet)
    {
    case DNET_CON_EXPLICIT_REQ:
    {
        iRet = ConnectExplicit(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            printf("connect error\n");
            return iRet;
        }
        break;
    }
    case DNET_DISCON_EXPLICIT_REQ:
    {
        iRet = DisconnectExplicit(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            printf("Disconnect error\n");
            return iRet;
        }
        break;
    }
    case DNET_SET_ATTRIBUTE_REQ:
    {
        iRet = SetAttributeComm(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            printf("Set Attribute error\n");
            return iRet;
        }
        break;
    }
    case DNET_GET_ATTRIBUTE_REQ:
    {
        iRet = GetAttributeComm(dneComObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            printf("Get Attribute error\n");
            return iRet;
        }
        break;
    }
    default:
    {
        if (TRUE == DNET_Polliong_Flag)
        {
            DNetPollingRead(dnePollingObject);
            iRet = DNetPolling(dnePollingObject, sock_fd);
            if (NO_ERROR != iRet)
            {
                printf("Polling communicate error\n");
                return DNET_POLLING_ERROR;
            }
        }
        close(sock_fd);
        // free(dneObject->val);
        return iRet;
    }
    }

    if (TRUE == DNET_Polliong_Flag)
    {
        DNetPollingRead(dnePollingObject);
        iRet = DNetPolling(dnePollingObject, sock_fd);
        if (NO_ERROR != iRet)
        {
            printf("Polling communicate error\n");
            return DNET_POLLING_ERROR;
        }
    }

    close(sock_fd);
    return NO_ERROR;
}

void *DNET_Communicate_thread(void *args)
{
    int ctrl_ret = 0;
    DnetCommObject *dneComObject = NULL;
    DnetPollingObject *dnePollingObject = NULL;

    dneComObject = malloc(sizeof(DnetCommObject));
    if (dneComObject == NULL)
    {
        printf("malloc error\n");
        free(dneComObject);
        pthread_exit(NULL);
        return NULL; /* Warning measures for static analysis tools */
    }
    dnePollingObject = malloc(sizeof(DnetPollingObject));
    if (dnePollingObject == NULL)
    {
        printf("malloc error\n");
        free(dnePollingObject);
        pthread_exit(NULL);
        return NULL; /* Warning measures for static analysis tools */
    }
    dneComObject->s_macId = 0x21;
    dnePollingObject->s_macId = 0x21;
    dnePollingObject->s_msgId = 0x00;
    for (int i = 0; i < 136; i++)
    {
        dnePollingObject->send[i] = i;
    }
    timeout_usec = timeout.tv_usec;
    timeout_sec = timeout.tv_sec;

    while (TRUE == DNET_Commu_Flag)
    {
        // sem_wait(&sem[0]);
        pthread_mutex_lock(&mutex);
        ctrl_ret = DNetComm(dneComObject, dnePollingObject);

        if (NO_ERROR == ctrl_ret)
        {
            DEBUG_INFO("DeviceNet Communicate successfully\n");
        }
        else
        {
            DEBUG_INFO("fail to communicate DeviceNet\n");
        }

        pthread_mutex_unlock(&mutex);
        // sem_post(&sem[1]);
    }
    free(dneComObject);
    free(dnePollingObject);
    pthread_exit(NULL);
    return NULL;
}

int DNetCommuThread(struct timeval *time)
{
    uint32_t iRet = 0;
    pthread_mutex_init(&mutex, NULL);
    timeout.tv_sec = time->tv_sec;
    timeout.tv_usec = time->tv_usec;
    DNET_Commu_Flag = TRUE;
    iRet = pthread_create(&DNET_thread, NULL, DNET_Communicate_thread, NULL);
    if (iRet != 0)
    {
        printf("fail to create explicit thread\n");
        DNET_Commu_Flag = FALSE;
        return GENERAL_ERROR;
    }

    return NO_ERROR;
}

int ThreadExit()
{
    if (TRUE == DNET_Commu_Flag)
    {
        DNET_Commu_Flag = FALSE;
        pthread_join(DNET_thread, NULL);
    }

    return NO_ERROR;
}
/*********************************************************************************
[function name] ResetCommunication

[arguments]
None


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int ResetCommunication()
{
    uint8_t error_txbuffer[ERROR_DATASIZE]; /* the  transfer data */
    uint8_t error_checksum;                 /* define a buffer to store the data which is used to calculate the checksum */
    uint16_t error_header = SPI_HEADER;
    uint16_t error_send_cmd = ERROR_SEND_CMD;
    uint16_t error_datasize = 0;
    uint8_t error_end = SPI_TRAILER;
    uint8_t error_ret;
    uint8_t error_clear_buffer[100];

    /* intialize SPI */
    // SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED); // ??

    /* store the transfer data */
    memcpy(error_txbuffer, &error_header, sizeof(error_header));
    memcpy(&error_txbuffer[2], &error_send_cmd, sizeof(error_send_cmd));
    memcpy(&error_txbuffer[4], &error_datasize, sizeof(error_datasize));
    error_checksum = Get_CheckSum(error_txbuffer, CC_ERROR_LENGTH);
    memcpy(&error_txbuffer[6], &error_checksum, sizeof(error_checksum));
    memcpy(&error_txbuffer[7], &error_end, sizeof(error_end));

    error_ret = SPI_SendData(error_txbuffer, ERROR_DATASIZE); /* transfer the buffer */
/////////////////////////
#if 0
    /* print the header of receiver */
    printf("***********************************************\n");
    DEBUG_INFO("send:\n");
    for (int i = 0; i < ERROR_DATASIZE; i++)
    {
        DEBUG_INFO("%02x  ", error_txbuffer[i]);
    }
    printf("\n");
#endif
    if (NO_ERROR != error_ret)
    {
        return error_ret;
    }
    memset(error_clear_buffer, 0, 100);
    SPI_SendData(error_clear_buffer, 100);
#if 0
    /* print the header of receiver */
    DEBUG_INFO("send:\n");
    for (int i = 0; i < 100; i++)
    {
        DEBUG_INFO("%02x  ", error_clear_buffer[i]);
    }
    printf("\n");
#endif
    printf("reset the Communication_api\n");
    Delay_Ms(ERROR_DEALY_TIME);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SDORead

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SDORead(int Address, short DataSize, int *val)
{
    uint8_t txbuffer[SDO_TX_DATASIZE]; /* the  transfer data */
    uint8_t checksum;                  /* define a buffer to store the data which is used to calculate the checksum */
    // uint8_t rxbuffer[SDO_RX_DATASIZE + DataSize]; /* the  receive data */
    uint8_t *rxbuffer = NULL;  /* the  receive data */
    RXBUFF_HEADER *rx_pointer; /* define a struct pointer to analysis the receive data more quickly */
    uint16_t header = SPI_HEADER;
    uint16_t read_result = SDO_READ_SUCCESS_FLAG;
    uint16_t sdo_read_cmd = SDO_READ_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint8_t end = SPI_TRAILER;
    uint32_t sdo_read_list;
    uint8_t error_num = 0;
    uint8_t count = 0;
    uint8_t ret = 0;
    _Bool Serval_Read_Flag = FALSE;
    _Bool Receive_End_Flag = FALSE;
    _Bool sdo_rd_address_flag = FALSE;

    // printf("address: %x\n", Address);
    /* judge the validity of parameters */
    for (sdo_read_list = 0; sdo_read_list < readsdo_listnum; sdo_read_list++)
    {
        // printf("%x\n", RF_read_sdo_area[sdo_read_list].address);
        if (Address == RF_read_sdo_area[sdo_read_list].address)
        {
            sdo_rd_address_flag = TRUE;
        }

        if (sdo_rd_address_flag == TRUE)
        {
            if (DataSize > RF_read_sdo_area[sdo_read_list].datasize)
            {
                printf("the datasize is not in the range\n");
                return PARAM_ERROR;
            }
        }
        if (sdo_rd_address_flag == TRUE)
            break;
    }
    if (FALSE == sdo_rd_address_flag)
    {
        printf("the address is wrong\n");
        return PARAM_ERROR;
    }
    if (NULL == val)
    {
        printf("the point is wrong\n");
        return PARAM_ERROR;
    }

    if (SDO_READ_DATASIZE > DataSize)
    {
        rxbuffer = (uint8_t *)malloc(SDO_RX_DATASIZE + DataSize + 1);
        if (rxbuffer == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
    }
    else
    {
        rxbuffer = (uint8_t *)malloc(SDO_RX_DATASIZE + SDO_READ_DATASIZE + 1);
        if (rxbuffer == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
        count = DataSize / SDO_READ_DATASIZE;
        if (0 != DataSize % SDO_READ_DATASIZE)
        {
            Receive_End_Flag = TRUE;
        }

        Serval_Read_Flag = TRUE;
    }

    /* intialize SPI */
    ret = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED); // ??
    if (NO_ERROR != ret)
    {
        SPI_End();
        free(rxbuffer);
        return ret;
    }

    while (ERROR_TIMES > error_num)
    {
        /* store the transfer data */
        memcpy(txbuffer, &header, sizeof(header));
        memcpy(&txbuffer[2], &sdo_read_cmd, sizeof(sdo_read_cmd));
        memcpy(&txbuffer[4], &Address, sizeof(Address));
        memcpy(&txbuffer[8], &DataSize, sizeof(DataSize));
        checksum = Get_CheckSum(txbuffer, CC_LENGTH);
        memcpy(&txbuffer[10], &checksum, sizeof(checksum));
        memcpy(&txbuffer[11], &end, sizeof(end));

        ret = SPI_SendData(txbuffer, SDO_TX_DATASIZE); /* transfer the buffer */
                                                       /////////////////////////
#if 1
        /* print the header of receiver */
        DEBUG_INFO("send:\n");
        for (int i = 0; i < SDO_TX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", txbuffer[i]);
        }
        printf("\n");
#endif
        if (NO_ERROR != ret)
        {
            SPI_End();
            free(rxbuffer);
            return ret;
        }

        usleep(DELAY_TIME); /* delay 62.5 us */

        if (TRUE != Serval_Read_Flag)
        {
            ret = SPI_ReceiveData(rxbuffer, SDO_RX_DATASIZE + DataSize); /* receive the header */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < SDO_RX_DATASIZE + DataSize; i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (sdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (DataSize != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + DataSize);

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[SDO_RX_DATASIZE + DataSize - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[SDO_RX_DATASIZE + DataSize - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                printf("output data\r\n");
                memcpy(val, rxbuffer + 6, DataSize);
                free(rxbuffer);
                SPI_End();
                return NO_ERROR;
            }
        }
        else
        {
            // rxbuffer = (uint8_t *)malloc(SDO_RX_DATASIZE + SDO_READ_DATASIZE);
            ret = SPI_ReceiveData(rxbuffer, SDO_RX_DATASIZE + SDO_READ_DATASIZE); /* receive the header */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < SDO_RX_DATASIZE + SDO_READ_DATASIZE; i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif
            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (sdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (SDO_READ_DATASIZE != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + SDO_READ_DATASIZE);

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[SDO_RX_DATASIZE + SDO_READ_DATASIZE - 2])
            {
                printf("the checksum is invalid");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[SDO_RX_DATASIZE + SDO_READ_DATASIZE - 1])
            {
                printf("the end is wrong");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                memcpy(val, rxbuffer + 6, SDO_READ_DATASIZE);
                memset(rxbuffer, 0, SDO_RX_DATASIZE + SDO_READ_DATASIZE);
            }

            for (int i = 0; i < count - 1; i++)
            {
                /* store the transfer data */
                memcpy(txbuffer, &header, sizeof(header));
                memcpy(&txbuffer[2], &sdo_read_cmd, sizeof(sdo_read_cmd));
                memcpy(&txbuffer[4], &read_result, sizeof(read_result));
                checksum = Get_CheckSum(txbuffer, 6);
                memcpy(&txbuffer[6], &checksum, sizeof(checksum));
                memcpy(&txbuffer[7], &end, sizeof(end));

                usleep(DELAY_TIME); /* delay 62.5 us */

                ret = SPI_SendData(txbuffer, SDO_TX_READS_DATA_DATASIZE); /* transfer the buffer */

#if 1
                /* print the header of receiver */
                DEBUG_INFO("send:\n");
                for (int i = 0; i < SDO_TX_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", txbuffer[i]);
                }
                printf("\n");
#endif

                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }

                usleep(DELAY_TIME); /* delay 62.5 us */

                ret = SPI_ReceiveData(rxbuffer, SDO_RX_DATASIZE + SDO_READ_DATASIZE);

                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }

#if 1 /* print the header of receiver */
                DEBUG_INFO("receive:\n");
                for (int i = 0; i < SDO_RX_DATASIZE + SDO_READ_DATASIZE; i++)
                {
                    // ccbuffer[i] = rxbuffer_1[i];
                    DEBUG_INFO("%02x  ", rxbuffer[i]);
                }
                printf("\n");
#endif
                rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

                /* judge whether the receive data is correct */
                if (header != rx_pointer->header)
                {
                    printf("the header is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                if (error_recv_cmd == rx_pointer->cmd)
                {
                    Receive_End_Flag = FALSE;
                    error_num++;
                    break;
                }
                else if (sdo_read_cmd != rx_pointer->cmd)
                {
                    printf("the cmd is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (SDO_READ_DATASIZE != rx_pointer->address_result.datasize)
                {
                    printf("the DataSize is wrong\n");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                checksum = Get_CheckSum(rxbuffer, 6 + SDO_READ_DATASIZE);

                /* judge whether the end of the receiver is valid */
                if (checksum != rxbuffer[SDO_RX_DATASIZE + SDO_READ_DATASIZE - 2])
                {
                    printf("the checksum is invalid");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                else if (end != rxbuffer[SDO_RX_DATASIZE + SDO_READ_DATASIZE - 1])
                {
                    printf("the end is wrong");
                    printf("reset the Communication_api\n");
                    Receive_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(rxbuffer);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else
                {
                    memcpy(val + ((i + 1) * (SDO_READ_DATASIZE / 4)), &rxbuffer[6], SDO_READ_DATASIZE);
                    memset(rxbuffer, 0, SDO_RX_DATASIZE + SDO_READ_DATASIZE);
                }
            }
            // free(rxbuffer); // free
        }
        if (TRUE == Receive_End_Flag)
        {
            // rxbuffer = (uint8_t *)malloc(SDO_RX_DATASIZE + (DataSize % SDO_READ_DATASIZE));
            /* store the transfer data */
            memcpy(txbuffer, &header, sizeof(header));
            memcpy(&txbuffer[2], &sdo_read_cmd, sizeof(sdo_read_cmd));
            memcpy(&txbuffer[4], &read_result, sizeof(read_result));
            checksum = Get_CheckSum(txbuffer, 6);
            memcpy(&txbuffer[6], &checksum, sizeof(checksum));
            memcpy(&txbuffer[7], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_SendData(txbuffer, SDO_TX_READS_DATA_DATASIZE); /* transfer the buffer */

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < SDO_TX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", txbuffer[i]);
            }
            printf("\n");
#endif

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_ReceiveData(rxbuffer, SDO_RX_DATASIZE + (DataSize % SDO_READ_DATASIZE));

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(rxbuffer);
                return ret;
            }

#if 1 /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < SDO_RX_DATASIZE + (DataSize % SDO_READ_DATASIZE); i++)
            {
                // ccbuffer[i] = rxbuffer_1[i];
                DEBUG_INFO("%02x  ", rxbuffer[i]);
            }
            printf("\n");
#endif
            rx_pointer = (RXBUFF_HEADER *)rxbuffer; /* pointer to receive cache */

            usleep(DELAY_TIME); /* delay 62.5 us */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (sdo_read_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if ((DataSize % SDO_READ_DATASIZE) != rx_pointer->address_result.datasize)
            {
                printf("the DataSize is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            checksum = Get_CheckSum(rxbuffer, 6 + (DataSize % SDO_READ_DATASIZE));

            /* judge whether the end of the receiver is valid */
            if (checksum != rxbuffer[SDO_RX_DATASIZE + (DataSize % SDO_READ_DATASIZE) - 2])
            {
                printf("the checksum is invalid");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }

            else if (end != rxbuffer[SDO_RX_DATASIZE + (DataSize % SDO_READ_DATASIZE) - 1])
            {
                printf("the end is wrong");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(rxbuffer);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                memcpy(val + (count * (SDO_READ_DATASIZE / 4)), rxbuffer + 6, (DataSize % SDO_READ_DATASIZE));
                memset(rxbuffer, 0, SDO_RX_DATASIZE + SDO_READ_DATASIZE);
            }
        }
        SPI_End();
        free(rxbuffer);
        return NO_ERROR;
    }
    /* Unreachable processing */
    SPI_End();
    free(rxbuffer);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SDOWrite

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	write data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/

int SDOWrite(int Address, short DataSize, int *val)
{
    uint8_t txbuf_start[SDO_TX_DATASIZE]; /* the  transfer data */
    // uint8_t txbuf_data[SDO_TX_DATASIZE + DataSize];
    uint8_t *txbuf_data = NULL; /* the transfer data */
    uint8_t *val_array = NULL;
    uint8_t checksum;                     /* define a buffer to store the data which is used to calculate the checksum */
    uint8_t rxbuf_start[SDO_RX_DATASIZE]; /* the  receive data */
    uint8_t rxbuf_data[SDO_RX_DATASIZE];
    RXBUFF_HEADER *rx_pointer; /* define a struct pointer to analysis the receive data more quickly */
    uint16_t header = SPI_HEADER;
    uint16_t sdo_write_start_cmd = SDO_WRITE_START_CMD;
    uint16_t sdo_write_data_cmd = SDO_WRITE_DATA_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint16_t sdo_write_datasize = SDO_WRITE_DATASIZE;
    uint16_t sdo_write_finish_flag = SDO_WRITE_FINISH_FLAG;
    uint32_t sdo_write_list;
    uint8_t end = SPI_TRAILER;
    uint8_t ret = 0;
    uint8_t count = 0;
    uint8_t error_num = 0;
    _Bool Serval_Write_Flag = FALSE;
    _Bool Write_End_Flag = FALSE;
    _Bool sdo_wt_address_flag = FALSE;

    /* judge the validity of parameters */
    for (sdo_write_list = 0; sdo_write_list < writesdo_listnum; sdo_write_list++)
    {
        if (Address == RF_write_sdo_area[sdo_write_list].address)
        {
            sdo_wt_address_flag = TRUE;
        }

        if (sdo_wt_address_flag == TRUE)
        {
            if ((DataSize > RF_write_sdo_area[sdo_write_list].datasize) || (DataSize < 0))
            {
                printf("the datasize is not in the range\n");
                return PARAM_ERROR;
            }
        }
        if (sdo_wt_address_flag == TRUE)
            break;
    }
    if (FALSE == sdo_wt_address_flag)
    {
        printf("the address is wrong\n");
        return PARAM_ERROR;
    }

    if (SDO_WRITE_DATASIZE > DataSize)
    {
        txbuf_data = (uint8_t *)malloc(SDO_TX_DATASIZE + DataSize + 1);
        if (txbuf_data == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
    }
    else
    {
        txbuf_data = (uint8_t *)malloc(SDO_TX_DATASIZE + SDO_WRITE_DATASIZE + 1);
        if (txbuf_data == NULL)
        {
            printf("malloc error\n");
            return MALLOC_ERROR;
        }
        count = DataSize / SDO_WRITE_DATASIZE;
        Serval_Write_Flag = TRUE;
        if (0 != DataSize % SDO_WRITE_DATASIZE)
        {
            Write_End_Flag = TRUE;
        }
    }
    val_array = (uint8_t *)malloc(DataSize * sizeof(uint8_t) + 1);
    if (val_array == NULL)
    {
        printf("malloc error\n");
        free(txbuf_data);
        return MALLOC_ERROR;
    }
    memcpy(val_array, val, DataSize);
    // if (0 == val)
    // {
    //     printf("the point is wrong");
    //     return PARAM_ERROR;
    // }

    /* intialize SPI */
    ret = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED);
    if (NO_ERROR != ret)
    {
        SPI_End();
        free(txbuf_data);
        free(val_array);
        return ret;
    }

    while (ERROR_TIMES > error_num)
    {
        /* store the transfer data */
        memcpy(txbuf_start, &header, sizeof(header));
        memcpy(&txbuf_start[2], &sdo_write_start_cmd, sizeof(sdo_write_start_cmd));
        memcpy(&txbuf_start[4], &Address, sizeof(Address));
        memcpy(&txbuf_start[8], &DataSize, sizeof(DataSize));
        checksum = Get_CheckSum(txbuf_start, CC_LENGTH);
        memcpy(&txbuf_start[10], &checksum, sizeof(checksum));
        memcpy(&txbuf_start[11], &end, sizeof(end));

        ret = SPI_SendData(txbuf_start, SDO_TX_DATASIZE); /* transfer the buffer */

        if (NO_ERROR != ret)
        {
            SPI_End();
            free(txbuf_data);
            free(val_array);
            return ret;
        }

#if 1
        /* print the header of receiver */
        DEBUG_INFO("send:\n");
        for (int i = 0; i < SDO_TX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", txbuf_start[i]);
        }
        printf("\n");
#endif

        usleep(DELAY_TIME); /* delay 62.5 us */

        ret = SPI_ReceiveData(rxbuf_start, SDO_RX_DATASIZE); /* receive the header */
        if (NO_ERROR != ret)
        {
            SPI_End();
            free(txbuf_data);
            free(val_array);
            return ret;
        }

#if 1
        /* print the header of receiver */
        DEBUG_INFO("receive:\n");
        for (int i = 0; i < SDO_RX_DATASIZE; i++)
        {
            DEBUG_INFO("%02x  ", rxbuf_start[i]);
        }
        printf("\n");
#endif
        rx_pointer = (RXBUFF_HEADER *)rxbuf_start; /* pointer to receive cache */

        /* judge whether the receive data is correct */
        if (header != rx_pointer->header)
        {
            printf("the header is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }

        if (error_recv_cmd == rx_pointer->cmd)
        {
            error_num++;
            continue;
        }
        else if (sdo_write_start_cmd != rx_pointer->cmd)
        {
            printf("the cmd is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else if (Get_CheckSum(rxbuf_start, SDO_RX_DATASIZE - 2) != rxbuf_start[SDO_RX_DATASIZE - 2])
        {
            printf("the checksum is invalid\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else if (end != rxbuf_start[SDO_RX_DATASIZE - 1])
        {
            printf("the end is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }
            error_num++;
            continue;
        }
        else
        {
            printf("start to write\n");
        }

        if (TRUE != Serval_Write_Flag)
        {
            memcpy(txbuf_data, &header, sizeof(header));
            memcpy(&txbuf_data[2], &sdo_write_data_cmd, sizeof(sdo_write_data_cmd));
            memcpy(&txbuf_data[4], &Address, sizeof(Address));
            memcpy(&txbuf_data[8], &DataSize, sizeof(DataSize));
            memcpy(&txbuf_data[10], val, DataSize);
            checksum = Get_CheckSum(txbuf_data, SDO_TX_DATASIZE + DataSize - 2);
            memcpy(&txbuf_data[SDO_TX_DATASIZE + DataSize - 2], &checksum, sizeof(checksum));
            memcpy(&txbuf_data[SDO_TX_DATASIZE + DataSize - 1], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_SendData(txbuf_data, SDO_TX_DATASIZE + DataSize); /* transfer the data */

            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < SDO_TX_DATASIZE + DataSize; i++)
            {
                DEBUG_INFO("%02x  ", txbuf_data[i]);
            }
            printf("\n");
#endif

            usleep(DELAY_TIME); /* delay 62.5 us */

            ret = SPI_ReceiveData(rxbuf_data, SDO_RX_DATASIZE);
            if (NO_ERROR != ret)
            {
                SPI_End();
                free(txbuf_data);
                free(val_array);
                return ret;
            }

#if 1
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < SDO_RX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            if (error_recv_cmd == rx_pointer->cmd)
            {
                error_num++;
                continue;
            }
            else if (sdo_write_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (sdo_write_finish_flag != rx_pointer->address_result.result)
            {
                printf("the result is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (Get_CheckSum(rxbuf_data, SDO_RX_DATASIZE - 2) != rxbuf_data[SDO_RX_DATASIZE - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (end != rxbuf_data[SDO_RX_DATASIZE - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else
            {
                printf("write successfully!\n");
                SPI_End();
                free(val_array);
                free(txbuf_data);
                return NO_ERROR;
            }
        }
        else
        {
            // txbuf_data = (uint8_t *)malloc(SDO_TX_DATASIZE + SDO_WRITE_DATASIZE);
            for (int i = 0; i < count; i++)
            {

                memcpy(txbuf_data, &header, sizeof(header));
                memcpy(&txbuf_data[2], &sdo_write_data_cmd, sizeof(sdo_write_data_cmd));
                memcpy(&txbuf_data[4], &Address, sizeof(Address));
                memcpy(&txbuf_data[8], &sdo_write_datasize, sizeof(sdo_write_datasize));
                memcpy(&txbuf_data[10], (val_array + (i * SDO_WRITE_DATASIZE)), SDO_WRITE_DATASIZE);
                checksum = Get_CheckSum(txbuf_data, SDO_TX_DATASIZE + SDO_WRITE_DATASIZE - 2);
                memcpy(&txbuf_data[SDO_TX_DATASIZE + SDO_WRITE_DATASIZE - 2], &checksum, sizeof(checksum));
                memcpy(&txbuf_data[SDO_TX_DATASIZE + SDO_WRITE_DATASIZE - 1], &end, sizeof(end));

                usleep(DELAY_TIME); /* delay 62.5 us */

                SPI_SendData(txbuf_data, SDO_TX_DATASIZE + SDO_WRITE_DATASIZE); /* transfer the data */

#if 1
                /* print the header of receiver */
                DEBUG_INFO("send:\n");
                for (int i = 0; i < SDO_TX_DATASIZE + SDO_WRITE_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", txbuf_data[i]);
                }
                printf("\n");
#endif

                usleep(DELAY_TIME); /* delay 62.5 us */

                SPI_ReceiveData(rxbuf_data, SDO_RX_DATASIZE);

#if 1
                /* print the header of receiver */
                DEBUG_INFO("receive:\n");
                for (int i = 0; i < SDO_RX_DATASIZE; i++)
                {
                    DEBUG_INFO("%02x  ", rxbuf_data[i]);
                }
                printf("\n");
#endif

                rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

                /* judge whether the receive data is correct */
                if (header != rx_pointer->header)
                {
                    printf("the header is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }

                if (error_recv_cmd == rx_pointer->cmd)
                {
                    Write_End_Flag = FALSE;
                    error_num++;
                    break;
                }
                else if (sdo_write_data_cmd != rx_pointer->cmd)
                {
                    printf("the cmd is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (sdo_write_finish_flag != rx_pointer->address_result.result)
                {
                    printf("the result is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (Get_CheckSum(rxbuf_data, SDO_RX_DATASIZE - 2) != rxbuf_data[SDO_RX_DATASIZE - 2])
                {
                    printf("the checksum is invalid\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else if (end != rxbuf_data[SDO_RX_DATASIZE - 1])
                {
                    printf("the end is wrong\n");
                    printf("reset the Communication_api\n");
                    Write_End_Flag = FALSE;
                    ret = ResetCommunication();
                    if (NO_ERROR != ret)
                    {
                        SPI_End();
                        free(txbuf_data);
                        free(val_array);
                        return ret;
                    }
                    error_num++;
                    break;
                }
                else
                {
                    memset(txbuf_data, 0, SDO_TX_DATASIZE + SDO_WRITE_DATASIZE);
                }
            }
            // free(txbuf_data);
        }
        if (TRUE == Write_End_Flag)
        {
            sdo_write_datasize = DataSize % SDO_WRITE_DATASIZE;
            // txbuf_data = (uint8_t *)malloc(SDO_TX_DATASIZE + sdo_write_datasize);

            memcpy(txbuf_data, &header, sizeof(header));
            memcpy(&txbuf_data[2], &sdo_write_data_cmd, sizeof(sdo_write_data_cmd));
            memcpy(&txbuf_data[4], &Address, sizeof(Address));
            memcpy(&txbuf_data[8], &sdo_write_datasize, sizeof(sdo_write_datasize));
            memcpy(&txbuf_data[10], (val_array + (count * SDO_WRITE_DATASIZE)), sdo_write_datasize);
            checksum = Get_CheckSum(txbuf_data, SDO_TX_DATASIZE + sdo_write_datasize - 2);
            printf("checksum: %x\n", checksum);
            memcpy(&txbuf_data[SDO_TX_DATASIZE + sdo_write_datasize - 2], &checksum, sizeof(checksum));
            memcpy(&txbuf_data[SDO_TX_DATASIZE + sdo_write_datasize - 1], &end, sizeof(end));

            usleep(DELAY_TIME); /* delay 62.5 us */

            SPI_SendData(txbuf_data, SDO_TX_DATASIZE + sdo_write_datasize); /* transfer the data */

#if 1
            /* print the header of receiver */
            DEBUG_INFO("send:\n");
            for (int i = 0; i < (SDO_TX_DATASIZE + sdo_write_datasize); i++)
            {
                DEBUG_INFO("%02x  ", txbuf_data[i]);
            }
            printf("\n");
#endif

            usleep(DELAY_TIME); /* delay 62.5 us */

            SPI_ReceiveData(rxbuf_data, SDO_RX_DATASIZE);

#if 1
            /* print the header of receiver */
            DEBUG_INFO("receive:\n");
            for (int i = 0; i < SDO_RX_DATASIZE; i++)
            {
                DEBUG_INFO("%02x  ", rxbuf_data[i]);
            }
            printf("\n");
#endif

            rx_pointer = (RXBUFF_HEADER *)rxbuf_data; /* pointer to receive cache */

            /* judge whether the receive data is correct */
            if (header != rx_pointer->header)
            {
                printf("the header is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (sdo_write_data_cmd != rx_pointer->cmd)
            {
                printf("the cmd is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (sdo_write_finish_flag != rx_pointer->address_result.result)
            {
                printf("the result is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (Get_CheckSum(rxbuf_data, SDO_RX_DATASIZE - 2) != rxbuf_data[SDO_RX_DATASIZE - 2])
            {
                printf("the checksum is invalid\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
            else if (end != rxbuf_data[SDO_RX_DATASIZE - 1])
            {
                printf("the end is wrong\n");
                printf("reset the Communication_api\n");
                ret = ResetCommunication();
                if (NO_ERROR != ret)
                {
                    SPI_End();
                    free(txbuf_data);
                    free(val_array);
                    return ret;
                }
                error_num++;
                continue;
            }
        }
        SPI_End();
        free(val_array);
        free(txbuf_data);
        return NO_ERROR;
    }
    /* Unreachable processing */
    SPI_End();
    free(val_array);
    free(txbuf_data);
    return NO_ERROR;
}

/*********************************************************************************
[function name] OrderSpecificData

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int OrderSpecificData(int *Address, short *DataSize, int *val, char *type, int num, int cmd, PDO_SDO_BUFFER *pdo_sdo_buffer)
{
    uint32_t pdo_read_list;
    uint32_t pdo_write_list;
    uint32_t sdo_read_list;
    uint32_t sdo_write_list;
    uint32_t pdo_sdo_list;
    uint16_t cur_data_size = 0;
    uint16_t total_data_size = 0;
    // uint8_t *val_buffer;
    _Bool pdo_rd_address_flag = FALSE;
    _Bool sdo_rd_address_flag = FALSE;
    _Bool pdo_wt_address_flag = FALSE;
    _Bool sdo_wt_address_flag = FALSE;
    _Bool type_flag = FALSE;

    /* Judge the validity of the parameters  */
    if (NULL == Address)
    {
        printf("the point of address is wrong\n");
        return PARAM_ERROR;
    }
    if (NULL == DataSize)
    {
        printf("the point of datasize is wrong\n");
        return PARAM_ERROR;
    }
    if (NULL == val)
    {
        printf("the point of val is wrong\n");
        return PARAM_ERROR;
    }
    if (NULL == pdo_sdo_buffer)
    {
        printf("the point of pdo_sdo_buffer is wrong\n");
        return PARAM_ERROR;
    }

    /* calculate the number of bytes in the buffer */
    for (int i = 0; i < num; i++)
    {
        total_data_size += DataSize[i];
    }

    /* malloc the val_buffer */
    // val_buffer = (uint8_t *)malloc(total_data_size);

    /* Judge the cmd */
    if (WRITE_CMD == cmd)
    {

        /* Judge whether the address is in the range */
        for (pdo_sdo_list = 0; pdo_sdo_list < num; pdo_sdo_list++)
        {
            /* Judge whether the type is right */
            if (PDO_TYPE == type[pdo_sdo_list])
            {
                type_flag = TRUE;
                /* Judge whether the address is in the range of pdo_write */
                for (pdo_write_list = 0; pdo_write_list < writepdo_listnum; pdo_write_list++)
                {
                    if (Address[pdo_sdo_list] == RF_write_pdo_area[pdo_write_list].address)
                    {
                        pdo_wt_address_flag = TRUE;
                    }

                    if (TRUE == pdo_wt_address_flag)
                    {
                        if ((DataSize[pdo_sdo_list] > RF_write_pdo_area[pdo_write_list].datasize) || (DataSize[pdo_sdo_list] < 0))
                        {
                            printf("the datasize %d is not in the range\n", pdo_sdo_list);
                            return PARAM_ERROR;
                        }
                    }

                    if (TRUE == pdo_wt_address_flag)
                    {
                        break;
                    }
                }
            }

            /* Judge whether the type is right */
            if (SDO_TYPE == type[pdo_sdo_list])
            {
                type_flag = TRUE;
                /* Judge whether the address is in the range of sdo_write */
                for (sdo_write_list = 0; sdo_write_list < writesdo_listnum; sdo_write_list++)
                {
                    if (Address[pdo_sdo_list] == RF_write_sdo_area[sdo_write_list].address)
                    {
                        sdo_wt_address_flag = TRUE;
                    }

                    if (TRUE == sdo_wt_address_flag)
                    {
                        if ((DataSize[pdo_sdo_list] > RF_write_sdo_area[sdo_write_list].datasize) || (DataSize[pdo_sdo_list] < 0))
                        {
                            printf("the datasize %d is not in the range\n", pdo_sdo_list);
                            return PARAM_ERROR;
                        }
                    }

                    if (TRUE == sdo_wt_address_flag)
                    {
                        break;
                    }
                }
            }

            if ((TRUE != sdo_wt_address_flag) && (TRUE != pdo_wt_address_flag))
            {
                printf("the address is wrong\n");
                return PARAM_ERROR;
            }

            if (FALSE == type_flag)
            {
                printf("the type is wrong\n");
                return PARAM_ERROR;
            }

            pdo_wt_address_flag = FALSE;
            sdo_wt_address_flag = FALSE; //
        }

        // printf("=====================================\n");

        /* store the data */
        for (pdo_sdo_list = 0; pdo_sdo_list < num; pdo_sdo_list++)
        {
            pdo_sdo_buffer[pdo_sdo_list].write_address = Address[pdo_sdo_list];
            pdo_sdo_buffer[pdo_sdo_list].write_datasize = DataSize[pdo_sdo_list];
            pdo_sdo_buffer[pdo_sdo_list].type = type[pdo_sdo_list];
            // pdo_sdo_buffer[pdo_sdo_list].write_value = (uint32_t *)malloc(DataSize[pdo_sdo_list]);
            memcpy(pdo_sdo_buffer[pdo_sdo_list].write_value, &val[cur_data_size], DataSize[pdo_sdo_list]);
            cur_data_size += DataSize[pdo_sdo_list];
        }
        return NO_ERROR;
    }
    else if (READ_CMD == cmd)
    {
        /* Judge whether the address is in the range */
        for (pdo_sdo_list = 0; pdo_sdo_list < num; pdo_sdo_list++)
        {
            /* Judge whether the type is right */
            if (PDO_TYPE == type[pdo_sdo_list])
            {
                type_flag = TRUE;
                /* Judge whether the address is in the range of pdo_write */
                for (pdo_read_list = 0; pdo_read_list < readpdo_listnum; pdo_read_list++)
                {
                    if (Address[pdo_sdo_list] == RF_read_pdo_area[pdo_read_list].address)
                    {
                        pdo_rd_address_flag = TRUE;
                    }

                    if (TRUE == pdo_rd_address_flag)
                    {
                        if ((DataSize[pdo_sdo_list] > RF_read_pdo_area[pdo_read_list].datasize) || (DataSize[pdo_sdo_list] < 0))
                        {
                            printf("address: %x\n", Address[pdo_sdo_list]);
                            printf("the datasize is %d\n", DataSize[pdo_sdo_list]);
                            printf("the list address is %x\n", RF_read_pdo_area[pdo_read_list].address);
                            printf("the list datasize is %d\n", RF_read_pdo_area[pdo_read_list].datasize);
                            printf("the datasize %d is not in the range\n", pdo_sdo_list);
                            return PARAM_ERROR;
                        }
                    }

                    if (TRUE == pdo_rd_address_flag)
                    {
                        break;
                    }
                }
            }

            /* Judge whether the type is right */
            if (SDO_TYPE == type[pdo_sdo_list])
            {
                type_flag = TRUE;
                /* Judge whether the address is in the range of sdo_write */
                for (sdo_read_list = 0; sdo_read_list < readsdo_listnum; sdo_read_list++)
                {
                    if (Address[pdo_sdo_list] == RF_read_sdo_area[sdo_read_list].address)
                    {
                        sdo_rd_address_flag = TRUE;
                    }

                    if (TRUE == sdo_rd_address_flag)
                    {
                        if ((DataSize[pdo_sdo_list] > RF_read_sdo_area[sdo_read_list].datasize) || (DataSize[pdo_sdo_list] < 0))
                        {
                            printf("the datasize %d is not in the range\n", pdo_sdo_list);
                            return PARAM_ERROR;
                        }
                    }

                    if (TRUE == sdo_rd_address_flag)
                    {
                        break;
                    }
                }
            }

            if ((TRUE != sdo_rd_address_flag) && (TRUE != pdo_rd_address_flag))
            {
                printf("the address is wrong\n");
                return PARAM_ERROR;
            }

            if (FALSE == type_flag)
            {
                printf("the type is wrong\n");
                return PARAM_ERROR;
            }

            pdo_rd_address_flag = FALSE;
            sdo_rd_address_flag = FALSE;
        }

        // printf("=====================================\n");

        /* store the data */
        for (pdo_sdo_list = 0; pdo_sdo_list < num; pdo_sdo_list++)
        {
            pdo_sdo_buffer[pdo_sdo_list].read_address = Address[pdo_sdo_list];
            pdo_sdo_buffer[pdo_sdo_list].read_datasize = DataSize[pdo_sdo_list];
            pdo_sdo_buffer[pdo_sdo_list].type = type[pdo_sdo_list];
            // pdo_sdo_buffer[pdo_sdo_list].read_value = (uint32_t *)malloc(DataSize[pdo_sdo_list]);
            // printf("=====================================\n");
            // memcpy(pdo_sdo_buffer[pdo_sdo_list].read_value, 0, DataSize[pdo_sdo_list]);
            // cur_data_size += DataSize[pdo_sdo_list];
        }
        return NO_ERROR;
    }
    else
    {
        printf("the cmd is wrong\n");
        return PARAM_ERROR;
    }
}

/*********************************************************************************
[function name] GetExIoSpecificData

[arguments]
num			    :	the register address
val			:	the length of the data
pdo_sdo_buffer			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetExIoSpecificData(int num, int *val, PDO_SDO_BUFFER *pdo_sdo_buffer)
{
    if (0 >= num)
    {
        printf("the number is not a valid number\n");
        return PARAM_ERROR;
    }
    if (NULL == val)
    {
        printf("the result buffer is NULL\n");
        return PARAM_ERROR;
    }
    if (NULL == pdo_sdo_buffer)
    {
        printf("the data is invalid, please try again!\n");
        return PARAM_ERROR;
    }
    uint32_t turns;
    uint32_t cur_data_size = 0;
    uint32_t total_size = 0;
    uint8_t ret = 0;
    uint8_t *array = NULL;

    for (turns = 0; turns < num; turns++)
    {
        total_size += pdo_sdo_buffer[turns].read_datasize;
    }

    array = (uint8_t *)malloc(total_size + 1);
    if (array == NULL)
    {
        printf("malloc error\n");
        return MALLOC_ERROR;
    }

    for (turns = 0; turns < num; turns++)
    {
        printf("address: %x\n", pdo_sdo_buffer[turns].read_address);
        printf("the datasize is %d\n", pdo_sdo_buffer[turns].read_datasize);
        printf("the type is %d\n", pdo_sdo_buffer[turns].type);
        // printf("the list address is %x\n", RF_read_pdo_area[pdo_read_list].address);
        if (PDO_TYPE == pdo_sdo_buffer[turns].type)
        {
            ret = ExIoAreaRead(pdo_sdo_buffer[turns].read_address, pdo_sdo_buffer[turns].read_datasize, (int *)pdo_sdo_buffer[turns].read_value);
            usleep(DELAY_TIME); /* delay 62.5 us */
            memcpy(array + cur_data_size, pdo_sdo_buffer[turns].read_value, pdo_sdo_buffer[turns].read_datasize);
            cur_data_size += pdo_sdo_buffer[turns].read_datasize;
            // free(pdo_sdo_buffer[turns].read_value);
            if (NO_ERROR != ret)
            {
                printf("fail to read\n");
                free(array);
                return SPI_COMMUN_ERROR;
            }
        }
        else if (SDO_TYPE == pdo_sdo_buffer[turns].type)
        {
            ret = SDORead(pdo_sdo_buffer[turns].read_address, pdo_sdo_buffer[turns].read_datasize, (int *)pdo_sdo_buffer[turns].read_value);
            usleep(DELAY_TIME); /* delay 62.5 us */
            memcpy(array + cur_data_size, pdo_sdo_buffer[turns].read_value, pdo_sdo_buffer[turns].read_datasize);
            printf("read_value:\n");
            printf("0x%08x\n", pdo_sdo_buffer[turns].read_value[0]);

            cur_data_size += pdo_sdo_buffer[turns].read_datasize;
            // free(pdo_sdo_buffer[turns].read_value);
            if (NO_ERROR != ret)
            {
                printf("fail to read\n");
                free(array);
                return SPI_COMMUN_ERROR;
            }
        }
        else
        {
            printf("the type is wrong\n");
            free(array);
            return PARAM_ERROR;
        }
        // printf("value:\n");
        // printf("0x%08x\n", val[0]);
        // printf("0x%08x\n", val[1]);
    }
    memcpy(val, array, total_size);
    free(array);
    // printf("0x%08x\n", val[0]);
    // printf("0x%08x\n", val[1]);

    return NO_ERROR;
}

/*********************************************************************************
[function name] SetExIoSpecificData

[arguments]
num			    :	the register address
pdo_sdo_buffer			:	the length of the data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetExIoSpecificData(int num, PDO_SDO_BUFFER *pdo_sdo_buffer)
{
    uint32_t turns;
    uint8_t ret = 0;
    if (0 >= num)
    {
        printf("the number is not a valid number\n");
        return PARAM_ERROR;
    }
    if (NULL == pdo_sdo_buffer)
    {
        printf("the data is invalid, please try again!\n");
        return PARAM_ERROR;
    }
    for (turns = 0; turns < num; turns++)
    {
        printf("address: %x\n", pdo_sdo_buffer[turns].read_address);
        printf("the datasize is %d\n", pdo_sdo_buffer[turns].read_datasize);
        printf("the type is %d\n", pdo_sdo_buffer[turns].type);
        if (PDO_TYPE == pdo_sdo_buffer[turns].type)
        {
            ret = ExIoAreaWrite(pdo_sdo_buffer[turns].write_address, pdo_sdo_buffer[turns].write_datasize, (int *)pdo_sdo_buffer[turns].write_value);
            usleep(DELAY_TIME); /* delay 62.5 us */
            // free(pdo_sdo_buffer[turns].write_value);
            if (NO_ERROR != ret)
            {
                printf("fail to write!\n");
                return SPI_WRITE_ERROR;
            }
        }
        else if (SDO_TYPE == pdo_sdo_buffer[turns].type)
        {
            ret = SDOWrite(pdo_sdo_buffer[turns].write_address, pdo_sdo_buffer[turns].write_datasize, (int *)pdo_sdo_buffer[turns].write_value);
            usleep(DELAY_TIME); /* delay 62.5 us */
            // free(pdo_sdo_buffer[turns].write_value);
            if (NO_ERROR != ret)
            {
                printf("fail to write!\n");
                return SPI_WRITE_ERROR;
            }
        }
        else
        {
            printf("the type is wrong\n");
            return PARAM_ERROR;
        }
    }
    return NO_ERROR;
}

int ECAT_DipSwRead(uint16_t *value)
{
    int ret = 0;
    uint8_t txbuffer[DIPSW_TX_DATASIZE];
    uint8_t rxbuffer[DIPSW_RX_DATASIZE];
    uint8_t end = SPI_TRAILER;
    uint16_t header = SPI_HEADER;
    uint16_t dipsw_read_cmd = DIPSW_READ_CMD;
    uint16_t error_recv_cmd = ERROR_SEND_CMD;
    uint8_t checksum = 0;
    RXBUFF_HEADER *rx_pointer;
    uint8_t error_num = 0;

    /* judge the validity of parameters */
    if (NULL == value)
    {
        printf("the point is wrong\n");
        return PARAM_ERROR;
    }
    while (ERROR_TIMES > error_num)
    {
        /* intialize SPI */
        ret = SPI_Init(SPI_DEV_ECAT, SPI_MODE0, SPI_SPEED);
        if (NO_ERROR != ret)
        {
            SPI_End();
            return ret;
        }

        memcpy(txbuffer, &header, 2);
        memcpy(txbuffer + 2, &dipsw_read_cmd, 2);
        memset(txbuffer + 4, 0, 6);

        checksum = Get_CheckSum(txbuffer, CC_LENGTH);

        memcpy(txbuffer + 10, &checksum, 1);
        memcpy(txbuffer + 11, &end, 1);

#if 1
        /* print the header of receiver */
        DEBUG_INFO("send:\n");
        for (int i = 0; i < DIPSW_TX_DATASIZE; i++)
        {
            DEBUG_INFO("0x%02x  ", txbuffer[i]);
        }
        printf("\n");
#endif

        ret = SPI_SendData(txbuffer, DIPSW_TX_DATASIZE);

        usleep(3000); /* delay 62.5 us */

        ret = SPI_ReceiveData(rxbuffer, DIPSW_RX_DATASIZE); /* receive the header */
        if (NO_ERROR != ret)
        {
            SPI_End();
            return ret;
        }

#if 1
        /* print the header of receiver */
        DEBUG_INFO("receive:\n");
        for (int i = 0; i < DIPSW_RX_DATASIZE; i++)
        {
            DEBUG_INFO("0x%02x  ", rxbuffer[i]);
        }
        printf("\n");
#endif

        rx_pointer = (RXBUFF_HEADER *)rxbuffer;

        if (header != rx_pointer->header)
        {
            printf("the header is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                return ret;
            }
            error_num++;
            continue;
        }

        if (error_recv_cmd == rx_pointer->cmd)
        {
            error_num++;
            continue;
        }
        else if (dipsw_read_cmd != rx_pointer->cmd)
        {
            printf("the cmd is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                return ret;
            }
            error_num++;
            continue;
        }

        checksum = Get_CheckSum(rxbuffer, 6);

        if (checksum != rxbuffer[6])
        {
            printf("the checksum is invalid");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                return ret;
            }
            error_num++;
            continue;
        }

        if (end != rxbuffer[7])
        {
            printf("the end is wrong\n");
            printf("reset the Communication_api\n");
            ret = ResetCommunication();
            if (NO_ERROR != ret)
            {
                SPI_End();
                return ret;
            }
            error_num++;
            continue;
        }

        memcpy(value, rxbuffer + 4, 2);
        break;
    }

    return NO_ERROR;
}