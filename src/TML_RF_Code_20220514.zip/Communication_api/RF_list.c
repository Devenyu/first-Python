#include "RF_list.h"

RF_list RF_read_pdo_area[] = {
    {0x7000, 1},
    {0x7010, 180},
    {0x7020, 50},
    {0x7030, 360},
    {0x7050, 4},
    {0x7060, 4},
    {0x7070, 2},  
    {0x7090, 4},
    {0x70A0, 24},
    {0x70B0, 48},
};

RF_list RF_write_pdo_area[] = {
    {0x6000, 9},
    {0x6010, 180},
    {0x6020, 50},
    {0x6030, 360},
    {0x6050, 96},
    {0x6060, 118},
    {0x6070, 272},
    {0x6090, 80},
    {0x60A0, 4},
    {0x60B0, 16},
};

RF_list RF_write_sdo_area[] = {
    {0x6060, 2},
    {0x6070, 8},
    {0x60B0, 32},
};

RF_list RF_read_sdo_area[] = {
    {0x7000, 1},
    {0x7050, 4},
    {0x7060, 3},
};

unsigned int writepdo_listnum = 10;
unsigned int readpdo_listnum = 10;
unsigned int writesdo_listnum = 3;
unsigned int readsdo_listnum = 3;