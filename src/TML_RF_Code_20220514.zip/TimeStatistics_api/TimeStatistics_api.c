#include <sys/time.h>
#include <math.h>
#include "cpufunc_api.h"
#include "gpio.h"
#include "RF_list.h"
#include "DNet_list.h"
#include "Communication_api.h"
#include "Algorithm_api.h"
#include "Parameter_api.h"
#include "eeprom_api.h"
#include "file_api.h"
#include "dio_api.h"
#include "calc_api.h"
#include "DataStrage_api.h"
#include "Err32_def_api.h"

long long end = 0;
long long start = 0;
struct timeval end_time;
struct timeval start_time;
DnetAccessObject dneObject = {0};

int get_local_time(char *time_str, int len, struct timeval *tv)
{
    struct tm *ptm;
    char time_string[40];
    long milliseconds;

    ptm = localtime(&(tv->tv_sec));

    strftime((char *)time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", ptm); // output: 2018-12-09 10:52:57.200

    milliseconds = tv->tv_usec / 1000;

    snprintf((char *)time_str, len, "[%s.%03ld]", (char *)time_string, milliseconds);

    return NO_ERROR;
}

int LedControlTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int lednum = 0;
    int control = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    lednum = rand() % 4;
    control = rand() % 2;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = LedControl(lednum, GPIO_VAL_HIGH);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]ledno:%d,[Input]control:%d", lednum, control);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int VersionAccessTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int version = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetDeviceDriverVersion(&version);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]version:0x%x", version);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int DipSWReadTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int ReadData[2];

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = DipSWRead(ReadData);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]ReadData[0]:%d,[Output]ReadData[1]:%d", ReadData[0], ReadData[1]);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetCPUTempTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    double temperature;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetCPUTemp(&temperature);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]Temperature:%f", temperature);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int WdtStartTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int WdtSecond = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    WdtSecond = rand() % 100;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = WdtStart(WdtSecond);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]SelectableSecond:%d", WdtSecond);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int WdtStopTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = WdtStop();
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "-");

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int WdtResetTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = WdtReset();
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "-");

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetBrdTempTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    double temperature[2];

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetBrdTemp(temperature);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]Temperature:%f", temperature[0]);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetFanStateTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int FanState = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetFanState(&FanState);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]FanState:%d", FanState);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int SetKernelDateTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    struct timeval tx;
    struct timezone tz;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    gettimeofday(&tx, &tz);
    tx.tv_sec = rand() % 1000 + tx.tv_sec;
    tx.tv_usec = rand() % 1000 + tx.tv_usec;
    tz.tz_minuteswest = rand() % 10 + tz.tz_minuteswest;
    tz.tz_dsttime = rand() % 10 + tz.tz_dsttime;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;
    printf("start time = %lld\n", start);

    /* run api */
    iRet = SetKernelDate(&tx, &tz);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;
    printf("end time = %lld\n", end);

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]tx.tv_sec:%ld,[Input]tx.tv_usec:%ld,[Input]tz.tz_minuteswest:%d,[Input]tz.tz_dsttime:%d", tx.tv_sec, tx.tv_usec, tz.tz_minuteswest, tz.tz_dsttime);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int ExIoAreaReadTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int iRandType = 0;
    int address = 0;
    int *val = NULL;
    int iCount = 0;
    int iTemp = 0;
    char cTemp[1024];
    short datasize = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    iRandType = rand() % readpdo_listnum;
    address = RF_read_pdo_area[iRandType].address;
    datasize = rand() % RF_read_pdo_area[iRandType].datasize + 1;
    val = (int *)malloc(datasize);
    if (val == NULL)
    {
        printf("malloc error\n");
        return MALLOC_ERROR;
    }

    if (0 == datasize % 4)
    {
        iCount = datasize / 4;
    }
    else
    {
        iCount = (datasize / 4) + 1;
    }
    memset(val, 0, iCount * 4);

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = ExIoAreaRead(address, datasize, val);
    if (NO_ERROR != iRet)
    {
        free(val);
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]Address:0x%x,[Input]DataSize:%d,", address, datasize);
    for (iTemp = 0; iTemp < iCount; iTemp++)
    {
        sprintf((char *)cTemp, "[Output]val[%d]:%d,", iTemp, val[iTemp]);
        strcat((char *)parameter_str, cTemp);
    }

    /* calculate the past time */
    *pasttime = end - start;

    free(val);
    return NO_ERROR;
}

int ExIoAreaWriteTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int iRandType = 0;
    int address = 0;
    int *val = NULL;
    int iCount = 0;
    int iTemp = 0;
    char cTemp[1024];
    short datasize = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    iRandType = rand() % writepdo_listnum;
    address = RF_write_pdo_area[iRandType].address;
    datasize = rand() % RF_write_pdo_area[iRandType].datasize + 1;
    val = (int *)malloc(datasize);
    if (val == NULL)
    {
        printf("malloc error\n");
        return MALLOC_ERROR;
    }
    if (0 == datasize % 4)
    {
        iCount = datasize / 4;
    }
    else
    {
        iCount = (datasize / 4) + 1;
    }
    for (iTemp = 0; iTemp < iCount; iTemp++)
    {
        if ((rand() % 2) == 0)
        {
            val[iTemp] = rand() % (int)(pow(2, 31));
        }
        else
        {
            val[iTemp] = -rand() % (int)(pow(2, 31) + 1);
        }
    }

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = ExIoAreaWrite(address, datasize, val);
    if (NO_ERROR != iRet)
    {
        free(val);
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]Address:0x%x,[Input]DataSize:%d,", address, datasize);
    for (iTemp = 0; iTemp < iCount; iTemp++)
    {
        sprintf((char *)cTemp, "[Input]val[%d]:%d,", iTemp, val[iTemp]);
        strcat((char *)parameter_str, cTemp);
    }

    /* calculate the past time */
    *pasttime = end - start;

    free(val);
    return NO_ERROR;
}

int DNetWriteTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int iTemp = 0;
    int iRandType = 0;
    char cTemp[1024];

    /* init the parameter */
    // rand()%(Y-X+1)+X
    if ((rand() % 2) == 0)
    {
        dneObject.serviceId = 0x0E;
        iRandType = rand() % 12;
        dneObject.classId = Explicit_area[iRandType].ClassId;
        dneObject.attributeId = Explicit_area[iRandType].AttributeId;
        dneObject.address = rand() % Explicit_area[iRandType].DataSize;
        dneObject.dataSize = rand() % (Explicit_area[iRandType].DataSize - dneObject.address);
    }
    else
    {
        dneObject.serviceId = 0x10;
        iRandType = rand() % 20;
        dneObject.classId = Identity_area[iRandType].ClassId;
        dneObject.attributeId = Identity_area[iRandType].AttributeId;
        dneObject.instanceId = Identity_area[iRandType].InstanceId;
        dneObject.address = rand() % Identity_area[iRandType].DataSize;
        dneObject.dataSize = rand() % (Identity_area[iRandType].DataSize - dneObject.address);
    }
    dneObject.val = (uint8_t *)malloc(dneObject.dataSize);
    for (iTemp = 0; iTemp < dneObject.dataSize; iTemp++)
    {
        dneObject.val[iTemp] = rand() % 256;
    }

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    // iRet = DNetWrite(&dneObject);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]Service ID:0x%x,[Input]Class ID:0x%x,[Input]Attribute ID:0%x,", dneObject.serviceId, dneObject.classId, dneObject.attributeId);
    if (0x10 == dneObject.serviceId)
    {
        sprintf((char *)cTemp, "[Input]Instance ID:0x%x,", dneObject.instanceId);
        strcat((char *)parameter_str, cTemp);
    }

    sprintf((char *)cTemp, "[Input]Address:0x%x,", dneObject.address);
    strcat((char *)parameter_str, cTemp);
    sprintf((char *)cTemp, "[Input]DataSize:0x%x,", dneObject.dataSize);
    strcat((char *)parameter_str, cTemp);
    for (iTemp = 0; iTemp < dneObject.dataSize; iTemp++)
    {
        sprintf((char *)cTemp, "[Input]val[%d]:%d,", iTemp, dneObject.val[iTemp]);
        strcat((char *)parameter_str, cTemp);
    }

    /* calculate the past time */
    *pasttime = end - start;
    free(dneObject.val);

    return NO_ERROR;
}

int DNetReadTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int iTemp = 0;
    char cTemp[1024];

    dneObject.val = (uint8_t *)malloc(dneObject.dataSize);

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    // iRet = DNetRead( &dneObject);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]Service ID:0x%x,[Input]Class ID:0x%x,[Input]Attribute ID:0%x,", dneObject.serviceId, dneObject.classId, dneObject.attributeId);
    if (0x10 == dneObject.serviceId)
    {
        sprintf((char *)cTemp, "[Input]Instance ID:0x%x,", dneObject.instanceId);
        strcat((char *)parameter_str, cTemp);
    }

    sprintf((char *)cTemp, "[Input]Address:0x%x,", dneObject.address);
    strcat((char *)parameter_str, cTemp);
    sprintf((char *)cTemp, "[Input]DataSize:0x%x,", dneObject.dataSize);
    strcat((char *)parameter_str, cTemp);
    for (iTemp = 0; iTemp < dneObject.dataSize; iTemp++)
    {
        sprintf((char *)cTemp, "[Output]val[%d]:%d,", iTemp, dneObject.val[iTemp]);
        strcat((char *)parameter_str, cTemp);
    }

    /* calculate the past time */
    *pasttime = end - start;
    free(dneObject.val);

    return NO_ERROR;
}

int GetFeatureValTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int num = 0;
    int iRet = 0;
    int dataSetNum = 0;
    freqData *pFreqData;
    WaferLevelCalcCoefficient wLevelCoff = {0};
    struct BoardSerialParam boardSerialParam[3] = {0};
    FeatureAnalysisParameter featureParam = {0};

    /* Feature Reg Init */
    wLevelCoff.matrix_1raw = HexToFloat(0x431fd75f);
    wLevelCoff.matrix_1clm = HexToFloat(0xc1c62594);
    wLevelCoff.matrix_2raw = HexToFloat(0x41fae752);
    wLevelCoff.matrix_2clm = HexToFloat(0x42d2ecd9);
    wLevelCoff.matrix_3raw = HexToFloat(0x3d15dfba);
    wLevelCoff.matrix_3clm = HexToFloat(0x3e71c0ae);
    wLevelCoff.matrix_4raw = HexToFloat(0x41c59887);
    wLevelCoff.matrix_4clm = HexToFloat(0xc0e42a6b);

    /* Init  Feature Analysis  parameters*/
    featureParam.movingAverage_Count = 0x3f800000;
    featureParam.transitionJudge_LowLimitCount = 0x41200000;
    featureParam.transitionJudge_LowLimitSigma = HexToFloat(0x40400000);
    featureParam.transitionJudge_UpperLimitCv = HexToFloat(0x3dcccccd);
    featureParam.transitionJudge_LowLimitDuty = HexToFloat(0x3dcccccd);
    featureParam.transitionJudge_SigmaDiffCofficient = HexToFloat(0x3f800000);
    featureParam.aggregationJudge_Sigma = HexToFloat(0x40400000);
    featureParam.aggregationJudge_DiffPercentage = HexToFloat(0x3dcccccd);
    featureParam.aggregationJudge_DiffVoltage = HexToFloat(0x41a00000);
    featureParam.aggregationWeights_CvThreshold = HexToFloat(0x40a00000);
    featureParam.aggregationWeights_LowLimit = HexToFloat(0x3f800000);

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 128; j++)
        {
            boardSerialParam[i].coff_1stOrder[j] = HexToFloat(0x3f800000);
        }

        boardSerialParam[i].constant[0] = HexToFloat(0x00000000);
        boardSerialParam[i].constant[1] = HexToFloat(0x44000000);
        boardSerialParam[i].constant[2] = HexToFloat(0x44800000);
        boardSerialParam[i].constant[3] = HexToFloat(0x44c00000);
        boardSerialParam[i].constant[4] = HexToFloat(0x45000000);
        boardSerialParam[i].constant[5] = HexToFloat(0x45200000);
        boardSerialParam[i].constant[6] = HexToFloat(0x45400000);
        boardSerialParam[i].constant[7] = HexToFloat(0x45600000);
        boardSerialParam[i].constant[8] = HexToFloat(0x45800000);
        boardSerialParam[i].constant[9] = HexToFloat(0x45900000);
        boardSerialParam[i].constant[10] = HexToFloat(0x45a00000);
        boardSerialParam[i].constant[11] = HexToFloat(0x45b00000);
        boardSerialParam[i].constant[12] = HexToFloat(0x45c00000);
        boardSerialParam[i].constant[13] = HexToFloat(0x45d00000);
        boardSerialParam[i].constant[14] = HexToFloat(0x45e00000);
        boardSerialParam[i].constant[15] = HexToFloat(0x45f00000);
        boardSerialParam[i].constant[16] = HexToFloat(0x46000000);
        boardSerialParam[i].constant[17] = HexToFloat(0x46080000);
        boardSerialParam[i].constant[18] = HexToFloat(0x46100000);
        boardSerialParam[i].constant[19] = HexToFloat(0x46180000);
        boardSerialParam[i].constant[20] = HexToFloat(0x46200000);
        boardSerialParam[i].constant[21] = HexToFloat(0x46280000);
        boardSerialParam[i].constant[22] = HexToFloat(0x46300000);
        boardSerialParam[i].constant[23] = HexToFloat(0x46380000);
        boardSerialParam[i].constant[24] = HexToFloat(0x46400000);
        boardSerialParam[i].constant[25] = HexToFloat(0x46480000);
        boardSerialParam[i].constant[26] = HexToFloat(0x46500000);
        boardSerialParam[i].constant[27] = HexToFloat(0x46580000);
        boardSerialParam[i].constant[28] = HexToFloat(0x46600000);
        boardSerialParam[i].constant[29] = HexToFloat(0x46680000);
        boardSerialParam[i].constant[30] = HexToFloat(0x46700000);
        boardSerialParam[i].constant[31] = HexToFloat(0x46780000);
        boardSerialParam[i].constant[32] = HexToFloat(0x46800000);
        boardSerialParam[i].constant[33] = HexToFloat(0x46840000);
        boardSerialParam[i].constant[34] = HexToFloat(0x46880000);
        boardSerialParam[i].constant[35] = HexToFloat(0x468c0000);
        boardSerialParam[i].constant[36] = HexToFloat(0x46900000);
        boardSerialParam[i].constant[37] = HexToFloat(0x46940000);
        boardSerialParam[i].constant[38] = HexToFloat(0x46980000);
        boardSerialParam[i].constant[39] = HexToFloat(0x469c0000);
        boardSerialParam[i].constant[40] = HexToFloat(0x46a00000);
        boardSerialParam[i].constant[41] = HexToFloat(0x46a40000);
        boardSerialParam[i].constant[42] = HexToFloat(0x46a80000);
        boardSerialParam[i].constant[43] = HexToFloat(0x46ac0000);
        boardSerialParam[i].constant[44] = HexToFloat(0x46b00000);
        boardSerialParam[i].constant[45] = HexToFloat(0x46b40000);
        boardSerialParam[i].constant[46] = HexToFloat(0x46b80000);
        boardSerialParam[i].constant[47] = HexToFloat(0x46bc0000);
        boardSerialParam[i].constant[48] = HexToFloat(0x46c00000);
        boardSerialParam[i].constant[49] = HexToFloat(0x46c40000);
        boardSerialParam[i].constant[50] = HexToFloat(0x46c80000);
        boardSerialParam[i].constant[51] = HexToFloat(0x46cc0000);
        boardSerialParam[i].constant[52] = HexToFloat(0x46d00000);
        boardSerialParam[i].constant[53] = HexToFloat(0x46d40000);
        boardSerialParam[i].constant[54] = HexToFloat(0x46d80000);
        boardSerialParam[i].constant[55] = HexToFloat(0x46dc0000);
        boardSerialParam[i].constant[56] = HexToFloat(0x46e00000);
        boardSerialParam[i].constant[57] = HexToFloat(0x46e40000);
        boardSerialParam[i].constant[58] = HexToFloat(0x46e80000);
        boardSerialParam[i].constant[59] = HexToFloat(0x46ec0000);
        boardSerialParam[i].constant[60] = HexToFloat(0x46f00000);
        boardSerialParam[i].constant[61] = HexToFloat(0x46f40000);
        boardSerialParam[i].constant[62] = HexToFloat(0x46f80000);
        boardSerialParam[i].constant[63] = HexToFloat(0x46fc0000);
        boardSerialParam[i].constant[64] = HexToFloat(0xc7000000);
        boardSerialParam[i].constant[65] = HexToFloat(0xc6fc0000);
        boardSerialParam[i].constant[66] = HexToFloat(0xc6f80000);
        boardSerialParam[i].constant[67] = HexToFloat(0xc6f40000);
        boardSerialParam[i].constant[68] = HexToFloat(0xc6f00000);
        boardSerialParam[i].constant[69] = HexToFloat(0xc6ec0000);
        boardSerialParam[i].constant[70] = HexToFloat(0xc6e80000);
        boardSerialParam[i].constant[71] = HexToFloat(0xc6e40000);
        boardSerialParam[i].constant[72] = HexToFloat(0xc6e00000);
        boardSerialParam[i].constant[73] = HexToFloat(0xc6dc0000);
        boardSerialParam[i].constant[74] = HexToFloat(0xc6d80000);
        boardSerialParam[i].constant[75] = HexToFloat(0xc6d40000);
        boardSerialParam[i].constant[76] = HexToFloat(0xc6d00000);
        boardSerialParam[i].constant[77] = HexToFloat(0xc6cc0000);
        boardSerialParam[i].constant[78] = HexToFloat(0xc6c80000);
        boardSerialParam[i].constant[79] = HexToFloat(0xc6c40000);
        boardSerialParam[i].constant[80] = HexToFloat(0xc6c00000);
        boardSerialParam[i].constant[81] = HexToFloat(0xc6bc0000);
        boardSerialParam[i].constant[82] = HexToFloat(0xc6b80000);
        boardSerialParam[i].constant[83] = HexToFloat(0xc6b40000);
        boardSerialParam[i].constant[84] = HexToFloat(0xc6b00000);
        boardSerialParam[i].constant[85] = HexToFloat(0xc6ac0000);
        boardSerialParam[i].constant[86] = HexToFloat(0xc6a80000);
        boardSerialParam[i].constant[87] = HexToFloat(0xc6a40000);
        boardSerialParam[i].constant[88] = HexToFloat(0xc6a00000);
        boardSerialParam[i].constant[89] = HexToFloat(0xc69c0000);
        boardSerialParam[i].constant[90] = HexToFloat(0xc6980000);
        boardSerialParam[i].constant[91] = HexToFloat(0xc6940000);
        boardSerialParam[i].constant[92] = HexToFloat(0xc6900000);
        boardSerialParam[i].constant[93] = HexToFloat(0xc68c0000);
        boardSerialParam[i].constant[94] = HexToFloat(0xc6880000);
        boardSerialParam[i].constant[95] = HexToFloat(0xc6840000);
        boardSerialParam[i].constant[96] = HexToFloat(0xc6800000);
        boardSerialParam[i].constant[97] = HexToFloat(0xc6780000);
        boardSerialParam[i].constant[98] = HexToFloat(0xc6700000);
        boardSerialParam[i].constant[99] = HexToFloat(0xc6680000);
        boardSerialParam[i].constant[100] = HexToFloat(0xc6600000);
        boardSerialParam[i].constant[101] = HexToFloat(0xc6580000);
        boardSerialParam[i].constant[102] = HexToFloat(0xc6500000);
        boardSerialParam[i].constant[103] = HexToFloat(0xc6480000);
        boardSerialParam[i].constant[104] = HexToFloat(0xc6400000);
        boardSerialParam[i].constant[105] = HexToFloat(0xc6380000);
        boardSerialParam[i].constant[106] = HexToFloat(0xc6300000);
        boardSerialParam[i].constant[107] = HexToFloat(0xc6280000);
        boardSerialParam[i].constant[108] = HexToFloat(0xc6200000);
        boardSerialParam[i].constant[109] = HexToFloat(0xc6180000);
        boardSerialParam[i].constant[110] = HexToFloat(0xc6100000);
        boardSerialParam[i].constant[111] = HexToFloat(0xc6080000);
        boardSerialParam[i].constant[112] = HexToFloat(0xc6000000);
        boardSerialParam[i].constant[113] = HexToFloat(0xc5f00000);
        boardSerialParam[i].constant[114] = HexToFloat(0xc5e00000);
        boardSerialParam[i].constant[115] = HexToFloat(0xc5d00000);
        boardSerialParam[i].constant[116] = HexToFloat(0xc5c00000);
        boardSerialParam[i].constant[117] = HexToFloat(0xc5b00000);
        boardSerialParam[i].constant[118] = HexToFloat(0xc5a00000);
        boardSerialParam[i].constant[119] = HexToFloat(0xc5900000);
        boardSerialParam[i].constant[120] = HexToFloat(0xc5800000);
        boardSerialParam[i].constant[121] = HexToFloat(0xc5600000);
        boardSerialParam[i].constant[122] = HexToFloat(0xc5400000);
        boardSerialParam[i].constant[123] = HexToFloat(0xc5200000);
        boardSerialParam[i].constant[124] = HexToFloat(0xc5000000);
        boardSerialParam[i].constant[125] = HexToFloat(0xc4c00000);
        boardSerialParam[i].constant[126] = HexToFloat(0xc4800000);
        boardSerialParam[i].constant[127] = HexToFloat(0xc4000000);
    }

    FeatureRegInit(&wLevelCoff, &featureParam, boardSerialParam);

    /* init the parameter */
    // rand()%(Y-X+1)+X
    dataSetNum = rand() % (int)(pow(2, 31) - 1);
    pFreqData = (freqData *)malloc(sizeof(freqData) * dataSetNum + 1);
    if (pFreqData == NULL)
    {
        printf("malloc error\n");
        return MALLOC_ERROR;
    }
    
    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetFeatureVal(pFreqData, (int *)&num, dataSetNum);
    if (NO_ERROR != iRet)
    {
        free(pFreqData);
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]Max:%f,\
                                    [Output]Min:%f,\
                                    [Output]Lvl1Ave:%f,\
                                    [Output]Lvl2Ave:%f,\
                                    [Output]Lvl3Ave:%f,\
                                    [Output]Lvl4Ave:%f,\
                                    [Output]Lvl5Ave:%f,\
                                    [Output]Lvl1Duty:%f,\
                                    [Output]Lvl2Duty:%f,\
                                    [Output]Lvl3Duty:%f,\
                                    [Output]Lvl4Duty:%f,\
                                    [Output]Lvl5Duty:%f,\
                                    [Output]num:%d,\
                                    [Input]dataSetNum:%d,\
                                    ",
            pFreqData->Max,
            pFreqData->Min,
            pFreqData->Lvl1Ave,
            pFreqData->Lvl2Ave,
            pFreqData->Lvl3Ave,
            pFreqData->Lvl4Ave,
            pFreqData->Lvl5Ave,
            pFreqData->Lvl1Duty,
            pFreqData->Lvl2Duty,
            pFreqData->Lvl3Duty,
            pFreqData->Lvl4Duty,
            pFreqData->Lvl5Duty,
            num, dataSetNum);

    /* calculate the past time */
    *pasttime = end - start;
    free(pFreqData);
    return NO_ERROR;
}

int GetFeatureAnalysisValTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int num = 0;
    int iRet = 0;
    int dataSetNum = 0;
    freqData *pFreqData;
    WaferLevelCalcCoefficient wLevelCoff = {0};
    struct BoardSerialParam boardSerialParam[3] = {0};
    FeatureAnalysisParameter featureParam = {0};

    /* Feature Reg Init */
    wLevelCoff.matrix_1raw = HexToFloat(0x431fd75f);
    wLevelCoff.matrix_1clm = HexToFloat(0xc1c62594);
    wLevelCoff.matrix_2raw = HexToFloat(0x41fae752);
    wLevelCoff.matrix_2clm = HexToFloat(0x42d2ecd9);
    wLevelCoff.matrix_3raw = HexToFloat(0x3d15dfba);
    wLevelCoff.matrix_3clm = HexToFloat(0x3e71c0ae);
    wLevelCoff.matrix_4raw = HexToFloat(0x41c59887);
    wLevelCoff.matrix_4clm = HexToFloat(0xc0e42a6b);

    /* Init  Feature Analysis  parameters*/
    featureParam.movingAverage_Count = 0x3f800000;
    featureParam.transitionJudge_LowLimitCount = 0x41200000;
    featureParam.transitionJudge_LowLimitSigma = HexToFloat(0x40400000);
    featureParam.transitionJudge_UpperLimitCv = HexToFloat(0x3dcccccd);
    featureParam.transitionJudge_LowLimitDuty = HexToFloat(0x3dcccccd);
    featureParam.transitionJudge_SigmaDiffCofficient = HexToFloat(0x3f800000);
    featureParam.aggregationJudge_Sigma = HexToFloat(0x40400000);
    featureParam.aggregationJudge_DiffPercentage = HexToFloat(0x3dcccccd);
    featureParam.aggregationJudge_DiffVoltage = HexToFloat(0x41a00000);
    featureParam.aggregationWeights_CvThreshold = HexToFloat(0x40a00000);
    featureParam.aggregationWeights_LowLimit = HexToFloat(0x3f800000);

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 128; j++)
        {
            boardSerialParam[i].coff_1stOrder[j] = HexToFloat(0x3f800000);
        }

        boardSerialParam[i].constant[0] = HexToFloat(0x00000000);
        boardSerialParam[i].constant[1] = HexToFloat(0x44000000);
        boardSerialParam[i].constant[2] = HexToFloat(0x44800000);
        boardSerialParam[i].constant[3] = HexToFloat(0x44c00000);
        boardSerialParam[i].constant[4] = HexToFloat(0x45000000);
        boardSerialParam[i].constant[5] = HexToFloat(0x45200000);
        boardSerialParam[i].constant[6] = HexToFloat(0x45400000);
        boardSerialParam[i].constant[7] = HexToFloat(0x45600000);
        boardSerialParam[i].constant[8] = HexToFloat(0x45800000);
        boardSerialParam[i].constant[9] = HexToFloat(0x45900000);
        boardSerialParam[i].constant[10] = HexToFloat(0x45a00000);
        boardSerialParam[i].constant[11] = HexToFloat(0x45b00000);
        boardSerialParam[i].constant[12] = HexToFloat(0x45c00000);
        boardSerialParam[i].constant[13] = HexToFloat(0x45d00000);
        boardSerialParam[i].constant[14] = HexToFloat(0x45e00000);
        boardSerialParam[i].constant[15] = HexToFloat(0x45f00000);
        boardSerialParam[i].constant[16] = HexToFloat(0x46000000);
        boardSerialParam[i].constant[17] = HexToFloat(0x46080000);
        boardSerialParam[i].constant[18] = HexToFloat(0x46100000);
        boardSerialParam[i].constant[19] = HexToFloat(0x46180000);
        boardSerialParam[i].constant[20] = HexToFloat(0x46200000);
        boardSerialParam[i].constant[21] = HexToFloat(0x46280000);
        boardSerialParam[i].constant[22] = HexToFloat(0x46300000);
        boardSerialParam[i].constant[23] = HexToFloat(0x46380000);
        boardSerialParam[i].constant[24] = HexToFloat(0x46400000);
        boardSerialParam[i].constant[25] = HexToFloat(0x46480000);
        boardSerialParam[i].constant[26] = HexToFloat(0x46500000);
        boardSerialParam[i].constant[27] = HexToFloat(0x46580000);
        boardSerialParam[i].constant[28] = HexToFloat(0x46600000);
        boardSerialParam[i].constant[29] = HexToFloat(0x46680000);
        boardSerialParam[i].constant[30] = HexToFloat(0x46700000);
        boardSerialParam[i].constant[31] = HexToFloat(0x46780000);
        boardSerialParam[i].constant[32] = HexToFloat(0x46800000);
        boardSerialParam[i].constant[33] = HexToFloat(0x46840000);
        boardSerialParam[i].constant[34] = HexToFloat(0x46880000);
        boardSerialParam[i].constant[35] = HexToFloat(0x468c0000);
        boardSerialParam[i].constant[36] = HexToFloat(0x46900000);
        boardSerialParam[i].constant[37] = HexToFloat(0x46940000);
        boardSerialParam[i].constant[38] = HexToFloat(0x46980000);
        boardSerialParam[i].constant[39] = HexToFloat(0x469c0000);
        boardSerialParam[i].constant[40] = HexToFloat(0x46a00000);
        boardSerialParam[i].constant[41] = HexToFloat(0x46a40000);
        boardSerialParam[i].constant[42] = HexToFloat(0x46a80000);
        boardSerialParam[i].constant[43] = HexToFloat(0x46ac0000);
        boardSerialParam[i].constant[44] = HexToFloat(0x46b00000);
        boardSerialParam[i].constant[45] = HexToFloat(0x46b40000);
        boardSerialParam[i].constant[46] = HexToFloat(0x46b80000);
        boardSerialParam[i].constant[47] = HexToFloat(0x46bc0000);
        boardSerialParam[i].constant[48] = HexToFloat(0x46c00000);
        boardSerialParam[i].constant[49] = HexToFloat(0x46c40000);
        boardSerialParam[i].constant[50] = HexToFloat(0x46c80000);
        boardSerialParam[i].constant[51] = HexToFloat(0x46cc0000);
        boardSerialParam[i].constant[52] = HexToFloat(0x46d00000);
        boardSerialParam[i].constant[53] = HexToFloat(0x46d40000);
        boardSerialParam[i].constant[54] = HexToFloat(0x46d80000);
        boardSerialParam[i].constant[55] = HexToFloat(0x46dc0000);
        boardSerialParam[i].constant[56] = HexToFloat(0x46e00000);
        boardSerialParam[i].constant[57] = HexToFloat(0x46e40000);
        boardSerialParam[i].constant[58] = HexToFloat(0x46e80000);
        boardSerialParam[i].constant[59] = HexToFloat(0x46ec0000);
        boardSerialParam[i].constant[60] = HexToFloat(0x46f00000);
        boardSerialParam[i].constant[61] = HexToFloat(0x46f40000);
        boardSerialParam[i].constant[62] = HexToFloat(0x46f80000);
        boardSerialParam[i].constant[63] = HexToFloat(0x46fc0000);
        boardSerialParam[i].constant[64] = HexToFloat(0xc7000000);
        boardSerialParam[i].constant[65] = HexToFloat(0xc6fc0000);
        boardSerialParam[i].constant[66] = HexToFloat(0xc6f80000);
        boardSerialParam[i].constant[67] = HexToFloat(0xc6f40000);
        boardSerialParam[i].constant[68] = HexToFloat(0xc6f00000);
        boardSerialParam[i].constant[69] = HexToFloat(0xc6ec0000);
        boardSerialParam[i].constant[70] = HexToFloat(0xc6e80000);
        boardSerialParam[i].constant[71] = HexToFloat(0xc6e40000);
        boardSerialParam[i].constant[72] = HexToFloat(0xc6e00000);
        boardSerialParam[i].constant[73] = HexToFloat(0xc6dc0000);
        boardSerialParam[i].constant[74] = HexToFloat(0xc6d80000);
        boardSerialParam[i].constant[75] = HexToFloat(0xc6d40000);
        boardSerialParam[i].constant[76] = HexToFloat(0xc6d00000);
        boardSerialParam[i].constant[77] = HexToFloat(0xc6cc0000);
        boardSerialParam[i].constant[78] = HexToFloat(0xc6c80000);
        boardSerialParam[i].constant[79] = HexToFloat(0xc6c40000);
        boardSerialParam[i].constant[80] = HexToFloat(0xc6c00000);
        boardSerialParam[i].constant[81] = HexToFloat(0xc6bc0000);
        boardSerialParam[i].constant[82] = HexToFloat(0xc6b80000);
        boardSerialParam[i].constant[83] = HexToFloat(0xc6b40000);
        boardSerialParam[i].constant[84] = HexToFloat(0xc6b00000);
        boardSerialParam[i].constant[85] = HexToFloat(0xc6ac0000);
        boardSerialParam[i].constant[86] = HexToFloat(0xc6a80000);
        boardSerialParam[i].constant[87] = HexToFloat(0xc6a40000);
        boardSerialParam[i].constant[88] = HexToFloat(0xc6a00000);
        boardSerialParam[i].constant[89] = HexToFloat(0xc69c0000);
        boardSerialParam[i].constant[90] = HexToFloat(0xc6980000);
        boardSerialParam[i].constant[91] = HexToFloat(0xc6940000);
        boardSerialParam[i].constant[92] = HexToFloat(0xc6900000);
        boardSerialParam[i].constant[93] = HexToFloat(0xc68c0000);
        boardSerialParam[i].constant[94] = HexToFloat(0xc6880000);
        boardSerialParam[i].constant[95] = HexToFloat(0xc6840000);
        boardSerialParam[i].constant[96] = HexToFloat(0xc6800000);
        boardSerialParam[i].constant[97] = HexToFloat(0xc6780000);
        boardSerialParam[i].constant[98] = HexToFloat(0xc6700000);
        boardSerialParam[i].constant[99] = HexToFloat(0xc6680000);
        boardSerialParam[i].constant[100] = HexToFloat(0xc6600000);
        boardSerialParam[i].constant[101] = HexToFloat(0xc6580000);
        boardSerialParam[i].constant[102] = HexToFloat(0xc6500000);
        boardSerialParam[i].constant[103] = HexToFloat(0xc6480000);
        boardSerialParam[i].constant[104] = HexToFloat(0xc6400000);
        boardSerialParam[i].constant[105] = HexToFloat(0xc6380000);
        boardSerialParam[i].constant[106] = HexToFloat(0xc6300000);
        boardSerialParam[i].constant[107] = HexToFloat(0xc6280000);
        boardSerialParam[i].constant[108] = HexToFloat(0xc6200000);
        boardSerialParam[i].constant[109] = HexToFloat(0xc6180000);
        boardSerialParam[i].constant[110] = HexToFloat(0xc6100000);
        boardSerialParam[i].constant[111] = HexToFloat(0xc6080000);
        boardSerialParam[i].constant[112] = HexToFloat(0xc6000000);
        boardSerialParam[i].constant[113] = HexToFloat(0xc5f00000);
        boardSerialParam[i].constant[114] = HexToFloat(0xc5e00000);
        boardSerialParam[i].constant[115] = HexToFloat(0xc5d00000);
        boardSerialParam[i].constant[116] = HexToFloat(0xc5c00000);
        boardSerialParam[i].constant[117] = HexToFloat(0xc5b00000);
        boardSerialParam[i].constant[118] = HexToFloat(0xc5a00000);
        boardSerialParam[i].constant[119] = HexToFloat(0xc5900000);
        boardSerialParam[i].constant[120] = HexToFloat(0xc5800000);
        boardSerialParam[i].constant[121] = HexToFloat(0xc5600000);
        boardSerialParam[i].constant[122] = HexToFloat(0xc5400000);
        boardSerialParam[i].constant[123] = HexToFloat(0xc5200000);
        boardSerialParam[i].constant[124] = HexToFloat(0xc5000000);
        boardSerialParam[i].constant[125] = HexToFloat(0xc4c00000);
        boardSerialParam[i].constant[126] = HexToFloat(0xc4800000);
        boardSerialParam[i].constant[127] = HexToFloat(0xc4000000);
    }

    FeatureRegInit(&wLevelCoff, &featureParam, boardSerialParam);

    /* init the parameter */
    // rand()%(Y-X+1)+X
    dataSetNum = rand() % (int)(pow(2, 31) - 1);
    pFreqData = (freqData *)malloc(sizeof(freqData) * dataSetNum + 1);
    if (pFreqData == NULL)
    {
        printf("malloc error\n");
        return MALLOC_ERROR;
    }

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetFeatureAnalysisVal(pFreqData, (int *)&num, dataSetNum);
    if (NO_ERROR != iRet)
    {
        free(pFreqData);
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]Ave:%f,\
                                    [Output]Var:%f,\
                                    [Output]Max:%f,\
                                    [Output]Min:%f,\
                                    [Output]HAve:%f,\
                                    [Output]HVar:%f,\
                                    [Output]LAve:%f,\
                                    [Output]LVar:%f,\
                                    [Output]HHAve:%f,\
                                    [Output]HHVar:%f,\
                                    [Output]HLAve:%f,\
                                    [Output]HLVar:%f,\
                                    [Output]LHAve:%f,\
                                    [Output]LHVar:%f,\
                                    [Output]LLAve:%f,\
                                    [Output]LLVar:%f,\
                                    [Output]HHHAve:%f,\
                                    [Output]HHHVar:%f,\
                                    [Output]HHLAve:%f,\
                                    [Output]HHLVar:%f,\
                                    [Output]HLHAve:%f,\
                                    [Output]HLHVar:%f,\
                                    [Output]HLLAve:%f,\
                                    [Output]HLLVar:%f,\
                                    [Output]LHHAve:%f,\
                                    [Output]LHHVar:%f,\
                                    [Output]LHLAve:%f,\
                                    [Output]LHLVar:%f,\
                                    [Output]LLHAve:%f,\
                                    [Output]LLHVar:%f,\
                                    [Output]LLLAve:%f,\
                                    [Output]LLLVar:%f,\
                                    [Output]HCount:%f,\
                                    [Output]LCount:%f,\
                                    [Output]HHCount:%f,\
                                    [Output]HLCount:%f,\
                                    [Output]LHCount:%f,\
                                    [Output]LLCount:%f,\
                                    [Output]HHHCount:%f,\
                                    [Output]HHLCount:%f,\
                                    [Output]HLHCount:%f,\
                                    [Output]HLLCount:%f,\
                                    [Output]LHHCount:%f,\
                                    [Output]LHLCount:%f,\
                                    [Output]LLHCount:%f,\
                                    [Output]LLLCount:%f,\
                                    [Output]Lvl1Ave:%f,\
                                    [Output]Lvl1Var:%f,\
                                    [Output]Lvl2Ave:%f,\
                                    [Output]Lvl2Var:%f,\
                                    [Output]Lvl3Ave:%f,\
                                    [Output]Lvl3Var:%f,\
                                    [Output]Lvl4Ave:%f,\
                                    [Output]Lvl4Var:%f,\
                                    [Output]Lvl5Ave:%f,\
                                    [Output]Lvl5Var:%f,\
                                    [Output]Lvl1Count:%f,\
                                    [Output]Lvl2Count:%f,\
                                    [Output]Lvl3Count:%f,\
                                    [Output]Lvl4Count:%f,\
                                    [Output]Lvl5Count:%f,\
                                    [Output]LvlCount:%f,\
                                    [Output]Lvl1Duty:%f,\
                                    [Output]Lvl2Duty:%f,\
                                    [Output]Lvl3Duty:%f,\
                                    [Output]Lvl4Duty:%f,\
                                    [Output]Lvl5Duty:%f,\
                                    [Output]num:%d,\
                                    [Input]dataSetNum:%d,\
                                    ",
            pFreqData->Ave,
            pFreqData->Var,
            pFreqData->Max,
            pFreqData->Min,
            pFreqData->HAve,
            pFreqData->HVar,
            pFreqData->LAve,
            pFreqData->LVar,
            pFreqData->HHAve,
            pFreqData->HHVar,
            pFreqData->HLAve,
            pFreqData->HLVar,
            pFreqData->LHAve,
            pFreqData->LHVar,
            pFreqData->LLAve,
            pFreqData->LLVar,
            pFreqData->HHHAve,
            pFreqData->HHHVar,
            pFreqData->HHLAve,
            pFreqData->HHLVar,
            pFreqData->HLHAve,
            pFreqData->HLHVar,
            pFreqData->HLLAve,
            pFreqData->HLLVar,
            pFreqData->LHHAve,
            pFreqData->LHHVar,
            pFreqData->LHLAve,
            pFreqData->LHLVar,
            pFreqData->LLHAve,
            pFreqData->LLHVar,
            pFreqData->LLLAve,
            pFreqData->LLLVar,
            pFreqData->HCount,
            pFreqData->LCount,
            pFreqData->HHCount,
            pFreqData->HLCount,
            pFreqData->LHCount,
            pFreqData->LLCount,
            pFreqData->HHHCount,
            pFreqData->HHLCount,
            pFreqData->HLHCount,
            pFreqData->HLLCount,
            pFreqData->LHHCount,
            pFreqData->LHLCount,
            pFreqData->LLHCount,
            pFreqData->LLLCount,
            pFreqData->Lvl1Ave,
            pFreqData->Lvl1Var,
            pFreqData->Lvl2Ave,
            pFreqData->Lvl2Var,
            pFreqData->Lvl3Ave,
            pFreqData->Lvl3Var,
            pFreqData->Lvl4Ave,
            pFreqData->Lvl4Var,
            pFreqData->Lvl5Ave,
            pFreqData->Lvl5Var,
            pFreqData->Lvl1Count,
            pFreqData->Lvl2Count,
            pFreqData->Lvl3Count,
            pFreqData->Lvl4Count,
            pFreqData->Lvl5Count,
            pFreqData->LvlCount,
            pFreqData->Lvl1Duty,
            pFreqData->Lvl2Duty,
            pFreqData->Lvl3Duty,
            pFreqData->Lvl4Duty,
            pFreqData->Lvl5Duty,
            num, dataSetNum);

    /* calculate the past time */
    *pasttime = end - start;
    free(pFreqData);
    return NO_ERROR;
}

int SetRfFreqModeTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int mode = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    mode = rand() % 4 + 1;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = SetRfFreqMode(mode);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]mode:%d", mode);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetRfFreqModeTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int mode = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetRfFreqMode(&mode);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]mode:%d", mode);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int FeatureAnalysisEnableTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = FeatureAnalysisEnable();
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "-");

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int FeatureAnalysisDisableTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = FeatureAnalysisDisable();
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "-");

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int SetFeatureAnalysisParameterTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int ch = 0;
    FeatureAnalysisParameter featureParam = {0};

    /* init the parameter */
    // rand()%(Y-X+1)+X
    // x ＋ 1.0 * rand() / RAND_MAX * ( y - x )
    featureParam.movingAverage_Count = rand() % (int)(pow(2, 31) - 1);
    ;
    featureParam.transitionJudge_LowLimitCount = rand() % (int)(pow(2, 31) - 1);
    ;
    featureParam.transitionJudge_LowLimitSigma = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.transitionJudge_UpperLimitCv = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.transitionJudge_LowLimitDuty = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.transitionJudge_SigmaDiffCofficient = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.aggregationJudge_Sigma = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.aggregationJudge_DiffPercentage = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.aggregationJudge_DiffVoltage = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.aggregationWeights_CvThreshold = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    featureParam.aggregationWeights_LowLimit = 1.0 * rand() / RAND_MAX * (3.4 * pow(10, 38));
    ch = rand() % 2;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = SetFeatureAnalysisParameter(&featureParam, ch);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]movingAverage_Count:%d,\
                                    [Input]transitionJudge_LowLimitCount:%d,\
                                    [Input]transitionJudge_LowLimitSigma:%f,\
                                    [Input]transitionJudge_UpperLimitCv:%f,\
                                    [Input]transitionJudge_LowLimitDuty:%f,\
                                    [Input]transitionJudge_SigmaDiffCofficient:%f,\
                                    [Input]aggregationJudge_Sigma:%f,\
                                    [Input]aggregationJudge_DiffPercentage:%f,\
                                    [Input]aggregationJudge_DiffVoltage:%f,\
                                    [Input]aggregationWeights_CvThreshold:%f,\
                                    [Input]aggregationWeights_LowLimit:%f,\
                                    [Input]ch:%d,\
                                    ",
            featureParam.movingAverage_Count,
            featureParam.transitionJudge_LowLimitCount,
            featureParam.transitionJudge_LowLimitSigma,
            featureParam.transitionJudge_UpperLimitCv,
            featureParam.transitionJudge_LowLimitDuty,
            featureParam.transitionJudge_SigmaDiffCofficient,
            featureParam.aggregationJudge_Sigma,
            featureParam.aggregationJudge_DiffPercentage,
            featureParam.aggregationJudge_DiffVoltage,
            featureParam.aggregationWeights_CvThreshold,
            featureParam.aggregationWeights_LowLimit,
            ch);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetFeatureAnalysisParameterTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int ch = 0;
    FeatureAnalysisParameter featureParam = {0};

    /* init the parameter */
    // rand()%(Y-X+1)+X
    ch = rand() % 2;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetFeatureAnalysisParameter(&featureParam, ch);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]movingAverage_Count:%d,\
                                    [Output]transitionJudge_LowLimitCount:%d,\
                                    [Output]transitionJudge_LowLimitSigma:%f,\
                                    [Output]transitionJudge_UpperLimitCv:%f,\
                                    [Output]transitionJudge_LowLimitDuty:%f,\
                                    [Output]transitionJudge_SigmaDiffCofficient:%f,\
                                    [Output]aggregationJudge_Sigma:%f,\
                                    [Output]aggregationJudge_DiffPercentage:%f,\
                                    [Output]aggregationJudge_DiffVoltage:%f,\
                                    [Output]aggregationWeights_CvThreshold:%f,\
                                    [Output]aggregationWeights_LowLimit:%f,\
                                    [Input]ch:%d,\
                                    ",
            featureParam.movingAverage_Count,
            featureParam.transitionJudge_LowLimitCount,
            featureParam.transitionJudge_LowLimitSigma,
            featureParam.transitionJudge_UpperLimitCv,
            featureParam.transitionJudge_LowLimitDuty,
            featureParam.transitionJudge_SigmaDiffCofficient,
            featureParam.aggregationJudge_Sigma,
            featureParam.aggregationJudge_DiffPercentage,
            featureParam.aggregationJudge_DiffVoltage,
            featureParam.aggregationWeights_CvThreshold,
            featureParam.aggregationWeights_LowLimit,
            ch);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int SetDownSamplingModeTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int thinningNum = 0;

    /* init the parameter */
    // rand()%(Y-X+1)+X
    thinningNum = rand() % 4 + 1;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = SetDownSamplingMode(thinningNum);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Input]thinningNum:%d", thinningNum);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int GetDownSamplingModeTime(char *time_str, char *parameter_str, long long *pasttime)
{
    int iRet = 0;
    int mode = 0;

    /* get the start time */
    gettimeofday(&start_time, NULL);
    start = (long long)start_time.tv_sec * (long long)1000000 + (long long)start_time.tv_usec;

    /* run api */
    iRet = GetRfFreqMode(&mode);
    if (NO_ERROR != iRet)
    {
        return TIME_STATISTIC_ERROR;
    }

    /* get the end time */
    gettimeofday(&end_time, NULL);
    end = (long long)end_time.tv_sec * (long long)1000000 + (long long)end_time.tv_usec;

    /* transform the time */
    get_local_time(time_str, 128, &start_time);

    /* transfer the parameter_str */
    sprintf((char *)parameter_str, "[Output]mode:%d", mode);

    /* calculate the past time */
    *pasttime = end - start;

    return NO_ERROR;
}

int TimeStatistc()
{
    char *cData;
    char local_time_str[128];
    char parameter_str[2048];
    char fileName[1024] = "Time_Use.csv";
    uint8_t cBuf[4096];
    int iRet = 0;
    int iNum = 1;
    long long pasttime = 0;
    FILE *tempFp = NULL;
    cData = "NO.,Time Stamp,API,Used Time(us),Parameter";

    tempFp = fopen(fileName, "wb+");
    if (tempFp == NULL)
    {
        printf("fopen error\n");
        return OPEN_ERROR;
    }
    fclose(tempFp);
    putString2Csv(cData, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);

    /* calculate the LedControl time*/
    iRet = LedControlTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate LedControl time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,LedControl,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the VersionAccess time*/
    iRet = VersionAccessTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate VersionAccess time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,VersionAccess,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the DipSWRead time*/
    iRet = DipSWReadTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate DipSWRead time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,DipSWRead,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the GetCPUTemp time*/
    iRet = GetCPUTempTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate GetCPUTemp time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,GetCPUTemp,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the WdtStart time*/
    iRet = WdtStartTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate WdtStart time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,WdtStart,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the WdtReset time*/
    iRet = WdtResetTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate WdtReset time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,WdtReset,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the WdtStop time*/
    iRet = WdtStopTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate WdtStop time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,WdtStop,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the GetBrdTemp time*/
    iRet = GetBrdTempTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate GetBrdTemp time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,GetBrdTemp,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the GetFanState time*/
    iRet = GetFanStateTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate GetFanState time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,GetFanState,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the ExIoAreaRead time*/
    iRet = ExIoAreaReadTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate ExIoAreaRead time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,ExIoAreaRead,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the ExIoAreaWrite time*/
    iRet = ExIoAreaWriteTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate ExIoAreaWrite time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,ExIoAreaWrite,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the DNetWrite time*/
    iRet = DNetWriteTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate DNetWrite time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,DNetWrite,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    /* calculate the DNetRead time*/
    iRet = DNetReadTime(local_time_str, parameter_str, &pasttime);
    if (NO_ERROR != iRet)
    {
        printf("fail to calculate DNetRead time\n");
        return iRet;
    }
    sprintf((char *)cBuf, "%d,%s,DNetRead,%lld,%s", iNum, local_time_str, pasttime, parameter_str);
    putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);
    iNum++;

    return NO_ERROR;
}