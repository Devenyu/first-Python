/*******************************************************************************
**	File name		: test.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include <libaio.h>

#include "i2c.h"
#include "spi.h"
#include "gpio.h"
#include "common.h"
#include "dio_api.h"
#include "mem_map.h"
#include "file_api.h"
#include "calc_api.h"
#include "eeprom_api.h"
#include "cpufunc_api.h"
#include "Err32_def_api.h"
#include "Parameter_api.h"
#include "Algorithm_api.h"
#include "DataStrage_api.h"
#include "Communication_api.h"
#include "TimeStatistics_api.h"

/*------------------------------------------------------------------------------
                               static define
------------------------------------------------------------------------------*/

// int file_fd = 0;
int pdo_total_size = 0;
// AD_DATA_STRUCT *ad_temp_data = NULL;
// uint32_t iAD_Count = 0;
// uint16_t iAD_Timeuse = 0;
// uint32_t iAD_Offset = 0;
_Bool order_write_ready = FALSE;
_Bool order_read_ready = FALSE;
_Bool pdo_malloc_flag = FALSE;
_Bool temp_data_save_flag = FALSE;
// struct timeval AD_current_time;
PDO_SDO_BUFFER *pdo_sdo_buffer;
struct TFD_t *File;
/*------------------------------------------------------------------------------
                               function define
------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] LedCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int LedCtrl()
{
    int submenu_input = 0;
    int ctrl_ret = 0;
    int lednum = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- Led Control menu ------------------------------\n");
    printf("0:Turn on the led\n");
    printf("1:Turn off the led\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        printf("please input the number of led(0~3)\n");
        scanf("%d", &lednum);

        ctrl_ret = LedControl(lednum, GPIO_VAL_HIGH);
        if (NO_ERROR == ctrl_ret)
        {
            printf("control LED%d successfully\n", lednum);
        }
        else
        {
            printf("fail to control LED%d\n", lednum);
        }
        return RETURN_CUR_MENU;

    case 1:
        printf("please input the number of led(0~3)\n");
        scanf("%d", &lednum);

        ctrl_ret = LedControl(lednum, GPIO_VAL_LOW);
        if (NO_ERROR == ctrl_ret)
        {
            printf("turn on LED%d successfully\n", lednum);
        }
        else
        {
            printf("fail to turn on LED%d\n", lednum);
        }
        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] VersionAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int VersionAccess()
{
    int version;
    int ctrl_ret = 0;

    ctrl_ret = GetDeviceDriverVersion(&version);
    if (NO_ERROR == ctrl_ret)
    {
        printf("the version of the device is 0x%x\n", version);
    }
    else
    {
        printf("fail to get the version of the device\n");
    }
    printf("2 seconds later, it will return to the superior menu\n");
    Delay_Ms(2000);
    return RETURN_MAIN_MENU; /* return to the superior menu */
}

/*********************************************************************************
[function name] DipSWAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int DipSWAccess()
{
    int ReadData[2];
    int ctrl_ret = 0;

    ctrl_ret = DipSWRead(ReadData);
    if (NO_ERROR == ctrl_ret)
    {
        printf("the data of the sw is 0b %08x %08x\n", ReadData[0], ReadData[1]);
    }
    else
    {
        printf("fail to read the sw");
    }
    return RETURN_MAIN_MENU;
}

/*********************************************************************************
[function name] CpuTempAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int CpuTempAccess()
{
    double temperature;
    int ctrl_ret = 0;

    ctrl_ret = GetCPUTemp(&temperature);
    if (NO_ERROR == ctrl_ret)
    {
        printf("the temperature of the cpu is %f\n", temperature);
    }
    else
    {
        printf("fail to get the temperature of the cpu\n");
    }
    printf("2 seconds later, it will return to the superior menu\n");
    Delay_Ms(2000);
    return RETURN_MAIN_MENU; /* return to the superior menu */
}

/*********************************************************************************
[function name] WDTCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int WDTCtrl()
{
    int submenu_input = 0;
    int WdtSecond = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- WDT Control menu ------------------------------\n");
    printf("0:Start WDT\n");
    printf("1:Stop WDT\n");
    printf("2:Reset WDT\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        printf("please input the second of wdt\n");
        scanf("%d", &WdtSecond);
        WdtStart(WdtSecond);
        return RETURN_CUR_MENU;

    case 1:
        WdtStop();
        return RETURN_CUR_MENU;

    case 2:
        WdtReset();
        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] BoardTempAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int BoardTempAccess()
{
    int ctrl_ret = 0;
    double temperature[2];

    ctrl_ret = GetBrdTemp(temperature);
    if (NO_ERROR == ctrl_ret)
    {
        printf("the temperature of the board1 is %1.2f\n", temperature[0]);
        // printf("the temperature of the board2 is %1.2f\n", temperature[1]);
    }
    else
    {
        printf("fail to get the temperature of the board\n");
    }
    printf("2 seconds later, it will return to the superior menu\n");
    Delay_Ms(2000);
    return RETURN_MAIN_MENU; /* return to the superior menu */
}

/*********************************************************************************
[function name] FanAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int FanAccess()
{
    int FanState;
    int ctrl_ret = 0;

    ctrl_ret = GetFanState(&FanState);
    if (NO_ERROR == ctrl_ret)
    {
        printf("the State of FAN is %02d\n", FanState);
    }
    else
    {
        printf("fail to get the state of FAN\n");
    }
    printf("2 seconds later, it will return to the superior menu\n");
    Delay_Ms(2000);
    return RETURN_MAIN_MENU; /* return to the superior menu */
}

/*********************************************************************************
[function name] TimeAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int TimeAccess()
{
    int ctrl_ret = 0;
    struct timeval tx, tx_start;
    struct timezone tz, tz_start;
    // time.tv_sec = 1606107059;
    // time.tv_usec = 645224;
    gettimeofday(&tx_start, &tz_start);
    // long start = ((long)tx_start.tv_sec) * 1000 + ((long)tx_start.tv_usec) / 1000;
    printf("Now, the second is %ld\n", tx_start.tv_sec);
    printf("Now, the microsecond is %ld\n", tx_start.tv_usec);
    printf("Now, the time difference with Greenwich is %d\n", tz_start.tz_minuteswest);
    printf("Now, the DST correction for time lag is %d\n", tz_start.tz_dsttime);
    // printf("Start time: %ld ms\n", start); //灏丒锟斤拷闂磋浆鍖栦负姣E
    printf("please input the second :");
    scanf("%ld", &tx.tv_sec);
    printf("please input the microsecond :");
    scanf("%ld", &tx.tv_usec);
    printf("please input the second :");
    scanf("%d", &tz.tz_minuteswest);
    printf("please input the second :");
    scanf("%d", &tz.tz_dsttime);

    ctrl_ret = SetKernelDate(&tx, &tz);
    if (NO_ERROR == ctrl_ret)
    {
        printf("set time successfully\n");
    }
    else
    {
        printf("fail to set time\n");
    }

    gettimeofday(&tx_start, &tz_start);
    // long start = ((long)tx_start.tv_sec) * 1000 + ((long)tx_start.tv_usec) / 1000;
    printf("Now, the second is %ld\n", tx_start.tv_sec);
    printf("Now, the microsecond is %ld\n", tx_start.tv_usec);
    printf("Now, the time difference with Greenwich is %d\n", tz_start.tz_minuteswest);
    printf("Now, the DST correction for time lag is %d\n", tz_start.tz_dsttime);

    printf("2 seconds later, it will return to the superior menu\n");
    Delay_Ms(2000);
    return RETURN_MAIN_MENU; /* return to the superior menu */
}

/*********************************************************************************
[function name] EtherCATCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int EtherCATCtrl()
{
    int num = 0;
    int ctrl_ret = 0;
    int val_num = 0;
    int submenu_input = 0;
    int input_ret = 0;

    // int pdo_total_size = 0;
    char err_str[100];

    printf("-EtherCAT Control menu ------------------------------\n");
    printf("0:Read PDO from ECAT\n");
    printf("1:Write PDO to ECAT\n");
    printf("2:Get FoE Data\n");
    printf("3:Order Specific Data\n");
    printf("4:Get Specific Data\n");
    printf("5:Set Specific Data\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }

    switch (submenu_input)
    {
    case 0:
    {
        int *val;
        short size;
        int address;
        int count = 0;
        printf("please input the address of PDO\n0x");
        int ret_size = scanf("%x", &address);
        if (ret_size != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        // printf("the ret_addr is %d\n", ret_size);
        fflush(stdin);
        printf("please input the data size of PDO\n");
        ret_size = scanf("%hd", &size);
        if (ret_size != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        // printf("the ret_addr is %d\n", ret_size);
        fflush(stdin);

        if (0 == size % 4)
        {
            count = size / 4;
        }
        else
        {
            count = (size / 4) + 1;
        }
        val = (int *)malloc(size + 1);
        if (val == NULL)
        {
            printf("malloc error\n");
            return RETURN_CUR_MENU;
        }
        // printf("the address is %x\n", size);
        // printf("the dataSize is %d\n", address);
        ctrl_ret = ExIoAreaRead(address, size, val);
        if (NO_ERROR == ctrl_ret)
        {
            printf("the result of the reading is \n");
            for (int i = 0; i < count; i++)
            {
                printf("val[%d] = 0x%x\n", i, val[i]);
            }
        }
        else
        {
            printf("fail to read the PDO\n");
        }
        printf("\n");
        free(val);
        return RETURN_CUR_MENU;
    }

    case 1:
    {
        int *val;
        uint8_t *array;
        short size;
        int address;
        printf("please input the address of PDO\n0x");
        int ret_size = scanf("%x", &address);
        if (ret_size != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        // printf("the ret_addr is %d\n", ret_size);
        fflush(stdin);
        printf("please input the data size of PDO\n");
        ret_size = scanf("%hd", &size);
        if (ret_size != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        // printf("the ret_addr is %d\n", ret_size);
        fflush(stdin);

        val = (int *)malloc(size + 1);
        if (val == NULL)
        {
            printf("malloc error\n");
            return RETURN_CUR_MENU;
        }
        array = (uint8_t *)malloc(size + 1);
        if (array == NULL)
        {
            printf("malloc error\n");
            free(val);
            return RETURN_CUR_MENU;
        }
        for (int j = 0; j < size; j++)
        {
            array[j] = j;
        }
        memcpy(val, array, size);
        fflush(stdin);

        ctrl_ret = ExIoAreaWrite(address, size, val);
        if (NO_ERROR == ctrl_ret)
        {
            printf("write to the PDO successfully\n");
        }
        else
        {
            printf("fail to write to the PDO\n");
        }
        free(val);
        free(array);
        return RETURN_CUR_MENU;
    }

    case 2:
    {
        ctrl_ret = ExIoAreaFoERead();
        if (NO_ERROR == ctrl_ret)
        {
            printf("read the FOE successfully\n");
        }
        else
        {
            printf("fail to read the FOE\n");
        }
        return RETURN_CUR_MENU;
    }

    case 3:
    {
        int cmd;
        uint32_t *val;
        uint32_t *Address;
        int current_size = 0;
        uint16_t *DataSize;
        uint8_t *type;
        uint8_t *val_array;

        /* set the status of order_ready*/
        pdo_malloc_flag = TRUE;

        printf("please choose the cmd:\n0:Read Data\n1:Write Data\n");
        int ret_size = scanf("%d", &cmd);
        if (ret_size != 1)
        {
            fgets(err_str, 100, stdin);
            pdo_malloc_flag = FALSE;
            return RETURN_CUR_MENU;
        }

        /* Judge the cmd is whether valid */
        if (WRITE_CMD == cmd)
        {
            printf("please input the number of Address:\n");
            ret_size = scanf("%d", &num);
            if (ret_size != 1)
            {
                fgets(err_str, 100, stdin);
                pdo_malloc_flag = FALSE;
                return RETURN_CUR_MENU;
            }

            /* malloc the address and size*/
            Address = (uint32_t *)malloc(sizeof(uint32_t) * num + 1);
            if (Address == NULL)
            {
                printf("malloc error\n");
                return RETURN_CUR_MENU;
            }
            DataSize = (uint16_t *)malloc(sizeof(uint16_t) * num + 1);
            if (DataSize == NULL)
            {
                printf("malloc error\n");
                free(Address);
                return RETURN_CUR_MENU;
            }
            val = (uint32_t *)malloc(10000 + 1);
            if (val == NULL)
            {
                printf("malloc error\n");
                free(Address);
                free(DataSize);
                return RETURN_CUR_MENU;
            }
            type = (uint8_t *)malloc(sizeof(uint8_t) * num + 1);

            if (type == NULL)
            {
                printf("malloc error\n");
                free(Address);
                free(DataSize);
                free(val);
                return RETURN_CUR_MENU;
            }
            pdo_sdo_buffer = (PDO_SDO_BUFFER *)malloc(sizeof(PDO_SDO_BUFFER) * num + 1);
            if (pdo_sdo_buffer == NULL)
            {
                printf("malloc error\n");
                free(Address);
                free(DataSize);
                free(val);
                free(type);
                return RETURN_CUR_MENU;
            }

            for (int i = 0; i < num; i++)
            {
                printf("please input the address[%d]:\n0x", i);
                ret_size = scanf("%x", &Address[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(val);
                    free(type);
                    free(pdo_sdo_buffer);
                    // order_ready = FALSE;
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }

                printf("please input the size[%d]:\n", i);
                ret_size = scanf("%hd", &DataSize[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(val);
                    free(type);
                    free(pdo_sdo_buffer);
                    // order_ready = FALSE;
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }

                printf("please input the type[%d](0:PDO   1:SDO):\n", i);
                ret_size = scanf("%hhd", &type[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(val);
                    free(type);
                    free(pdo_sdo_buffer);
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }

                val_array = (uint8_t *)malloc(sizeof(uint8_t) * DataSize[i] + 1);
                if (val_array == NULL)
                {
                    printf("malloc error\n");
                    return RETURN_CUR_MENU;
                }
                pdo_total_size += DataSize[i];
                for (int j = 0; j < DataSize[i]; j++)
                {
                    val_array[j] = j;
                }

                memcpy(val + current_size, val_array, DataSize[i]);
                current_size += DataSize[i];
                free(val_array);
            }

            ctrl_ret = OrderSpecificData((int *)Address, (short *)DataSize, (int *)val, (char *)type, num, cmd, pdo_sdo_buffer);

            free(Address);
            free(DataSize);
            free(val);
            free(type);

            if (NO_ERROR == ctrl_ret)
            {
                printf("order successfully\n");
                order_write_ready = TRUE;
                return RETURN_CUR_MENU;
            }
            else
            {
                printf("fail to order\n");
                // order_ready = FALSE;
                pdo_malloc_flag = FALSE;
                free(pdo_sdo_buffer);
                return RETURN_CUR_MENU;
            }
        }
        else if (READ_CMD == cmd)
        {
            printf("please input the number of Address:\n");
            ret_size = scanf("%d", &num);
            if (ret_size != 1)
            {
                fgets(err_str, 100, stdin);
                pdo_malloc_flag = FALSE;
                return RETURN_CUR_MENU;
            }

            /* malloc the address and size*/
            // printf("---------------------------\n");
            Address = (uint32_t *)malloc(sizeof(uint32_t) * num + 1);
            if (Address == NULL)
            {
                printf("malloc error\n");
                return RETURN_CUR_MENU;
            }
            // printf("===========================\n");
            DataSize = (uint16_t *)malloc(sizeof(uint16_t) * num + 1);
            if (DataSize == NULL)
            {
                printf("malloc error\n");
                free(Address);
                return RETURN_CUR_MENU;
            }
            // val = (uint32_t *)malloc(pdo_total_size);
            // printf("***************************\n");
            type = (uint8_t *)malloc(sizeof(uint8_t) * num + 1);
            if (type == NULL)
            {
                printf("malloc error\n");
                free(Address);
                free(DataSize);
                return RETURN_CUR_MENU;
            }
            pdo_sdo_buffer = (PDO_SDO_BUFFER *)malloc(sizeof(PDO_SDO_BUFFER) * num + 1);
            if (pdo_sdo_buffer == NULL)
            {
                printf("malloc error\n");
                free(Address);
                free(DataSize);
                free(pdo_sdo_buffer);
                return RETURN_CUR_MENU;
            }

            for (int i = 0; i < num; i++)
            {
                printf("please input the address[%d]:\n0x", i);
                ret_size = scanf("%x", &Address[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(type);
                    free(pdo_sdo_buffer);
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }

                printf("please input the size[%d]:\n", i);
                ret_size = scanf("%hd", &DataSize[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(type);
                    free(pdo_sdo_buffer);
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }
                pdo_total_size += DataSize[i];

                printf("please input the type[%d](0:PDO   1:SDO):\n", i);
                ret_size = scanf("%hhd", &type[i]);
                if (ret_size != 1)
                {
                    fgets(err_str, 100, stdin);
                    free(Address);
                    free(DataSize);
                    free(type);
                    free(pdo_sdo_buffer);
                    pdo_malloc_flag = FALSE;
                    return RETURN_CUR_MENU;
                }
            }

            val = (uint32_t *)malloc(pdo_total_size + 1);
            ctrl_ret = OrderSpecificData((int *)Address, (short *)DataSize, (int *)val, (char *)type, num, cmd, pdo_sdo_buffer);
            printf("the pdo_total_size is %d\n", pdo_total_size);

            free(Address);
            free(DataSize);
            free(val);
            free(type);

            if (NO_ERROR == ctrl_ret)
            {
                printf("order successfully\n");
                order_read_ready = TRUE;
                return RETURN_CUR_MENU;
            }
            else
            {
                // order_ready = FALSE;
                pdo_malloc_flag = FALSE;
                free(pdo_sdo_buffer);
                printf("fail to order\n");
                return RETURN_CUR_MENU;
            }
        }
        else
        {
            printf("cmd error\nplease try again\n");
            return RETURN_CUR_MENU;
        }
    }

    case 4:
    {
        /* judge whether the data is ordered or not */
        if (FALSE == order_read_ready)
        {
            printf("please order the data firstly\n");
            return RETURN_CUR_MENU;
        }
#if 1
        for (int i = 0; i < num; i++)
        {
            printf("address[%d]: 0x%x\n", i, pdo_sdo_buffer[i].read_address);
            printf("datasize[%d]: 0x%x\n", i, pdo_sdo_buffer[i].read_datasize);
        }
#endif
        int *val = (int *)malloc(pdo_total_size + 1);
        if (val == NULL)
        {
            printf("malloc error\n");
            return RETURN_CUR_MENU;
        }
        ctrl_ret = GetExIoSpecificData(num, val, pdo_sdo_buffer);

        if (NO_ERROR != ctrl_ret)
        {
            printf("read error");
            free(val);
            return RETURN_CUR_MENU;
        }

        if (0 == (pdo_total_size % 4))
        {
            val_num = pdo_total_size / 4;
        }
        else
        {
            val_num = (pdo_total_size / 4) + 1;
        }
        printf("the pdo_total_size is %d\n", pdo_total_size);
        printf("the val_num is %d\n", val_num);
        printf("the result of the reading is \n");
        for (int i = 0; i < val_num; i++)
        {
            printf("val[%d] = 0x%x\n", i, val[i]);
        }

        pdo_total_size = 0;
        order_read_ready = FALSE;
        pdo_malloc_flag = FALSE;
        free(val);
        free(pdo_sdo_buffer);

        return RETURN_CUR_MENU;
    }

    case 5:
    {
        /* judge whether the data is ordered or not */
        if (FALSE == order_write_ready)
        {
            printf("please order the data firstly\n");
            return RETURN_CUR_MENU;
        }

#if 1
        for (int i = 0; i < num; i++)
        {
            printf("address[%d]: 0x%x\n", i, pdo_sdo_buffer[i].write_address);
            printf("datasize[%d]: 0x%x\n", i, pdo_sdo_buffer[i].write_datasize);
            if (0 == (pdo_total_size % 4))
            {
                val_num = pdo_sdo_buffer[i].write_datasize / 4;
            }
            else
            {
                val_num = (pdo_sdo_buffer[i].write_datasize / 4) + 1;
            }
            for (int j = 0; j < val_num; j++)
            {
                printf("val[%d]: %d\n", j, pdo_sdo_buffer[i].write_value[j]);
            }
        }
#endif
        ctrl_ret = SetExIoSpecificData(num, pdo_sdo_buffer);

        if (NO_ERROR != ctrl_ret)
        {
            printf("write error");
        }
        else
        {
            printf("write successfully\n");
        }

        order_write_ready = FALSE;
        pdo_malloc_flag = FALSE;
        free(pdo_sdo_buffer);

        return RETURN_CUR_MENU;
    }

    case 99:
    {
        if (TRUE == pdo_malloc_flag)
        {
            printf("free the malloc\n");
            free(pdo_sdo_buffer);
            pdo_malloc_flag = FALSE;
        }

        return RETURN_MAIN_MENU; /* return to the superior menu */
    }

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] DeviceNetCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int DeviceNetCtrl()
{
    int submenu_input = 0;
    int input_ret = 0;
    int ctrl_ret = 0;
    DnetAccessObject dneObject = {0};
    DnetPollingObject dnePollingObject = {0};
    DnetIdentifyObject identifyParam = {0};
    DnetCommunicationSetting dnetParam = {0};

    char err_str[100];

    printf("- DeviceNet Control menu ------------------------------\n");
    printf("0:Init DeviceNet\n");
    printf("1:Read DeviceNet Data\n");
    printf("2:Write DeviceNet Data\n");
    printf("3:Read DeviceNet Polling Data\n");
    printf("4:Write DeviceNet Polling Data\n");
    printf("5:Get Identify Parameter\n");
    printf("6:Set Identify Parameter\n");
    printf("7:Get Dnet Parameter\n");
    printf("8:Set Dnet Parameter\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }

    switch (submenu_input)
    {
    case 0:
    {
        ctrl_ret = DNetInit();
        if (NO_ERROR == ctrl_ret)
        {
            printf("succeed to init DeviceNet\n");
        }
        else
        {
            printf("fail to init DeviceNet\n");
        }
        return RETURN_CUR_MENU;
    }

    case 1:
    {
        int dnet_enum = 0;

        printf("please input the ENUM of DeviceNet(%d~%d):", DNET_IDTY_MSG_ID_OBJ_REV, DNET_MSG_MAX_NUM);
        scanf("%d", &dnet_enum);
        fflush(stdin);
        printf("please input the address of DeviceNet\n0x");
        scanf("%hhx", &dneObject.address);
        fflush(stdin);
        printf("please input the data size of DeviceNet\n0x");
        scanf("%hhx", &dneObject.dataSize);
        fflush(stdin);
        dneObject.val = (uint8_t *)malloc(dneObject.dataSize + 1);
        if (dneObject.val == NULL)
        {
            printf("malloc error\n");
            return RETURN_CUR_MENU;
        }

        ctrl_ret = DNetRead(&dneObject, dnet_enum);
        if (NO_ERROR == ctrl_ret)
        {
            // printf("the result of the reading is %d\n", dneObject->);
            printf("succeed to read the date\n");
        }
        else
        {
            printf("fail to read the DeviceNet\n");
            free(dneObject.val);
            // free(dneObject);
            return RETURN_CUR_MENU;
        }
        printf("the service id of DeviceNet is 0x%02x\n", dneObject.serviceId);
        printf("the class id of DeviceNet is 0x%02x\n", dneObject.classId);
        printf("the instance id of DeviceNet is 0x%02x\n", dneObject.instanceId);
        printf("the attribute id of DeviceNet is 0x%02x\n", dneObject.attributeId);
        printf("the value of read:\n");
        for (int itmp = 0; itmp < dneObject.dataSize; itmp++)
        {
            printf("0x%02x ", dneObject.val[itmp]);
            if (0 == (itmp % 8))
            {
                if (0 != itmp)
                {
                    printf("\n");
                }
            }
        }
        printf("\n");
        free(dneObject.val);
        return RETURN_CUR_MENU;
    }

    case 2:
    {
        int dnet_enum = 0;

        printf("please input the ENUM of DeviceNet(%d~%d):", DNET_IDTY_MSG_ID_OBJ_REV, DNET_MSG_MAX_NUM);
        scanf("%d", &dnet_enum);
        fflush(stdin);
        printf("please input the address of DeviceNet\n0x");
        scanf("%hhx", &dneObject.address);
        fflush(stdin);
        printf("please input the data size of DeviceNet\n0x");
        scanf("%hhx", &dneObject.dataSize);
        fflush(stdin);

        dneObject.val = (uint8_t *)malloc(dneObject.dataSize + 1);
        if (dneObject.val == NULL)
        {
            printf("malloc error\n");
            return RETURN_CUR_MENU;
        }
        DEBUG_INFO("the datasize is %d", dneObject.dataSize);
        for (int j = 0; j < dneObject.dataSize; j++)
        {
            printf("please input the byte %d of data:\n0x", j);
            scanf("%hhx", &dneObject.val[j]);
        }
        fflush(stdin);
        ctrl_ret = DNetWrite(&dneObject, dnet_enum);
        if (NO_ERROR == ctrl_ret)
        {
            printf("write the DeviceNet Data successfully\n");
        }
        else
        {
            printf("fail to write the DeviceNet Data\n");
        }
        printf("Write DNet\n");
        free(dneObject.val);
        return RETURN_CUR_MENU;
    }

    case 3:
    {
        ctrl_ret = DNetPollingRead(&dnePollingObject);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Read the DeviceNet Polling Data successfully\n");
            for (int i = 0; i < DEVICENET_POLLING_DATASIZE; i++)
            {
                DEBUG_INFO("the data[%d] = 0x%x\n", i, dnePollingObject.send[i]);
            }
        }
        else
        {
            printf("fail to read the DeviceNet Polling Data\n");
        }

        return RETURN_CUR_MENU;
    }

    case 4:
    {
        uint8_t cTemp = 0;

        printf("please input the data of Polling mode\n0x");
        scanf("%hhx", &cTemp);
        fflush(stdin);

        for (int i = 0; i < DEVICENET_POLLING_DATASIZE; i++)
        {
            dnePollingObject.send[i] = cTemp;
        }

        ctrl_ret = DNetPollingWrite(&dnePollingObject);
        if (NO_ERROR == ctrl_ret)
        {
            printf("write the DeviceNet Polling Data successfully\n");
        }
        else
        {
            printf("fail to write the DeviceNet Polling Data\n");
        }

        return RETURN_CUR_MENU;
    }

    case 5:
    {
        ctrl_ret = DNetGetIdentifyParameter(&identifyParam);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Read the DeviceNet Identify Parameter successfully\n");
            printf("IdentifyObjectRevision=%d\n", identifyParam.IdentifyObjectRevision);
            printf("Vendor=%d\n", identifyParam.Vendor);
            printf("DeviceType=%d\n", identifyParam.DeviceType);
            printf("ProductCode=%d\n", identifyParam.ProductCode);
            printf("Revision=%d\n", identifyParam.Revision);
            printf("Status=%d\n", identifyParam.Status);
            printf("SerialNumber=%d\n", identifyParam.SerialNumber);
            printf("ProductName=%s\n", identifyParam.ProductName);
            printf("State=%d\n", identifyParam.State);
            printf("ConfigurationConsistencyValue=%d\n", identifyParam.ConfigurationConsistencyValue);
            printf("HeartbeatInterval=%d\n", identifyParam.HeartbeatInterval);
        }
        else
        {
            printf("fail to read the DeviceNet Identify Parameter\n");
        }

        return RETURN_CUR_MENU;
    }

    case 6:
    {
        printf("please input the IdentifyObjectRevision:");
        scanf("%d", &identifyParam.IdentifyObjectRevision);
        fflush(stdin);
        printf("please input the Vendor:");
        scanf("%d", &identifyParam.Vendor);
        fflush(stdin);
        printf("please input the DeviceType:");
        scanf("%d", &identifyParam.DeviceType);
        fflush(stdin);
        printf("please input the ProductCode:");
        scanf("%d", &identifyParam.ProductCode);
        fflush(stdin);
        printf("please input the Revision:");
        scanf("%d", &identifyParam.Revision);
        fflush(stdin);
        printf("please input the Status:");
        scanf("%d", &identifyParam.Status);
        fflush(stdin);
        printf("please input the SerialNumber:");
        scanf("%d", &identifyParam.SerialNumber);
        fflush(stdin);
        printf("please input the ProductName:");
        scanf("%s", identifyParam.ProductName);
        fflush(stdin);
        printf("please input the State:");
        scanf("%d", &identifyParam.State);
        fflush(stdin);
        printf("please input the ConfigurationConsistencyValue:");
        scanf("%d", &identifyParam.ConfigurationConsistencyValue);
        fflush(stdin);
        printf("please input the HeartbeatInterval:");
        scanf("%d", &identifyParam.HeartbeatInterval);
        fflush(stdin);
        ctrl_ret = DNetSetIdentifyParameter(&identifyParam);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Set Identify Parameter successfully\n");
        }
        else
        {
            printf("fail to set Identify Parameter\n");
        }
        return RETURN_CUR_MENU;
    }

    case 7:
    {
        ctrl_ret = DNetGetDnetParameter(&dnetParam);
        if (NO_ERROR == ctrl_ret)
        {
            printf("NodeAddress=%d\n", dnetParam.NodeAddress);
            printf("BaudRate=%d\n", dnetParam.BaudRate);
            printf("BusOffInterruption=%d\n", dnetParam.BusOffInterruption);
            printf("BusOffCounter=%d\n", dnetParam.BusOffCounter);
            printf("AllocationInformation=%d\n", dnetParam.AllocationInformation);
            printf("NodeAddressSwitchChanged=%d\n", dnetParam.NodeAddressSwitchChanged);
            printf("BaudRateSwitchChanged=%d\n", dnetParam.BaudRateSwitchChanged);
            printf("NodeAddressSwitchValue=%d\n", dnetParam.NodeAddressSwitchValue);
            printf("BaudRateSwitchValue=%d\n", dnetParam.BaudRateSwitchValue);
        }
        else
        {
            printf("fail to read the DeviceNet Communication Parameter\n");
        }

        return RETURN_CUR_MENU;
    }

    case 8:
    {
        printf("NodeAddress:");
        scanf("%d", &dnetParam.NodeAddress);
        fflush(stdin);
        printf("BaudRate:");
        scanf("%d", &dnetParam.BaudRate);
        fflush(stdin);
        printf("BusOffInterruption:");
        scanf("%d", &dnetParam.BusOffInterruption);
        fflush(stdin);
        printf("BusOffCounter:");
        scanf("%d", &dnetParam.BusOffCounter);
        fflush(stdin);
        printf("AllocationInformation:");
        scanf("%d", &dnetParam.AllocationInformation);
        fflush(stdin);
        printf("NodeAddressSwitchChanged:");
        scanf("%d", &dnetParam.NodeAddressSwitchChanged);
        fflush(stdin);
        printf("BaudRateSwitchChanged:");
        scanf("%d", &dnetParam.BaudRateSwitchChanged);
        fflush(stdin);
        printf("NodeAddressSwitchValue:");
        scanf("%d", &dnetParam.NodeAddressSwitchValue);
        fflush(stdin);
        printf("BaudRateSwitchValue:");
        scanf("%d", &dnetParam.BaudRateSwitchValue);
        fflush(stdin);
        ctrl_ret = DNetSetDnetParameter(&dnetParam);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Set Identify Parameter successfully\n");
        }
        else
        {
            printf("fail to set Identify Parameter\n");
        }
        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] MaxDataModeCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int MaxDataModeCtrl()
{
    int ctrl_ret = 0;
    int submenu_input = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- Max Data Set Mode Control menu ------------------------------\n");
    printf("0:Set Max Data Set Mode\n");
    printf("1:Get Max Data Set Mode\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }

    switch (submenu_input)
    {
    case 0:
    {
        int maxDataSet = 0;

        printf("please input the Max Data of set\n");
        scanf("%d", &maxDataSet);
        /* SetMaxDataSetMode */
        ctrl_ret = SetMaxDataSetMode(maxDataSet);

        if (NO_ERROR == ctrl_ret)
        {
            printf("set the Max Data Mode successfully\n");
        }
        else
        {
            printf("fail to set the Max Data Mode\n");
        }

        return RETURN_CUR_MENU;
    }

    case 1:
    {
        int maxDataSet;

        /* GetMaxDataSetMode */
        ctrl_ret = GetMaxDataSetMode(&maxDataSet);

        if (NO_ERROR == ctrl_ret)
        {
            printf("the max data set mode is %d\n", maxDataSet);
        }
        else
        {
            printf("fail to get the Max Data Mode\n");
        }

        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] WLevelCalcCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int WLevelCalcCtrl()
{
    int ch;
    int ctrl_ret = 0;
    int submenu_input = 0;
    int input_ret = 0;
    char err_str[100];
    WaferLevelCalcCoefficient wLevelCoff = {0};

    printf("- W Level Calc Coeff Control menu ------------------------------\n");
    printf("0:Set W Level Calc Coeff\n");
    printf("1:Get W Level Calc Coeff\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }

    switch (submenu_input)
    {
    case 0:
    {
        // wLevelCoff = malloc(sizeof(WaferLevelCalcCoefficient));
        printf("please input the matrix_1raw(float)\n");
        scanf("%f", &wLevelCoff.matrix_1raw);
        printf("please input the matrix_1clm(float)\n");
        scanf("%f", &wLevelCoff.matrix_1clm);
        printf("please input the matrix_2raw(float)\n");
        scanf("%f", &wLevelCoff.matrix_2raw);
        printf("please input the matrix_2clm(float)\n");
        scanf("%f", &wLevelCoff.matrix_2clm);
        printf("please input the matrix_3raw(float)\n");
        scanf("%f", &wLevelCoff.matrix_3raw);
        printf("please input the matrix_3clm(float)\n");
        scanf("%f", &wLevelCoff.matrix_3clm);
        printf("please input the matrix_4raw(float)\n");
        scanf("%f", &wLevelCoff.matrix_4raw);
        printf("please input the matrix_4clm(float)\n");
        scanf("%f", &wLevelCoff.matrix_4clm);
        printf("please input the ch(0~1)\n");
        scanf("%d", &ch);
        ctrl_ret = SetWlevelCalcCoeff(&wLevelCoff, ch);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Set Wlevel Calc Coeff successfully\n");
        }
        else
        {
            printf("fail to Set Wlevel Calc Coeff\n");
        }
        // free(wLevelCoff);
        return RETURN_CUR_MENU;
    }

    case 1:
    {
        // wLevelCoff = malloc(sizeof(WaferLevelCalcCoefficient));
        printf("please input the ch(0~1)\n");
        scanf("%d", &ch);
        GetWlevelCalcCoeff(&wLevelCoff, ch);
        printf("the matrix_1raw is %f\n", wLevelCoff.matrix_1raw);
        printf("the matrix_1clm is %f\n", wLevelCoff.matrix_1clm);
        printf("the matrix_2raw is %f\n", wLevelCoff.matrix_2raw);
        printf("the matrix_2clm is %f\n", wLevelCoff.matrix_2clm);
        printf("the matrix_3raw is %f\n", wLevelCoff.matrix_3raw);
        printf("the matrix_3clm is %f\n", wLevelCoff.matrix_3clm);
        printf("the matrix_4raw is %f\n", wLevelCoff.matrix_4raw);
        printf("the matrix_4clm is %f\n", wLevelCoff.matrix_4clm);
        // free(wLevelCoff);
        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] RfFreqModeAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int RfFreqModeAccess()
{
    int submenu_input = 0;
    int ctrl_ret = 0;
    int mode = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- Rf Freq Mode Control menu ------------------------------\n");
    printf("0:Set Rf Freq Mode\n");
    printf("1:Get Rf Freq Mode\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }

    switch (submenu_input)
    {
    case 0:
        printf("please input the mode of Rf Freq(1~4)\n");
        scanf("%d", &mode);
        /* SetFreqMode */
        ctrl_ret = SetRfFreqMode(mode);

        if (NO_ERROR == ctrl_ret)
        {
            printf("Set Rf Freq Mode successfully\n");
        }
        else
        {
            printf("fail to set Rf Freq Mode\n");
        }

        return RETURN_CUR_MENU;

    case 1:
        /* GetFreqMode */
        ctrl_ret = GetRfFreqMode(&mode);

        if (NO_ERROR == ctrl_ret)
        {
            printf("the mode of Rf Freq Mode is %d\n", mode);
        }
        else
        {
            printf("fail to get the Rf Freq Mode\n");
        }

        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] FeatureAnalysisCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int FeatureAnalysisCtrl()
{
    int submenu_input = 0;
    int ctrl_ret = 0;
    int input_ret = 0;
    int ch = 0;
    // int thinningNum = 0;
    char err_str[100];
    FeatureAnalysisParameter featureParam = {0};

    printf("- Feature Analysis Control menu ------------------------------\n");
    printf("0:Init Feature Analysis\n");
    printf("1:Enable Feature Analysis\n");
    printf("2:Disable Feature Analysis\n");
    printf("3:Set Feature Analysis Parameter\n");
    printf("4:Get Feature Analysis Parameter\n");
    printf("5:Get Feature Data\n");
    printf("6:Get Feature Analysis Data\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
    {
        WaferLevelCalcCoefficient wLevelCoff = {0};
        struct BoardSerialParam boardSerialParam[3] = {0};

        // wLevelCoff = (WaferLevelCalcCoefficient *)malloc(sizeof(WaferLevelCalcCoefficient));
        // featureParam = (FeatureAnalysisParameter *)malloc(sizeof(FeatureAnalysisParameter));
        // boardSerialParam = (struct BoardSerialParam *)malloc(sizeof(boardserial_param) * 3);
        wLevelCoff.matrix_1raw = HexToFloat(0x431fd75f);
        wLevelCoff.matrix_1clm = HexToFloat(0xc1c62594);
        wLevelCoff.matrix_2raw = HexToFloat(0x41fae752);
        wLevelCoff.matrix_2clm = HexToFloat(0x42d2ecd9);
        wLevelCoff.matrix_3raw = HexToFloat(0x3d15dfba);
        wLevelCoff.matrix_3clm = HexToFloat(0x3e71c0ae);
        wLevelCoff.matrix_4raw = HexToFloat(0x41c59887);
        wLevelCoff.matrix_4clm = HexToFloat(0xc0e42a6b);

        /* Init  Feature Analysis  parameters*/
        featureParam.movingAverage_Count = 0x3f800000;
        featureParam.transitionJudge_LowLimitCount = 0x41200000;
        featureParam.transitionJudge_LowLimitSigma = HexToFloat(0x40400000);
        featureParam.transitionJudge_UpperLimitCv = HexToFloat(0x3dcccccd);
        featureParam.transitionJudge_LowLimitDuty = HexToFloat(0x3dcccccd);
        featureParam.transitionJudge_SigmaDiffCofficient = HexToFloat(0x3f800000);
        featureParam.aggregationJudge_Sigma = HexToFloat(0x40400000);
        featureParam.aggregationJudge_DiffPercentage = HexToFloat(0x3dcccccd);
        featureParam.aggregationJudge_DiffVoltage = HexToFloat(0x41a00000);
        featureParam.aggregationWeights_CvThreshold = HexToFloat(0x40a00000);
        featureParam.aggregationWeights_LowLimit = HexToFloat(0x3f800000);

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 128; j++)
            {
                boardSerialParam[i].coff_1stOrder[j] = HexToFloat(0x3f800000);
            }

            boardSerialParam[i].constant[0] = HexToFloat(0x00000000);
            boardSerialParam[i].constant[1] = HexToFloat(0x44000000);
            boardSerialParam[i].constant[2] = HexToFloat(0x44800000);
            boardSerialParam[i].constant[3] = HexToFloat(0x44c00000);
            boardSerialParam[i].constant[4] = HexToFloat(0x45000000);
            boardSerialParam[i].constant[5] = HexToFloat(0x45200000);
            boardSerialParam[i].constant[6] = HexToFloat(0x45400000);
            boardSerialParam[i].constant[7] = HexToFloat(0x45600000);
            boardSerialParam[i].constant[8] = HexToFloat(0x45800000);
            boardSerialParam[i].constant[9] = HexToFloat(0x45900000);
            boardSerialParam[i].constant[10] = HexToFloat(0x45a00000);
            boardSerialParam[i].constant[11] = HexToFloat(0x45b00000);
            boardSerialParam[i].constant[12] = HexToFloat(0x45c00000);
            boardSerialParam[i].constant[13] = HexToFloat(0x45d00000);
            boardSerialParam[i].constant[14] = HexToFloat(0x45e00000);
            boardSerialParam[i].constant[15] = HexToFloat(0x45f00000);
            boardSerialParam[i].constant[16] = HexToFloat(0x46000000);
            boardSerialParam[i].constant[17] = HexToFloat(0x46080000);
            boardSerialParam[i].constant[18] = HexToFloat(0x46100000);
            boardSerialParam[i].constant[19] = HexToFloat(0x46180000);
            boardSerialParam[i].constant[20] = HexToFloat(0x46200000);
            boardSerialParam[i].constant[21] = HexToFloat(0x46280000);
            boardSerialParam[i].constant[22] = HexToFloat(0x46300000);
            boardSerialParam[i].constant[23] = HexToFloat(0x46380000);
            boardSerialParam[i].constant[24] = HexToFloat(0x46400000);
            boardSerialParam[i].constant[25] = HexToFloat(0x46480000);
            boardSerialParam[i].constant[26] = HexToFloat(0x46500000);
            boardSerialParam[i].constant[27] = HexToFloat(0x46580000);
            boardSerialParam[i].constant[28] = HexToFloat(0x46600000);
            boardSerialParam[i].constant[29] = HexToFloat(0x46680000);
            boardSerialParam[i].constant[30] = HexToFloat(0x46700000);
            boardSerialParam[i].constant[31] = HexToFloat(0x46780000);
            boardSerialParam[i].constant[32] = HexToFloat(0x46800000);
            boardSerialParam[i].constant[33] = HexToFloat(0x46840000);
            boardSerialParam[i].constant[34] = HexToFloat(0x46880000);
            boardSerialParam[i].constant[35] = HexToFloat(0x468c0000);
            boardSerialParam[i].constant[36] = HexToFloat(0x46900000);
            boardSerialParam[i].constant[37] = HexToFloat(0x46940000);
            boardSerialParam[i].constant[38] = HexToFloat(0x46980000);
            boardSerialParam[i].constant[39] = HexToFloat(0x469c0000);
            boardSerialParam[i].constant[40] = HexToFloat(0x46a00000);
            boardSerialParam[i].constant[41] = HexToFloat(0x46a40000);
            boardSerialParam[i].constant[42] = HexToFloat(0x46a80000);
            boardSerialParam[i].constant[43] = HexToFloat(0x46ac0000);
            boardSerialParam[i].constant[44] = HexToFloat(0x46b00000);
            boardSerialParam[i].constant[45] = HexToFloat(0x46b40000);
            boardSerialParam[i].constant[46] = HexToFloat(0x46b80000);
            boardSerialParam[i].constant[47] = HexToFloat(0x46bc0000);
            boardSerialParam[i].constant[48] = HexToFloat(0x46c00000);
            boardSerialParam[i].constant[49] = HexToFloat(0x46c40000);
            boardSerialParam[i].constant[50] = HexToFloat(0x46c80000);
            boardSerialParam[i].constant[51] = HexToFloat(0x46cc0000);
            boardSerialParam[i].constant[52] = HexToFloat(0x46d00000);
            boardSerialParam[i].constant[53] = HexToFloat(0x46d40000);
            boardSerialParam[i].constant[54] = HexToFloat(0x46d80000);
            boardSerialParam[i].constant[55] = HexToFloat(0x46dc0000);
            boardSerialParam[i].constant[56] = HexToFloat(0x46e00000);
            boardSerialParam[i].constant[57] = HexToFloat(0x46e40000);
            boardSerialParam[i].constant[58] = HexToFloat(0x46e80000);
            boardSerialParam[i].constant[59] = HexToFloat(0x46ec0000);
            boardSerialParam[i].constant[60] = HexToFloat(0x46f00000);
            boardSerialParam[i].constant[61] = HexToFloat(0x46f40000);
            boardSerialParam[i].constant[62] = HexToFloat(0x46f80000);
            boardSerialParam[i].constant[63] = HexToFloat(0x46fc0000);
            boardSerialParam[i].constant[64] = HexToFloat(0xc7000000);
            boardSerialParam[i].constant[65] = HexToFloat(0xc6fc0000);
            boardSerialParam[i].constant[66] = HexToFloat(0xc6f80000);
            boardSerialParam[i].constant[67] = HexToFloat(0xc6f40000);
            boardSerialParam[i].constant[68] = HexToFloat(0xc6f00000);
            boardSerialParam[i].constant[69] = HexToFloat(0xc6ec0000);
            boardSerialParam[i].constant[70] = HexToFloat(0xc6e80000);
            boardSerialParam[i].constant[71] = HexToFloat(0xc6e40000);
            boardSerialParam[i].constant[72] = HexToFloat(0xc6e00000);
            boardSerialParam[i].constant[73] = HexToFloat(0xc6dc0000);
            boardSerialParam[i].constant[74] = HexToFloat(0xc6d80000);
            boardSerialParam[i].constant[75] = HexToFloat(0xc6d40000);
            boardSerialParam[i].constant[76] = HexToFloat(0xc6d00000);
            boardSerialParam[i].constant[77] = HexToFloat(0xc6cc0000);
            boardSerialParam[i].constant[78] = HexToFloat(0xc6c80000);
            boardSerialParam[i].constant[79] = HexToFloat(0xc6c40000);
            boardSerialParam[i].constant[80] = HexToFloat(0xc6c00000);
            boardSerialParam[i].constant[81] = HexToFloat(0xc6bc0000);
            boardSerialParam[i].constant[82] = HexToFloat(0xc6b80000);
            boardSerialParam[i].constant[83] = HexToFloat(0xc6b40000);
            boardSerialParam[i].constant[84] = HexToFloat(0xc6b00000);
            boardSerialParam[i].constant[85] = HexToFloat(0xc6ac0000);
            boardSerialParam[i].constant[86] = HexToFloat(0xc6a80000);
            boardSerialParam[i].constant[87] = HexToFloat(0xc6a40000);
            boardSerialParam[i].constant[88] = HexToFloat(0xc6a00000);
            boardSerialParam[i].constant[89] = HexToFloat(0xc69c0000);
            boardSerialParam[i].constant[90] = HexToFloat(0xc6980000);
            boardSerialParam[i].constant[91] = HexToFloat(0xc6940000);
            boardSerialParam[i].constant[92] = HexToFloat(0xc6900000);
            boardSerialParam[i].constant[93] = HexToFloat(0xc68c0000);
            boardSerialParam[i].constant[94] = HexToFloat(0xc6880000);
            boardSerialParam[i].constant[95] = HexToFloat(0xc6840000);
            boardSerialParam[i].constant[96] = HexToFloat(0xc6800000);
            boardSerialParam[i].constant[97] = HexToFloat(0xc6780000);
            boardSerialParam[i].constant[98] = HexToFloat(0xc6700000);
            boardSerialParam[i].constant[99] = HexToFloat(0xc6680000);
            boardSerialParam[i].constant[100] = HexToFloat(0xc6600000);
            boardSerialParam[i].constant[101] = HexToFloat(0xc6580000);
            boardSerialParam[i].constant[102] = HexToFloat(0xc6500000);
            boardSerialParam[i].constant[103] = HexToFloat(0xc6480000);
            boardSerialParam[i].constant[104] = HexToFloat(0xc6400000);
            boardSerialParam[i].constant[105] = HexToFloat(0xc6380000);
            boardSerialParam[i].constant[106] = HexToFloat(0xc6300000);
            boardSerialParam[i].constant[107] = HexToFloat(0xc6280000);
            boardSerialParam[i].constant[108] = HexToFloat(0xc6200000);
            boardSerialParam[i].constant[109] = HexToFloat(0xc6180000);
            boardSerialParam[i].constant[110] = HexToFloat(0xc6100000);
            boardSerialParam[i].constant[111] = HexToFloat(0xc6080000);
            boardSerialParam[i].constant[112] = HexToFloat(0xc6000000);
            boardSerialParam[i].constant[113] = HexToFloat(0xc5f00000);
            boardSerialParam[i].constant[114] = HexToFloat(0xc5e00000);
            boardSerialParam[i].constant[115] = HexToFloat(0xc5d00000);
            boardSerialParam[i].constant[116] = HexToFloat(0xc5c00000);
            boardSerialParam[i].constant[117] = HexToFloat(0xc5b00000);
            boardSerialParam[i].constant[118] = HexToFloat(0xc5a00000);
            boardSerialParam[i].constant[119] = HexToFloat(0xc5900000);
            boardSerialParam[i].constant[120] = HexToFloat(0xc5800000);
            boardSerialParam[i].constant[121] = HexToFloat(0xc5600000);
            boardSerialParam[i].constant[122] = HexToFloat(0xc5400000);
            boardSerialParam[i].constant[123] = HexToFloat(0xc5200000);
            boardSerialParam[i].constant[124] = HexToFloat(0xc5000000);
            boardSerialParam[i].constant[125] = HexToFloat(0xc4c00000);
            boardSerialParam[i].constant[126] = HexToFloat(0xc4800000);
            boardSerialParam[i].constant[127] = HexToFloat(0xc4000000);
        }

        ctrl_ret = FeatureRegInit(&wLevelCoff, &featureParam, boardSerialParam);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Init the Feature Analysis successfully\n");
        }
        else
        {
            printf("fail to init the Feature Analysis\n");
        }

        return RETURN_CUR_MENU;
    }
    case 1:
        /* FeatureAnalysisEnable */
        ctrl_ret = FeatureAnalysisEnable();

        if (NO_ERROR == ctrl_ret)
        {
            printf("Enable the Feature Analysis successfully\n");
        }
        else
        {
            printf("fail to enable the Feature Analysis\n");
        }

        return RETURN_CUR_MENU;

    case 2:
        /* FeatureAnalysisDisable */
        ctrl_ret = FeatureAnalysisDisable();

        if (NO_ERROR == ctrl_ret)
        {
            printf("Disable the Feature Analysis successfully\n");
        }
        else
        {
            printf("fail to disable the Feature Analysis\n");
        }

        return RETURN_CUR_MENU;

    case 3:
        /* SetFeatureAnalysisParameter */
        printf("please set the ch of the Feature Analysis parameter(0~1)\n");
        scanf("%d", &ch);
        // faParam = malloc(sizeof(FeatureAnalysisParameter));
        printf("please input the movingAverage_Count(int)\n");
        scanf("%d", &featureParam.movingAverage_Count);
        printf("please input the transitionJudge_LowLimitCount(int)\n");
        scanf("%d", &featureParam.transitionJudge_LowLimitCount);
        printf("please input the transitionJudge_LowLimitSigma(float)\n");
        scanf("%f", &featureParam.transitionJudge_LowLimitSigma);
        printf("please input the transitionJudge_UpperLimitCv(float)\n");
        scanf("%f", &featureParam.transitionJudge_UpperLimitCv);
        printf("please input the transitionJudge_LowLimitDuty(float)\n");
        scanf("%f", &featureParam.transitionJudge_LowLimitDuty);
        printf("please input the transitionJudge_SigmaDiffCofficient(float)\n");
        scanf("%f", &featureParam.transitionJudge_SigmaDiffCofficient);
        printf("please input the aggregationJudge_Sigma(float)\n");
        scanf("%f", &featureParam.aggregationJudge_Sigma);
        printf("please input the aggregationJudge_DiffPercentage(float)\n");
        scanf("%f", &featureParam.aggregationJudge_DiffPercentage);
        printf("please input the aggregationJudge_DiffVoltage(float)\n");
        scanf("%f", &featureParam.aggregationJudge_DiffVoltage);
        printf("please input the aggregationWeights_CvThreshold(float)\n");
        scanf("%f", &featureParam.aggregationWeights_CvThreshold);
        printf("please input the aggregationWeights_LowLimit(float)\n");
        scanf("%f", &featureParam.aggregationWeights_LowLimit);
        ctrl_ret = SetFeatureAnalysisParameter(&featureParam, ch);

        if (NO_ERROR == ctrl_ret)
        {
            printf("Set Feature Analysis Parameter successfully\n");
        }
        else
        {
            printf("fail to Set Feature Analysis Parameter\n");
        }
        // free(faParam);
        return RETURN_CUR_MENU;

    case 4:
        /* GetFeatureAnalysisParameter */
        printf("please set the ch of the Feature Analysis parameter(0~1)\n");
        scanf("%d", &ch);
        // faParam = malloc(sizeof(FeatureAnalysisParameter));
        ctrl_ret = GetFeatureAnalysisParameter(&featureParam, ch);
        if (NO_ERROR == ctrl_ret)
        {
            printf("Get Feature Analysis Parameter successfully\n");
            printf("the movingAverage_Count is %d\n", featureParam.movingAverage_Count);
            printf("the transitionJudge_LowLimitCount is %d\n", featureParam.transitionJudge_LowLimitCount);
            printf("the transitionJudge_LowLimitSigma is %f\n", featureParam.transitionJudge_LowLimitSigma);
            printf("the transitionJudge_UpperLimitCv is %f\n", featureParam.transitionJudge_UpperLimitCv);
            printf("the transitionJudge_LowLimitDuty is %f\n", featureParam.transitionJudge_LowLimitDuty);
            printf("the transitionJudge_SigmaDiffCofficient is %f\n", featureParam.transitionJudge_SigmaDiffCofficient);
            printf("the aggregationJudge_Sigma is %f\n", featureParam.aggregationJudge_Sigma);
            printf("the aggregationJudge_DiffPercentage is %f\n", featureParam.aggregationJudge_DiffPercentage);
            printf("the aggregationJudge_DiffVoltage is %f\n", featureParam.aggregationJudge_DiffVoltage);
            printf("the aggregationWeights_CvThreshold is %f\n", featureParam.aggregationWeights_CvThreshold);
            printf("the aggregationWeights_LowLimit is %f\n", featureParam.aggregationWeights_LowLimit);
        }
        else
        {
            printf("fail to Get Feature Analysis Parameter\n");
        }
        // free(faParam);
        return RETURN_CUR_MENU;

    case 5:
    {
        /* Feature Data Access */
        int dataSetNum;
        uint32_t num;
        freqData *pFreqData;
        printf("Feature Data Access\n");
        printf("please input the Max Data of set\n");
        scanf("%d", &dataSetNum);

        pFreqData = (freqData *)malloc(sizeof(freqData) * dataSetNum + 1);
        GetFeatureVal(pFreqData, (int *)&num, dataSetNum);
        free(pFreqData);
        return RETURN_MAIN_MENU;
    }

    case 6:
    {
        /* Feature Analysis Access */
        uint32_t dataSetNum;
        uint32_t num;
        freqData *pFreqData;
        printf("Feature Analysis Access\n");
        printf("please input the Max Data of set\n");
        scanf("%d", &dataSetNum);

        pFreqData = (freqData *)malloc(sizeof(freqData) * dataSetNum + 1);
        GetFeatureAnalysisVal(pFreqData, (int *)&num, dataSetNum);
        free(pFreqData);

        return RETURN_MAIN_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] SamplingModeAccess

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int SamplingModeAccess()
{
    int submenu_input = 0;
    int ctrl_ret = 0;
    int thinningNum = 0;
    int interpolationNum = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- Sampling Mode Control menu ------------------------------\n");
    printf("0:Set Down Sampling Mode\n");
    printf("1:Set Up Sampling Mode\n");
    printf("2:Get Down Sampling Mode\n");
    printf("3:Get Up Sampling Mode\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        /* SetDownSamplingMode */
        printf("please input the mode of Down Sampling(1~5000)\n");
        scanf("%d", &thinningNum);
        ctrl_ret = SetDownSamplingMode(thinningNum);

        if (NO_ERROR == ctrl_ret)
        {
            printf("set the Down Sampling Mode successfully\n");
        }
        else
        {
            printf("fail to set the Down Sampling Mode\n");
        }

        return RETURN_CUR_MENU;

    case 1:
        /* SetUpSamplingMode */
        printf("please input the mode of Up Sampling(0~10)\n");
        scanf("%d", &interpolationNum);
        ctrl_ret = SetUpSamplingMode(interpolationNum);

        if (NO_ERROR == ctrl_ret)
        {
            printf("set the Up Sampling Mode successfully\n");
        }
        else
        {
            printf("fail to set the Up Sampling Mode\n");
        }

        return RETURN_CUR_MENU;

    case 2:
        /* GetDownSamplingMode */
        ctrl_ret = GetDownSamplingMode(&thinningNum);

        if (NO_ERROR == ctrl_ret)
        {
            printf("the Down Sampling Mode is %d\n", thinningNum);
        }
        else
        {
            printf("fail to get the Down Sampling Mode\n");
        }

        return RETURN_CUR_MENU;

    case 3:
        /* GetUpSamplingMode */
        ctrl_ret = GetUpSamplingMode(&interpolationNum);

        if (NO_ERROR == ctrl_ret)
        {
            printf("the Up Sampling Mode is %d\n", interpolationNum);
        }
        else
        {
            printf("fail to get the Down Sampling Mode\n");
        }

        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] TempCompensationCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int TempCompensationCtrl()
{
    int submenu_input = 0;
    int input_ret = 0;
    int temperature = 0;
    uint32_t iRet = 0;
    char err_str[100];

    /* Control Temperature Compensation Parameter */
    printf("- Temperature Compensation Parameter Control menu ------------------------------\n");
    printf("0:Set Temperature Compensation Parameter\n");
    printf("1:Get Temperature Compensation Parameter\n");
    printf("2:Notify Temperature compensation\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        /* SetTemperatureCompensationParam */
        printf("Set Temperature Compensation Parameter\n");
        return RETURN_CUR_MENU;

    case 1:
        /* GetTemperatureCompensationParam */
        printf("Get Temperature Compensation Parameter\n");
        return RETURN_CUR_MENU;

    case 2:
    {
        printf("please input the temperature compensation parameter\n");
        scanf("%d", &temperature);
        iRet = NotifyTempCompensation(temperature);
        if (NO_ERROR == iRet)
        {
            printf("Notify Temperature compensation successfully\n");
        }
        else
        {
            printf("fail to notify temperature compensation\n");
        }

        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] SelfCalibrationCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int SelfCalibrationCtrl()
{
    /* Self Calibration Control */
    printf("Self Calibration Control\n");
    return RETURN_MAIN_MENU;
}

/*********************************************************************************
[function name] BoardSensorCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int BoardSensorCtrl()
{
    int submenu_input = 0;
    int input_ret = 0;
    int ch = 0;
    uint32_t iRet = 0;
    uint32_t iCount = 0;
    float fTemp = 0.0f;
    char err_str[100];
    struct BoardSerialParam boardParam;

    /* Control Board and Sensor Parameter */
    printf("- Board and Sensor Parameter Control menu ------------------------------\n");
    printf("0:Get Board Serial Parameter\n");
    printf("1:Set Board Serial Parameter\n");
    printf("2:Get Sensor Serial Parameter\n");
    printf("3:Set Sensor Serial Parameter\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        /* GetBoardSerialParameter */
        printf("Please input the ch of Board\n");
        scanf("%d", &ch);
        iRet = GetBoardSerialparameter(&boardParam, ch);
        if (NO_ERROR == iRet)
        {
            printf("get board serial parameter successfully\n");
            for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
            {
                printf("the coff_1stOrder[%d] is %f\n", iCount, boardParam.coff_1stOrder[iCount]);
                printf("the constant[%d] is %f\n", iCount, boardParam.constant[iCount]);
            }
        }
        else
        {
            printf("fail to get board serial parameter\n");
        }
        return RETURN_CUR_MENU;

    case 1:
        /* SetBoardSerialParameter */
        printf("Please input the coff_1stOrder of Board\n");
        scanf("%f", &fTemp);
        for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
        {
            boardParam.coff_1stOrder[iCount] = fTemp;
        }
        printf("Please input the constant of Board\n");
        scanf("%f", &fTemp);
        for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
        {
            boardParam.constant[iCount] = fTemp;
        }
        printf("Please input the ch of Board\n");
        scanf("%d", &ch);
        iRet = SetBoardSerialparameter(&boardParam, ch);
        if (NO_ERROR == iRet)
        {
            printf("set board serial parameter successfully\n");
        }
        else
        {
            printf("fail to set board serial parameter\n");
        }

        return RETURN_CUR_MENU;

    case 2:
        /* getsensorSerialParameter */
        printf("Get Sensor Serial Parameter\n");
        return RETURN_CUR_MENU;

    case 3:
        /* SetSensorSerialParameter */
        printf("Set Sensor Serial Parameter\n");
        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] RawDataCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int RawDataCtrl()
{
    int submenu_input = 0;
    int input_ret = 0;
    int milisec = 0;
    int beforesec = 0;
    char filename[1024];
    uint32_t iRet;
    uint32_t iCount = 0;
    uint32_t recipeNum = 0;
    uint32_t stepNum = 0;
    char err_str[100];

    /* Control Raw Data */
    printf("- Raw Data Control menu ------------------------------\n");
    printf("0:Get Raw Data\n");
    printf("1:Get Stable Raw Data\n");
    printf("2:Get Adc Raw Data\n");
    printf("3:Delete All Raw Data\n");
    printf("4:Free Up Storage In Raw Data\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        /* GetRawData */
        printf("Get Raw Data\n");

        printf("please input the milisec(1~1000)\n");
        scanf("%d", &milisec);
        printf("please input the beforesec(1~1000)\n");
        scanf("%d", &beforesec);

        iRet = GetRawData(milisec, beforesec, filename);
        if (NO_ERROR == iRet)
        {
            printf("Get Raw Data successfully\n");
            printf("the name of file is %s\n", filename);
        }
        else
        {
            printf("fail to get raw data\n");
        }
        return RETURN_CUR_MENU;

    case 1:
        /* getstableRawData */
        printf("please input the recipeNum(100~20000)\n");
        scanf("%d", &recipeNum);
        printf("please input the stepNum\n");
        scanf("%d", &stepNum);
        printf("Get Stable Raw Data\n");
        iRet = GetStableRawDate(recipeNum, stepNum, filename);
        if (NO_ERROR == iRet)
        {
            printf("Get Stable Raw Data successfully\n");
            printf("the name of file is %s\n", filename);
        }
        else
        {
            printf("fail to get stable raw data\n");
        }
        return RETURN_CUR_MENU;

    case 2:
        /* GetAdcRawData */
        printf("please input the count of data(1~20000)\n");
        scanf("%d", &iCount);
        iRet = GetAdcRawData(iCount, filename);
        if (NO_ERROR == iRet)
        {
            printf("Get Adc Raw Data successfully\n");
            printf("the name of file is %s\n", filename);
        }
        else
        {
            printf("fail to get Adc Raw Data\n");
        }
        return RETURN_CUR_MENU;

    case 3:
        /* DeleteAllRawData */
        printf("Delete All Raw Data\n");
        iRet = DeleteAllRawData();
        if (NO_ERROR == iRet)
        {
            printf("Delete data successfully\n");
        }
        return RETURN_CUR_MENU;

    case 4:
        /* FreeUpStorageInRawData */
        printf("Free Up Storage InRawData\n");
        iRet = FreeUpStrageInRawData();
        if (NO_ERROR == iRet)
        {
            printf("Free Up successfully\n");
        }
        return RETURN_CUR_MENU;

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] EEPROMCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int EEPROMCtrl()
{
    int submenu_input = 0;
    int input_ret = 0;
    char err_str[100];

    printf("- EEPROM Control menu ------------------------------\n");
    printf("0:Read Eeprom\n");
    printf("1:Secure Write Eeprom\n");
    printf("2:Write Eeprom\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
    {
        int count;
        int *read_data;
        int read_address;
        int read_dataSize;
        int read_ret = 0;

        printf("please input the address:\n0x");
        input_ret = scanf("%x", &read_address);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        printf("please input the dataSize:\n");
        input_ret = scanf("%d", &read_dataSize);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }

        if (0 == (read_dataSize % 4))
        {
            count = read_dataSize / 4;
            read_data = (int *)malloc(read_dataSize);
        }
        else
        {
            count = read_dataSize / 4 + 1;
            read_data = (int *)malloc(count * sizeof(int));
        }
        if (read_data == NULL)
        {
            printf("malloc error, please input again\n");
            return RETURN_CUR_MENU;
        }
        DEBUG_INFO("read_address = 0x%x\n", read_address);
        DEBUG_INFO("read_dataSize = %d\n", read_dataSize);
        read_ret = EepromRead(read_address, read_dataSize, read_data);
        if (NO_ERROR == read_ret)
        {
            for (int j = 0; j < count; j++)
            {
                printf("the result%d of the reading is 0x%x\n", j, read_data[j]);
            }
        }
        else
        {
            printf("fail to read Eeprom\n");
        }
        memset(read_data, 0, read_dataSize);
        free(read_data);

        return RETURN_CUR_MENU;
    }

    case 1:
    {
        int *write_data;
        int write_address;
        int write_dataSize;
        int count = 0;
        int write_ret = 0;
        printf("please input the address:\n0x");
        scanf("%x", &write_address);
        fflush(stdin);
        printf("please input the dataSize:\n");
        scanf("%d", &write_dataSize);
        fflush(stdin);
        if (0 == (write_dataSize % 4))
        {
            count = write_dataSize / 4;
            write_data = (int *)malloc((write_dataSize) + 1);
        }
        else
        {
            count = write_dataSize / 4 + 1;
            write_data = (int *)malloc(count * sizeof(int));
        }
        if (write_data == NULL)
        {
            printf("malloc error, please input again\n");
            return RETURN_CUR_MENU;
        }
        for (int j = 0; j < count; j++)
        {
            printf("please input the data %d:\n0x", j);
            scanf("%x", &write_data[j]);
        }
        fflush(stdin);

        printf("-------------------------------\n");

        write_ret = EepromSecureWrite(write_address, write_dataSize, write_data);

        if (NO_ERROR == write_ret)
        {
            printf("write Eeprom successfully\n");
        }
        else
        {
            printf("fail to write Eeprom\n");
        }

        free(write_data);

        return RETURN_CUR_MENU;
    }

    case 2:
    {
        int *write_data;
        int write_address;
        int write_dataSize;
        int count = 0;
        int write_ret = 0;
        printf("please input the address:\n0x");
        scanf("%x", &write_address);
        fflush(stdin);
        printf("please input the dataSize:\n");
        scanf("%d", &write_dataSize);
        fflush(stdin);
        if (0 == (write_dataSize % 4))
        {
            count = write_dataSize / 4;
            write_data = (int *)malloc(write_dataSize);
        }
        else
        {
            count = write_dataSize / 4 + 1;
            write_data = (int *)malloc(count * sizeof(int));
        }
        if (write_data == NULL)
        {
            printf("malloc error, please input again\n");
            return RETURN_CUR_MENU;
        }
        for (int j = 0; j < count; j++)
        {
            printf("please input the data %d:\n0x", j);
            scanf("%x", &write_data[j]);
        }
        fflush(stdin);

        printf("-------------------------------\n");

        write_ret = EepromWrite(write_address, write_dataSize, write_data);

        if (NO_ERROR == write_ret)
        {
            printf("write Eeprom successfully\n");
        }
        else
        {
            printf("fail to write Eeprom\n");
        }

        free(write_data);

        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] DIOCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int DIOCtrl()
{
    int ctrl_ret = 0;
    int submenu_input = 0;
    int input_ret = 0;
    int di_num = 0;
    int do_num = 0;
    char err_str[100];

    printf("- DIO Control menu ------------------------------\n");
    printf("0:Init Dio\n");
    printf("1:Dio Get Di\n");
    printf("2:Dio Set Di\n");
    printf("3:Dio Get Do\n");
    printf("4:Dio Set Do\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
        ctrl_ret = DioInit();
        if (NO_ERROR == ctrl_ret)
        {
            printf("initilize DIO successfully\n");
        }
        else
        {
            printf("fail to initilize DIO");
        }
        return RETURN_CUR_MENU;

    case 1:
    {
        unsigned char value;
        printf("please input the number of DI(0~3)\n");
        input_ret = scanf("%d", &di_num);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        ctrl_ret = DioGetDi(di_num, &value);
        if (NO_ERROR == ctrl_ret)
        {
            printf("the value of Di%d is %d\n", di_num, value);
        }
        else
        {
            printf("fail to get the value of Di\n");
        }
        return RETURN_CUR_MENU;
    }

    case 2:
    {
        unsigned char value;
        printf("please input the number of DI(0~3)\n");
        input_ret = scanf("%d", &di_num);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        printf("please input the value of DI(0: OutPut Off  1: OutPut ON)\n");
        input_ret = scanf("%hhd", &value);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        ctrl_ret = DioSetDi(di_num, value);
        if (NO_ERROR == ctrl_ret)
        {
            printf("set the value of Di successfully\n");
        }
        else
        {
            printf("fail to set the value of Di\n");
        }
        return RETURN_CUR_MENU;
    }

    case 3:
    {
        unsigned char value;
        printf("please input the number of DO(0~3)\n");
        input_ret = scanf("%d", &do_num);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        ctrl_ret = DioGetDo(do_num, &value);
        if (NO_ERROR == ctrl_ret)
        {
            printf("the value of Do%d is %d\n", do_num, value);
        }
        else
        {
            printf("fail to get the value of Do\n");
        }
        return RETURN_CUR_MENU;
    }
    case 4:
    {
        unsigned char value;
        printf("please input the number of DO(0~3)\n");
        input_ret = scanf("%d", &do_num);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        printf("please input the value of DO(0: OutPut Off  1: OutPut ON)\n");
        input_ret = scanf("%hhd", &value);
        fflush(stdin);
        if (input_ret != 1)
        {
            fgets(err_str, 100, stdin);
            return RETURN_CUR_MENU;
        }
        ctrl_ret = DioSetDo(do_num, value);
        if (NO_ERROR == ctrl_ret)
        {
            printf("set the value of Do successfully\n");
        }
        else
        {
            printf("fail to set the value of Do\n");
        }
        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] FileCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int FileCtrl()
{
    int ctrl_ret = 0;
    int submenu_input = 0;
    int input_ret = 0;
    int inum = 1;
    int que_count = 0;
    int iError = 0;
    uint8_t *que_ptr;
    char err_str[100];

    printf("- File Control menu ------------------------------\n");
    printf("0:Init File_api\n");
    printf("1:Write the File\n");
    printf("2:Lseek the File\n");
    printf("3:Close the Line\n");
    printf("4:Get Quests\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    fflush(stdin);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        return RETURN_CUR_MENU;
    }
    switch (submenu_input)
    {
    case 0:
    {
        char path[MAX_PATH];

        // printf("please input the num of files\n");
        // scanf("%d", &inum);
        printf("please input the path of the file\n");
        scanf("%s", path);
        fflush(stdin);
        printf("please input the count of que\n");
        scanf("%d", &que_count);
        fflush(stdin);
        ctrl_ret = t_file_api_init(inum);
        if (NO_ERROR == ctrl_ret)
        {
            printf("the line is initilized successfully\n");
        }
        else
        {
            printf("fail to initilize the line\n");
        }
        que_ptr = (uint8_t *)malloc(que_count * QUE_WRITE_1024);
        File = t_open(path, O_RDWR | O_APPEND | O_CREAT, QUE_WRITE_1024, que_count, que_ptr, &iError);
        if (NULL == File)
        {
            printf("error opening\n");
            return RETURN_CUR_MENU;
        }

        return RETURN_CUR_MENU;
    }

    case 1:
    {
        char str[MAX_STRING];
        int iRam;
#if 0
        printf("please input the contents of the file\n");
        getchar();
        scanf("%[^\n]", str);
        fflush(stdin);
#else
        for (int i = 0; i < 1024; i++)
        {
            srand((unsigned)time(NULL));
            iRam = rand() & 1;
            if (0 == iRam)
            {
                str[i] = 'A' + rand() % 26;
            }
            else
            {
                str[i] = 'a' + rand() % 26;
            }
            // str[i] = i;
        }
#endif

        printf("size of string is %ld\n", strlen(str));
        t_write(File, str, 1024, &iError);
        // t_write(File, str, strlen(str), &iError);
        // Delay_Ms(2000);
        if (NO_ERROR == iError)
        {
            printf("write successfully\n");
        }
        else
        {
            printf("fail to write\n");
        }
        return RETURN_CUR_MENU;
    }

    case 2:
    {
        int offset;
        int whence = SEEK_SET;

        // printf("please input the whence of the file:\n0:SEEK_SET\n1:SEEK_CUR\n2:SEEK_END\n");
        // scanf("%d", &whence);
        // fflush(stdin);
        // if ((SEEK_SET != whence) && (SEEK_CUR != whence) && (SEEK_END != whence))
        // {
        //     printf("error input\n");
        //     return RETURN_CUR_MENU;
        // }
        printf("please input the offset:\n");
        scanf("%d", &offset);
        fflush(stdin);
        t_lseek(File, offset, whence, &iError);
        if (NO_ERROR == iError)
        {
            printf("lseek successfully\n");
        }
        else
        {
            printf("fail to lseek\n");
        }
        return RETURN_CUR_MENU;
    }

    case 3:
    {
        ctrl_ret = t_close(File, 1);
        if (NO_ERROR == ctrl_ret)
        {
            printf("close successfully\n");
        }
        else
        {
            printf("fail to close\n");
        }
        // t_file_api_exit();
        // Delay_Ms(2000);
        return RETURN_CUR_MENU;
    }

    case 4:
    {
        int current = 0;
        int max = 0;
        ctrl_ret = t_quests_get(File, &current, &max);
        if (NO_ERROR == ctrl_ret)
        {
            printf("current : %d\n", current);
            printf("max : %d\n", max);
            printf("get quests successfully\n");
        }
        else
        {
            printf("fail to get quests\n");
        }
        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

/*********************************************************************************
[function name] RowColumnCalculus

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/

int RowColumnCalculus()
{
    // int count = 0;
    int ctrl_ret = 0;
    int input_ret = 0;
    int submenu_input = 0;
    // int iValue = 0;
    float matrix1[MATRIX_SIZE];
    float matrix2[MATRIX_SIZE];
    float calc_result[MATRIX_SIZE];
    // float set_result[MATRIX_SIZE];
    char err_str[100];
    // unsigned long long reg_VirthBaseAddr_Mat;
    // unsigned long long reg_VirthBaseAddr_Mat2;
    // unsigned long long reg_VirthBaseAddr_Mat3;

    printf("- Row Column Calculus menu ------------------------------\n");
    printf("0:Solve Dmatrix Multiplication 22_21\n");
    printf("1:Solve Dmatrix Multiplication 33_31\n");
    printf("2:Solve Sqrt\n");
    printf("3:Solve Dmatrix Multiplication 22_22\n");
    printf("4:Solve Dmatrix Multiplication 33_33\n");
    printf("\n");
    printf("99:Exit\n");
    input_ret = scanf("%d", &submenu_input);
    if (input_ret != 1)
    {
        fgets(err_str, 100, stdin);
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
    fflush(stdin);

    switch (submenu_input)
    {
    case 0:
    {
        printf("please input the value of mat1_22[1][1]:\n");
        scanf("%f", &matrix1[0]);
        printf("please input the value of mat1_22[1][2]:\n");
        scanf("%f", &matrix1[1]);
        printf("please input the value of mat1_22[2][1]:\n");
        scanf("%f", &matrix1[2]);
        printf("please input the value of mat1_22[2][2]:\n");
        scanf("%f", &matrix1[3]);
        printf("please input the value of mat2_21[1][1]:\n");
        scanf("%f", &matrix2[0]);
        printf("please input the value of mat2_21[2][1]:\n");
        scanf("%f", &matrix2[2]);
        matrix2[1] = 0.0;
        matrix2[3] = 0.0;
        ctrl_ret = SolveDmatrixMultiplication22_21(matrix1, matrix2, calc_result);
        if (NO_ERROR == ctrl_ret)
        {
            printf("calculate successfully\n");
            printf("the result is:\n");
            printf("%f  %f\n", calc_result[0], calc_result[1]);
            printf("%f  %f\n", calc_result[2], calc_result[3]);
            printf("\n");
        }
        else
        {
            printf("calculate error\n");
        }

        return RETURN_CUR_MENU;
    }

    case 1:
    {
        // memset(&matrix2, 0, sizeof(matrix2));
        printf("please input the value of mat1_33[1][1]:\n");
        scanf("%f", &matrix1[0]);
        printf("please input the value of mat1_33[1][2]:\n");
        scanf("%f", &matrix1[1]);
        printf("please input the value of mat1_33[1][3]:\n");
        scanf("%f", &matrix1[2]);
        printf("please input the value of mat1_33[2][1]:\n");
        scanf("%f", &matrix1[3]);
        printf("please input the value of mat1_33[2][2]:\n");
        scanf("%f", &matrix1[4]);
        printf("please input the value of mat1_33[2][3]:\n");
        scanf("%f", &matrix1[5]);
        printf("please input the value of mat1_33[3][1]:\n");
        scanf("%f", &matrix1[6]);
        printf("please input the value of mat1_33[3][2]:\n");
        scanf("%f", &matrix1[7]);
        printf("please input the value of mat1_33[3][3]:\n");
        scanf("%f", &matrix1[8]);
        printf("please input the value of mat2_31[1][1]:\n");
        scanf("%f", &matrix2[0]);
        printf("please input the value of mat2_31[2][1]:\n");
        scanf("%f", &matrix2[3]);
        printf("please input the value of mat2_31[3][1]:\n");
        scanf("%f", &matrix2[6]);
        matrix2[1] = 0.0;
        matrix2[2] = 0.0;
        matrix2[4] = 0.0;
        matrix2[5] = 0.0;
        matrix2[7] = 0.0;
        matrix2[8] = 0.0;
        ctrl_ret = SolveDmatrixMultiplication33_31(matrix1, matrix2, calc_result);
        if (NO_ERROR == ctrl_ret)
        {
            printf("calculate successfully\n");
            printf("the result is:\n");
            printf("%f  %f %f\n", calc_result[0], calc_result[1], calc_result[2]);
            printf("%f  %f %f\n", calc_result[3], calc_result[4], calc_result[5]);
            printf("%f  %f %f\n", calc_result[6], calc_result[7], calc_result[8]);
            printf("\n");
        }
        else
        {
            printf("calculate error\n");
        }

        return RETURN_CUR_MENU;
    }

    case 2:
    {
        /* Solve Sqrt */
        printf("Solve Sqrt\n");
        float din;
        float sqrt_result;

        printf("please input the data\n");
        scanf("%f", &din);
        ctrl_ret = SolveSqrt(din, &sqrt_result);
        if (NO_ERROR == ctrl_ret)
        {
            printf("the result of sqrt is %f\n", sqrt_result);
        }
        else
        {
            printf("sqrt error\n");
        }

        return RETURN_CUR_MENU;
    }

    case 3:
    {
        printf("please input the value of mat1_22[1][1]:\n");
        scanf("%f", &matrix1[0]);
        printf("please input the value of mat1_22[1][2]:\n");
        scanf("%f", &matrix1[1]);
        printf("please input the value of mat1_22[2][1]:\n");
        scanf("%f", &matrix1[2]);
        printf("please input the value of mat1_22[2][2]:\n");
        scanf("%f", &matrix1[3]);
        printf("please input the value of mat2_21[1][1]:\n");
        scanf("%f", &matrix2[0]);
        printf("please input the value of mat2_21[1][2]:\n");
        scanf("%f", &matrix2[1]);
        printf("please input the value of mat2_21[2][1]:\n");
        scanf("%f", &matrix2[2]);
        printf("please input the value of mat2_21[2][2]:\n");
        scanf("%f", &matrix2[3]);

        ctrl_ret = SolveDmatrixMultiplication22_22(matrix1, matrix2, calc_result);
        if (NO_ERROR == ctrl_ret)
        {
            printf("calculate successfully\n");
            printf("the result is:\n");
            printf("%f  %f\n", calc_result[0], calc_result[1]);
            printf("%f  %f\n", calc_result[2], calc_result[3]);
            printf("\n");
        }
        else
        {
            printf("calculate error\n");
        }

        return RETURN_CUR_MENU;
    }

    case 4:
    {
        printf("please input the value of mat1_33[1][1]:\n");
        scanf("%f", &matrix1[0]);
        printf("please input the value of mat1_33[1][2]:\n");
        scanf("%f", &matrix1[1]);
        printf("please input the value of mat1_33[1][3]:\n");
        scanf("%f", &matrix1[2]);
        printf("please input the value of mat1_33[2][1]:\n");
        scanf("%f", &matrix1[3]);
        printf("please input the value of mat1_33[2][2]:\n");
        scanf("%f", &matrix1[4]);
        printf("please input the value of mat1_33[2][3]:\n");
        scanf("%f", &matrix1[5]);
        printf("please input the value of mat1_33[3][1]:\n");
        scanf("%f", &matrix1[6]);
        printf("please input the value of mat1_33[3][2]:\n");
        scanf("%f", &matrix1[7]);
        printf("please input the value of mat1_33[3][3]:\n");
        scanf("%f", &matrix1[8]);
        printf("please input the value of mat2_31[1][1]:\n");
        scanf("%f", &matrix2[0]);
        printf("please input the value of mat2_31[1][2]:\n");
        scanf("%f", &matrix2[1]);
        printf("please input the value of mat2_31[1][3]:\n");
        scanf("%f", &matrix2[2]);
        printf("please input the value of mat2_31[2][1]:\n");
        scanf("%f", &matrix2[3]);
        printf("please input the value of mat2_31[2][2]:\n");
        scanf("%f", &matrix2[4]);
        printf("please input the value of mat2_31[2][3]:\n");
        scanf("%f", &matrix2[5]);
        printf("please input the value of mat2_31[3][1]:\n");
        scanf("%f", &matrix2[6]);
        printf("please input the value of mat2_31[3][2]:\n");
        scanf("%f", &matrix2[7]);
        printf("please input the value of mat2_31[3][3]:\n");
        scanf("%f", &matrix2[8]);

        ctrl_ret = SolveDmatrixMultiplication33_33(matrix1, matrix2, calc_result);
        if (NO_ERROR == ctrl_ret)
        {
            printf("calculate successfully\n");
            printf("the result is:\n");
            printf("%f  %f %f\n", calc_result[0], calc_result[1], calc_result[2]);
            printf("%f  %f %f\n", calc_result[3], calc_result[4], calc_result[5]);
            printf("%f  %f %f\n", calc_result[6], calc_result[7], calc_result[8]);
            printf("\n");
        }
        else
        {
            printf("calculate error\n");
        }

        return RETURN_CUR_MENU;
    }

    case 99:
        return RETURN_MAIN_MENU; /* return to the superior menu */

    default:
        printf("input error, please input again\n");
        return RETURN_CUR_MENU;
    }
}

int MultCorTest()
{
    uint8_t line[3096];
    uint8_t mode = 0;
    uint8_t cBuf[256];
    char fileName[1024] = "Read_Data.csv";
    char *cName;
    float fTemp;
    FILE *tempFp = NULL;
    FILE *stream = NULL;
    uint32_t iCount = 1;
    uint32_t count = 0;
    uint32_t iTurn = 0;
    uint32_t iValue;
    struct BoardSerialParam *boardSerialParam;
    WaferLevelCalcCoefficient wLevelCoff = {0};
    unsigned long long reg_VirthBaseAddr;

    printf("please input the mode :\n");
    scanf("%hhd", &mode);
    printf("please input the num of data :\n");
    scanf("%d", &count);

    if ((0 == mode) || (1 == mode) || (2 == mode))
    {
        stream = fopen("DulCor.csv", "r");
        boardSerialParam = (struct BoardSerialParam *)malloc(sizeof(struct BoardSerialParam) * 3);
        if (NULL == stream)
        {
            printf("error open\n");
            return RETURN_MAIN_MENU;
        }

        while (fgets((char *)line, 1024, stream))
        {
            uint8_t *tok;
            // uint8_t *tmp = strdup(line);

            for (tok = (uint8_t *)strtok((char *)line, ","); tok && *tok; iCount++, tok = (uint8_t *)strtok(NULL, ",\n"))
            {
                fTemp = atof((const char *)tok);

                if (iCount > 9)
                {
                    if ((iCount % 9) == 8)
                    {
                        boardSerialParam[0].constant[iTurn] = fTemp;
                        boardSerialParam[1].constant[iTurn] = fTemp;
                        boardSerialParam[2].constant[iTurn] = fTemp;
                        // DEBUG_INFO("iCount = %d\n", iCount);
                        DEBUG_INFO("boardSerialParam[0].constant[%d] = %g", iTurn, boardSerialParam[0].constant[iTurn]);
                    }
                    if ((iCount % 9) == 0)
                    {
                        boardSerialParam[0].coff_1stOrder[iTurn] = fTemp;
                        boardSerialParam[1].coff_1stOrder[iTurn] = fTemp;
                        boardSerialParam[2].coff_1stOrder[iTurn] = fTemp;
                        // DEBUG_INFO("iCount = %d\n", iCount);
                        DEBUG_INFO("boardSerialParam[0].coff_1stOrder[%d] = %g", iTurn, boardSerialParam[0].coff_1stOrder[iTurn]);
                        iTurn++;
                    }
                }
            }
            // free(tmp);
        }

        fclose(stream);

        SetBoardSerialparameter(boardSerialParam, 0);
        SetBoardSerialparameter(boardSerialParam, 1);
        free(boardSerialParam);
        cName = "ADC Raw Data1,Iinear Interpolation1,Upsampling1,ADC Raw Data2,Interpolation2,Upsampling2";
    }
    else if (3 == mode)
    {
        // wLevelCoff = (WaferLevelCalcCoefficient *)malloc(sizeof(WaferLevelCalcCoefficient));
        wLevelCoff.matrix_1raw = HexToFloat(0x431fd75f);
        wLevelCoff.matrix_1clm = HexToFloat(0xc1c62594);
        wLevelCoff.matrix_2raw = HexToFloat(0x41fae752);
        wLevelCoff.matrix_2clm = HexToFloat(0x42d2ecd9);
        wLevelCoff.matrix_3raw = HexToFloat(0x3d15dfba);
        wLevelCoff.matrix_3clm = HexToFloat(0x3e71c0ae);
        wLevelCoff.matrix_4raw = HexToFloat(0x41c59887);
        wLevelCoff.matrix_4clm = HexToFloat(0xc0e42a6b);
        SetWlevelCalcCoeff(&wLevelCoff, 0);
        SetWlevelCalcCoeff(&wLevelCoff, 1);

        cName = "V13,I13,P13,Vr13,Vi13,Ir13";
    }
    else if (4 == mode)
    {
        // wLevelCoff = (WaferLevelCalcCoefficient *)malloc(sizeof(WaferLevelCalcCoefficient));
        wLevelCoff.matrix_1raw = HexToFloat(0x431fd75f);
        wLevelCoff.matrix_1clm = HexToFloat(0xc1c62594);
        wLevelCoff.matrix_2raw = HexToFloat(0x41fae752);
        wLevelCoff.matrix_2clm = HexToFloat(0x42d2ecd9);
        wLevelCoff.matrix_3raw = HexToFloat(0x3d15dfba);
        wLevelCoff.matrix_3clm = HexToFloat(0x3e71c0ae);
        wLevelCoff.matrix_4raw = HexToFloat(0x41c59887);
        wLevelCoff.matrix_4clm = HexToFloat(0xc0e42a6b);
        SetWlevelCalcCoeff(&wLevelCoff, 0);
        SetWlevelCalcCoeff(&wLevelCoff, 1);

        cName = "V0.4,I0.4,P0.4,Vr0.4,Vi0.4,Ir0.4";
    }
    else
    {
        printf("the mode is out of range\n");
        return RETURN_MAIN_MENU; /* return to the superior menu */
    }

    AutoInitReg(mode);

    DEBUG_INFO("open the file");
    tempFp = fopen(fileName, "wb+");
    if (tempFp == NULL)
    {
        printf("fopen error\n");
        return RETURN_MAIN_MENU;
    }
    fclose(tempFp);
    putString2Csv(cName, fileName, ECWM_ONELINE);
    putString2Csv("", fileName, ECWM_OTHERLINE);

    mem_mmap(DATA_START_ADDR, MAX_AD_OFFSET, &reg_VirthBaseAddr);

    DEBUG_INFO("-DDR Read-----------------");
    for (iCount = 0; iCount < (count * 6); iCount++)
    {
        if (0 == (iCount % 6))
        {
            DEBUG_INFO("-Data %d--------------", (iCount / 6));
        }
        GetRegister(reg_VirthBaseAddr, iCount * 4, (int *)&iValue);
        sprintf((char *)cBuf, "%d", iValue);
        putString2Csv((char *)cBuf, fileName, ECWM_ONELINE);
        DEBUG_INFO("the val of 0x%08x is 0x%08x", (DATA_START_ADDR + (iCount * 4)), iValue);

        if (0 == ((iCount + 1) % 6))
        {
            putString2Csv("", fileName, ECWM_OTHERLINE);
        }
    }
    mem_unmap(reg_VirthBaseAddr, MAX_AD_OFFSET);

    return RETURN_MAIN_MENU;
}

/*********************************************************************************
[function name] main

[arguments]
 NULL


[return value]
Normal	:	EXIT_MAIN_MENU

*********************************************************************************/
int main()
{
    int input = 0;
    int ret = 0;
    char err_str[100];
    system("pgrep -f \"/usr/sbin/inetd\" | while read PID;do echo -1000 > /proc/$PID/oom_score_adj;done");
    temp_data_save_flag = TRUE;
    StoreData(temp_data_save_flag);
    // timeout = (struct timeval *)malloc(sizeof(struct timeval));

    while (EXIT_MAIN_MENU != ret)
    {
        printf("@@@@@@@@@@@@@@@@@@@@@ Test Program @@@@@@@@@@@@@@@@@@@@@\n");
        printf("@@@@@@@@@@@@@@@@@@@@@  Ver 0.1     @@@@@@@@@@@@@@@@@@@@@\n");
        printf("@@@@@@@@@@@@  Compilation time %s  @@@@@@@@@@@@\n", __DATE__);
        printf("- Test menu ------------------------------\n");
        printf("%d:Control Led%15d:Get API Version%15d:Get DipSW State%12d:Get CPU Temperature\n", 1, 2, 3, 4);
        printf("%d:Control WDT%15d:Get Board Temperature%9d:Get FAN State\n", 5, 6, 7);
        printf("%d:Set Kernel Date%11d:Control EtherCAT%15d:Control DeviceNet\n", 8, 9, 10);
        printf("%d:Control Rf Freq Mode%6d:Control Feature Analysis%6d:Control Max Data Set Mode\n", 11, 12, 13);
        printf("%d:Control Sampling Mode%5d:Control W Level Calc Coeff%4d:Self Calibration\n", 14, 15, 16);
        printf("%d:Control Temperature Compensation Parameter%15d:Control Board and Sensor Parameter\n", 17, 18);
        printf("%d:Control Raw Data%10d:Control EEPROM%16d:Control DIO\n", 19, 20, 21);
        printf("%d:Control File%14d:Row Column Calculus%11d:Multipoint Correction Test\n", 22, 23, 24);
        printf("%d:Time Statistic\n", 25);
        printf("\n");
        printf("99:Exit\n");
        ret = scanf("%d", &input);
        fflush(stdin);
        if (ret != 1)
        {
            fgets(err_str, 100, stdin);
            printf("input error, please input again\n");
            continue;
        }
        switch (input)
        {
        case LEDTEST:
            do
            {
                ret = LedCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case VERSIONTEST:
            do
            {
                ret = VersionAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case DIPSWTEST:
            do
            {
                ret = DipSWAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case CPUTEMPTEST:
            do
            {
                ret = CpuTempAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case WDTTEST:
            do
            {
                ret = WDTCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case BOARDTEMPTEST:
            do
            {
                ret = BoardTempAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case FANTEST:
            do
            {
                ret = FanAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case TIMETEST:
            do
            {
                ret = TimeAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case ETHERCATTEST:
            do
            {
                ret = EtherCATCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case DEVICENETTEST:
            do
            {
                ret = DeviceNetCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

            // case SDOTEST:
            //     do
            //     {
            //         ret = SdoCtrl();
            //     } while (RETURN_MAIN_MENU != ret);
            //     break;

        case RFFREQMODETEST:
            do
            {
                ret = RfFreqModeAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case FEATURERUNTEST:
            do
            {
                ret = FeatureAnalysisCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;
        case MAXDATASETMODETEST:
            do
            {
                ret = MaxDataModeCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case SAMPLINGMODETEST:
            do
            {
                ret = SamplingModeAccess();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case WLEVELCALC:
            do
            {
                ret = WLevelCalcCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case SELFCALIBRATIONTEST:
            do
            {
                ret = SelfCalibrationCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case TEMPCOMPENSATIONTEST:
            do
            {
                ret = TempCompensationCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case BOARDSENSORTEST:
            do
            {
                ret = BoardSensorCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case RAWDATATEST:
            do
            {
                ret = RawDataCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case EEPROMTEST:
            do
            {
                ret = EEPROMCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case DIOTEST:
            do
            {
                ret = DIOCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case FILETEST:
            do
            {
                ret = FileCtrl();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case ROWCOLUMNTEST:
            do
            {
                ret = RowColumnCalculus();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case MULTCORTEST:
            do
            {
                ret = MultCorTest();
            } while (RETURN_MAIN_MENU != ret);
            break;

        case TIMESTATISTICTEST:
        {
            TimeStatistc();
            break;
        }

        case EXITMENU:
            ret = EXIT_MAIN_MENU;
            temp_data_save_flag = FALSE;
            StoreData(temp_data_save_flag);
            // free(timeout);
            break;

        default:
            printf("input error, please input again\n");
            break;
        }
    }
    return 0;
}
