/*******************************************************************************
**	File name		: test.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include <libaio.h>
#include "eeprom_api.h"
#include "Communication_api.h"
#include "Err32_def_api.h"
#include "common.h"
/*------------------------------------------------------------------------------
                               static define
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
                               function define
------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] DeviceNetCtrl

[arguments]
 NULL


[return value]
Normal	:	RETURN_CUR_MENU

*********************************************************************************/
int main(int argc , char* argv[])
{
    printf("@@@@@@@@@@@@  Compilation time %s  @@@@@@@@@@@@\n", __DATE__);
    // timeout = (struct timeval *)malloc(sizeof(struct timeval));
    // timeout = &timeout_local;
    // timeout.tv_sec = 0;
    struct timeval timeout;
    DEBUG_INFO("argc = %d\n", argc);
    if(argc != 3) 
    {
        printf("the parameter is invalid\n");
        return PARAM_ERROR;
    }
    timeout.tv_sec = atoi(argv[1]);
    timeout.tv_usec = atoi(argv[2]);
    DNetInit();
    DEBUG_INFO("tv_sec is %ld\n", timeout.tv_sec);
    DEBUG_INFO("tv_usec is %ld\n", timeout.tv_usec);
    if((0 == timeout.tv_sec) || (0 == timeout.tv_usec))
    {
        printf("the parameter is invalid\n");
        return PARAM_ERROR;
    }
    // DNetInit();
    DNetCommuThread(&timeout);

    while(1)
    {

    }
    return NO_ERROR;
}

