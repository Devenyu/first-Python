/*******************************************************************************
**	File name		: Parameter_api.c                                         **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2022/03/21 Devenyu] New regulations have been made                        **
*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "mem_map.h"
#include "common.h"
#include "Err32_def_api.h"
#include "Parameter_api.h"

/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] GetBoardSerialparameter

[arguments]
boardParam			:	First address of the structure containing the frequency data
ch			        :	the valid num of structure

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetBoardSerialparameter(struct BoardSerialParam *boardParam, int ch)
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    uint32_t iCount = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    /* judge the parameters */
    if (NULL == boardParam)
    {
        printf("the boardParam is NULL\n");
    }
    if ((1 != ch) && (0 != ch))
    {
        printf("the ch is out of range\n");
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }
    for (vip = 1; vip <= 3; vip++)
    {
        for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
        {
            boardParam[vip - 1].coff_1stOrder[iCount] = *(float *)(reg_VirthBaseAddr + COFF_1STORDER_OFFSET + (vip * 0x1000) + (ch * 0x4000) + (iCount * 8));
            boardParam[vip - 1].constant[iCount] = *(float *)(reg_VirthBaseAddr + CONSTANTS_OFFSET + (vip * 0x1000) + (ch * 0x4000) + (iCount * 8));
        }
        for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
        {
            DEBUG_INFO("boardParam->coff_1stOrder[%d] = %f", iCount, boardParam[vip - 1].coff_1stOrder[iCount]);
            DEBUG_INFO("boardParam->constant[%d] = %f", iCount, boardParam[vip - 1].constant[iCount]);
        }
    }

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetBoardSerialparameter

[arguments]
boardParam			:	First address of the structure containing the frequency data
ch			        :	the valid num of structure

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetBoardSerialparameter(const struct BoardSerialParam *boardParam, int ch)
{
    uint32_t iRet = 0;
    // uint32_t iValue = 0;
    uint32_t iCount = 0;
    uint32_t vip = 1; // V=1, I=2, P=3
    unsigned long long reg_VirthBaseAddr;

    /* judge the parameters */
    if (NULL == boardParam)
    {
        printf("the boardParam is NULL\n");
    }
    if ((1 != ch) && (0 != ch))
    {
        printf("the ch is out of range\n");
    }

    /* map the mode register address */
    iRet = mem_mmap(BASE_ADDRESS, MODE_REG_SIZE, &reg_VirthBaseAddr);
    if (NO_ERROR != iRet)
    {
        return GENERAL_ERROR;
    }

    for (vip = 1; vip <= 3; vip++)
    {
        for (iCount = 0; iCount < MAX_PARAM_SIZE; iCount++)
        {
            *(float *)(reg_VirthBaseAddr + COFF_1STORDER_OFFSET + (vip * 0x1000) + (ch * 0x4000) + (iCount * 8)) = boardParam[vip - 1].coff_1stOrder[iCount];
            *(float *)(reg_VirthBaseAddr + CONSTANTS_OFFSET + (vip * 0x1000) + (ch * 0x4000) + (iCount * 8)) = boardParam[vip - 1].constant[iCount];
            DEBUG_INFO("0x80001040 = %g", *(float *)(reg_VirthBaseAddr + 0x1040 ));
        }
    }
    DEBUG_INFO("boardParam->coff_1stOrder[8] = %g\n", boardParam->coff_1stOrder[8]);

    mem_unmap(reg_VirthBaseAddr, MODE_REG_SIZE);
    return NO_ERROR;
}

/*********************************************************************************
[function name] GetBoardSerialparameter

[arguments]
sensorParam			:	First address of the structure containing the frequency data
ch			        :	the valid num of structure

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetSensorSerialparameter(struct SensorSerialParam *sensorParam, int ch)
{
    return NO_ERROR;
}

/*********************************************************************************
[function name] SetSensorSerialparameter

[arguments]
sensorParam     	:	First address of the structure containing the frequency data
ch			        :	the valid num of structure

[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetSensorSerialparameter(const struct SensorSerialParam *sensorParam, int ch)
{
    return NO_ERROR;
}
