/*******************************************************************************
**	File name		: eeprom_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
								header file
------------------------------------------------------------------------------*/
#include "eeprom_api.h"
#include "axi_i2c.h"
#include "Err32_def_api.h"
#include "common.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

/*--------------------------------------------------------------------------------
							   function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] EepromRead

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	read data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int EepromRead(int Address, int DataSize, int *val)
{
	int32_t ret;
	uint32_t size;
	uint32_t times;
	uint8_t *data;
	uint8_t address[2] = {0};

	/* Judge the parameters */
	if (NULL == val)
	{
		printf("the val is NULL\n");
		return PARAM_ERROR;
	}
	if (MAX_DATASIZE < DataSize)
	{
		printf("the data size is too large\n");
		return PARAM_ERROR;
	}

	DEBUG_INFO("the address is 0x%x\n", Address);
	DEBUG_INFO("the datasize is 0x%d\n", DataSize)
	/* calculate the size of int */
	if ((DataSize % 4) == 0)
	{
		size = DataSize / 4;
	}
	else
	{
		size = (DataSize / 4) + 1;
	}
	data = (unsigned char *)malloc(DataSize + 1);
	if (data == NULL)
	{
		printf("malloc error\n");
		return MALLOC_ERROR;
	}

	address[0] = (Address >> 8) & 0xFF;
	address[1] = Address & 0xFF;

	ret = XIic_Send(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_ADDR, (u8 *)address, 2, XIIC_STOP);
	if (ret == 0)
	{
		printf("Send iic data failed!\n");
		free(data);
		return EEPROM_READ_ERROR;
	}

	// usleep(1500);
	ret = XIic_Recv(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_READ_ADDR, data, DataSize, XIIC_STOP);

	if (ret < DataSize)
	{
		printf("Receive iic data failed!\n");
		free(data);
		return EEPROM_READ_ERROR;
	}
	for (int i = 0; i < DataSize; i++)
	{
		DEBUG_INFO("data[%d] = 0x%x\n", i, data[i]);
	}
	for (times = 0; times < size; times++)
	{
		val[times] = (data[times * 4] | data[times * 4 + 1] << 8 | data[times * 4 + 2] << 16 | data[times * 4 + 3] << 24);
	}

	memset(data, 0, DataSize + 1);
	free(data);
	return NO_ERROR;
}

/*********************************************************************************
[function name] EepromSecureWrite

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	write data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int EepromSecureWrite(int Address, int DataSize, int *val)
{
	int32_t ret;
	uint32_t size;
	// uint32_t times;
	unsigned char *data = NULL;

	/* Judge the parameters */
	if (NULL == val)
	{
		printf("the val is NULL\n");
		return PARAM_ERROR;
	}
	if (MAX_DATASIZE < DataSize)
	{
		printf("the data size is too large\n");
		return PARAM_ERROR;
	}

	/* calculate the size of int */
	if ((DataSize % 4) == 0)
	{
		size = DataSize / 4;
	}
	else
	{
		size = (DataSize / 4) + 1;
	}
	
	data = (unsigned char *)malloc((size * 4) + 3);
	if (NULL == data)
	{
		return MALLOC_ERROR;
	}

	/* set the address of write */
	data[0] = (Address >> 8) & 0xFF;
	data[1] = Address & 0xFF;

	/* transform the uint16_t to uint8_t */
	for (int i = 0; i < size; i++)
	{
		data[i * 4 + 2] = val[i] & 0xFF;
		data[i * 4 + 3] = (val[i] >> 8) & 0xFF;
		data[i * 4 + 4] = 0x00;
		data[i * 4 + 5] = 0x00;
	}

	ret = XIic_Send(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_ADDR, data, DataSize + 2, XIIC_STOP);
	// usleep(1500);
	if (ret < DataSize)
	{
		printf("EEPROM Write error\n");
		free(data);
		return EEPROM_WRITE_ERROR;
	}

	free(data);
	return NO_ERROR;
}

/*********************************************************************************
[function name] EepromWrite

[arguments]
Address			    :	the register address
DataSize			:	the length of the data
val			    	:	write data


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int EepromWrite(int Address, int DataSize, int *val)
{
	int iTemp = 0;
	int iCount = 0;
	int iAddress = Address;
	int32_t ret;
	uint32_t size;
	// uint32_t times;
	unsigned char *data;

	/* Judge the parameters */
	if (NULL == val)
	{
		printf("the val is NULL\n");
		return PARAM_ERROR;
	}
	if (MAX_DATASIZE < DataSize)
	{
		printf("the data size is too large\n");
		return PARAM_ERROR;
	}

	/* calculate the size of int */
	if ((DataSize % 4) == 0)
	{
		size = DataSize / 4;
	}
	else
	{
		size = (DataSize / 4) + 1;
	}

	if (DataSize <= 32)
	{
		// DEBUG_INFO("malloc the data");
		data = (unsigned char *)malloc((size * 4) + 3);
		if (data == NULL)
		{
			printf("malloc error\n");
			return MALLOC_ERROR;
		}

		/* set the address of write */
		data[0] = (Address >> 8) & 0xFF;
		data[1] = Address & 0xFF;

		/* transform the uint16_t to uint8_t */
		for (int i = 0; i < size; i++)
		{
			data[i * 4 + 2] = val[i] & 0xFF;
			data[i * 4 + 3] = (val[i] >> 8) & 0xFF;
			data[i * 4 + 4] = (val[i] >> 16) & 0xFF;
			data[i * 4 + 5] = (val[i] >> 24) & 0xFF;
		}

		// DEBUG_INFO("send the data");
		ret = XIic_Send(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_ADDR, data, DataSize + 2, XIIC_STOP);
		// usleep(1500);
		if (ret < DataSize)
		{
			printf("EEPROM Write error\n");
			free(data);
			return EEPROM_WRITE_ERROR;
		}
		// DEBUG_INFO("write eeprom successfully");
		free(data);
	}
	else
	{
		data = (unsigned char *)malloc(35);
		if (data == NULL)
		{
			printf("malloc error\n");
			return MALLOC_ERROR;
		}

		/* judge how many page */
		if ((DataSize % 32) == 0)
		{
			iCount = DataSize / 32;
		}
		else
		{
			iCount = (DataSize / 32) + 1;
		}

		for (iTemp = 0; iTemp < iCount - 1; iTemp++)
		{
			/* set the address of write */
			data[0] = (iAddress >> 8) & 0xFF;
			data[1] = iAddress & 0xFF;

			memcpy(data + 2, val + (iTemp * 8), 32);
			ret = XIic_Send(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_ADDR, data, 34, XIIC_STOP);
			// usleep(1500);
			if (ret < 34)
			{
				DEBUG_INFO("ret = %d\n", ret);
				printf("EEPROM Write error\n");
				free(data);
				return EEPROM_WRITE_ERROR;
			}
			iAddress += 32;
			usleep(2000);
			// DEBUG_INFO("write eeprom successfully");
		}
		data[0] = (iAddress >> 8) & 0xFF;
		data[1] = iAddress & 0xFF;

		iTemp = DataSize - ((iCount - 1) * 32);
		if ((iTemp % 4) == 0)
		{
			size = iTemp / 4;
		}
		else
		{
			size = (iTemp / 4) + 1;
		}

		// memcpy(data + 2, val + ((iCount - 1) * 32), DataSize - ((iCount - 1) * 32));
		for (int i = 0; i < size; i++)
		{
			data[((iCount - 1) * 32) + i + 2] = (val[((iCount - 1) * 8) + i]) & 0xFF;
			data[((iCount - 1) * 32) + i + 3] = (val[((iCount - 1) * 8) + i] >> 8) & 0xFF;
			data[((iCount - 1) * 32) + i + 4] = (val[((iCount - 1) * 8) + i] >> 16) & 0xFF;
			data[((iCount - 1) * 32) + i + 5] = (val[((iCount - 1) * 8) + i] >> 24) & 0xFF;
		}

		ret = XIic_Send(I2C_EEPROM_BASEADDR, EEPROM_DEVICE_ADDR, data, iTemp + 2, XIIC_STOP);
		// usleep(1500);
		if (ret < DataSize - ((iCount - 1) * 32) + 2)
		{
			printf("EEPROM Write error\n");
			free(data);
			return EEPROM_WRITE_ERROR;
		}

		free(data);
	}
	return NO_ERROR;
}
