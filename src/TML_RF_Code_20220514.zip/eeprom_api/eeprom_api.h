/*******************************************************************************
**	File name		: eeprom_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __EEPROM_API_H__ 
#define __EEPROM_API_H__

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define I2C_EEPROM_BASEADDR 0x80013000
#define EEPROM_DEVICE_ADDR 0xA0
#define EEPROM_DEVICE_WRITE_ADDR 0xA0
#define EEPROM_DEVICE_READ_ADDR 0xA1
#define MAX_DATASIZE 0x1000
#define EEPROM_ONCE_OFFSET 4

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int EepromRead(int Address, int DataSize, int *val);
extern int EepromWrite(int Address, int DataSize, int *val);
extern int EepromSecureWrite(int Address, int DataSize, int *val);

#endif