



int mem_mmap(unsigned long long phyModuleAddr, unsigned int phyModuleSize, unsigned long long *pVirModuleAddr);
int mem_unmap(unsigned long long VirModuleAddr, unsigned int phyModuleSize);