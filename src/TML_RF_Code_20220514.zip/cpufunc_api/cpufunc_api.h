/*******************************************************************************
**	File name		: cpufunc_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __CPUFUNC_API_H__
#define __CPUFUNC_API_H__

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct
{
    // sem_t *lock;
    int fd;
    int SelectableSecond;
} WDT_ST;

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define TRUE 1
#define FALSE 0
#define LED1_GPIO_NUMBER 1
#define LED2_GPIO_NUMBER 2
#define DEV_DRV_VER (0x20210819)
#define I2C_DRV_CPU_TEMP "/dev/i2c-3"
#define WATCHDOG_DRV "/dev/watchdog0"
#define LED_GPIO_MODE 483
#define DIPSW_GPIO_MODE 479
#define I2C_CONFIG_CMD (0xA06001)
#define I2C_RD_BUFF_SIZE 2
#define TEMP_DEVICE_ADDR 0x49 /* the address of temperature register */
#define TEMP_REG_ADDR 0x01
#define RST_LPD_IOU2_REG 0xFF5E0238
#define TTC1_MODULE_REG 0xFF120000
#define TTC1_CONTROL_TIMER_REG 0xFF12006c
#define TTC1_COUNTER_CONTROL_REG 0xFF12000C
#define TTC1_COUNTER_VALUE_REG 0xFF120018
#define I2C_TMP117_BASEADDR1 0x80011000 // TMP117_1
#define I2C_TMP117_BASEADDR2 0x80012000 // TMP117_2
#define BASE_ADDRESS 0x80000000
#define MAX_REG_SIZE 0xFFFF
#define FPGA_VERSION_OFFSET 0xFFFC
#define SW1_GPIO_NUMBER 0
#define SW2_GPIO_NUMBER 1
#define SW3_GPIO_NUMBER 2
#define SW4_GPIO_NUMBER 3
#define FAN_GPIO_NUMBER 340
#define GPIO_DIR_IN 0

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int LedControl(int ledno, int control);
extern int GetDeviceDriverVersion(int *version);
extern int DipSWRead(int *ReadData);
extern int GetCPUTemp(double *Temperature);
extern int WdtStart(int SelectableSecond);
extern int WdtStop(void);
extern int WdtReset(void);
extern int GetBrdTemp(double *Temperature);
extern int GetFanState(int *FanState);
extern int SetKernelDate(const struct timeval *tv, const struct timezone *tz);

#endif