#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "Err32_def_api.h"

int mem_mmap(unsigned long long phyModuleAddr, unsigned int phyModuleSize, unsigned long long *pVirModuleAddr)
{
    int iRet = NO_ERROR;
    int fd;
    unsigned long long map_VirthAddr;
    unsigned long long map_PhyAddr;
    //unsigned int map_offset;
    // unsigned page_size = sysconf(_SC_PAGESIZE);

    do
    {
        fd = open("/dev/mem", O_RDWR | O_SYNC);
        if (fd <= NO_ERROR)
        {
            iRet = MMAP_ERROR;
            printf("/dev/mem file open failed!\n");
            break;
        }
        map_PhyAddr = phyModuleAddr; //physical address

        map_VirthAddr = (unsigned long long)mmap(NULL, phyModuleSize,
                                                 PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)map_PhyAddr);
        if (map_VirthAddr == (unsigned long long)MAP_FAILED)
        {
            printf("\tERROR : Address Map Failed.\n");
            iRet = MMAP_ERROR;
            break;
        }

        *pVirModuleAddr = map_VirthAddr;
        close(fd);
    } while (0);

    return iRet;
}

int mem_unmap(unsigned long long VirModuleAddr, unsigned int phyModuleSize)
{
    int iRet = NO_ERROR;
    int fd;
    do
    {
        fd = open("/dev/mem", O_RDWR | O_SYNC);
        if (fd <= NO_ERROR)
        {
            iRet = MMAP_ERROR;
            break;
        }

        munmap((void *)VirModuleAddr, phyModuleSize);

        close(fd);
    } while (0);

    return iRet;
}
