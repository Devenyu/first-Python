/*
  @
  @   Date               :        30.11.2018 / Sunday
  @
  @   Contact            :        Writing by Muhammet Rasit KIYAK                    @https://www.linkedin.com/in/mrstkyk/
  @                               mrstkyk@gmail.com
  @
  @   Description        :        This Library for TMP117/TMP116 Temperature Sensor on Texas Instruments
  @                               Dependency library is HAL for STM32 series (__STM32xx_HAL_I2C_H)
  @
*/

#include "tmp117.h"
#include "axi_i2c.h"
#include "common.h"
#include <unistd.h>

// #include <linux/i2c.h>

uint8_t TMP117_DeviceID = 0x92;

/*
   @Brief         Get temperature basically
   @Description   Function gives to us ambient temperature
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  Float
 */
double TMP117_get_Temperature(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_TemperatureRegister;
      uint8_t buf[2];

      /* send the cmd of read temperature*/
      DEBUG_INFO("XIic_Send");
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      DEBUG_INFO("XIic_Recv");
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((((buf[0] << 8) | buf[1])) * 0.0078125);
}

/*
   @Brief         Get Configuration
   @Description   Get Configuration Register Value
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_Configuration(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_ConfigurationRegister;
      uint8_t buf[2];

      /* send the cmd of get the configuration*/
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Set Configuration
   @Description   Set Configuration Register for Features
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_Configuration(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_ConfigurationRegister;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief         Set HighLimit
   @Description   Set HighLimit for Alert
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_HighLimit(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_TemperatureHighLimit;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief         Get Highlimit
   @Description   Get Highlimit Register Value
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_HighLimit(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_TemperatureHighLimit;
      uint8_t buf[2];

      /* send the cmd of get HighLimit */
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Set LowLimit
   @Description   Set LowLimit for Alert
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_LowLimit(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_TemperatureLowLimit;
      buf[1] = first;  // Reset Value
      buf[2] = second; // Reset Value

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief         Get LowLimit
   @Description   Get Lowlimit Register Value
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_LowLimit(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_TemperatureLowLimit;
      uint8_t buf[2];

      /* send the cmd of get low limit*/
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Get EEPROM Unlock Register Value
   @Description   Check EEPROM for Unlock/Lock
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_EEPROM_Unclock(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_EEPROM_Uclock;
      uint8_t buf[2];

      /* send the cmd of get eeprom unclock */
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Set EEPROM Unlock Register Value
   @Description   Active/Inactive for EEPROM read/write situation
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_EEPROM_Unlock(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_EEPROM_Uclock;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_EEPROM1(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_EEPROM1;
      buf[1] = first;  // Reset Value
      buf[2] = second; // Reset Value

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_EEPROM1(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_EEPROM1;
      uint8_t buf[3];

      /* send the cmd of get eeprom1 */
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_EEPROM2(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_EEPROM2;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_EEPROM2(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_EEPROM2;
      uint8_t buf[2];

      /* send the cmd of get eeprom2 */
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_EEPROM3(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_EEPROM3;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief         Get EEPROM3 Value
   @Description
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_EEPROM3(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_EEPROM3;
      uint8_t buf[2];

      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Set Temperature Offset Value
   @Description   Set Temperature Offset Value for Calibrating
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
                  uint8_t first     ->  [15:8]
                  uint8_t second    ->  [7:0]
   @Return value  void
 */
void TMP117_set_Temperature_Offset(uint32_t iic_baseaddress, uint8_t first, uint8_t second)
{
      uint8_t buf[3];
      buf[0] = TMP117_Temperature_Offset;
      buf[1] = first;
      buf[2] = second;

      XIic_Send(iic_baseaddress, TMP117_DeviceID, buf, 3, XIIC_STOP);
      usleep(1500);
}

/*
   @Brief         Get Temperature Offset Value
   @Description   Get Temperature Offset Value for Calibrating
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_Temperature_Offset(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_Temperature_Offset;
      uint8_t buf[3];

      /* send the cmd of get temperature offset */
      XIic_Send(iic_baseaddress, TMP117_DeviceID, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      XIic_Recv(iic_baseaddress, TMP117_DeviceID, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Get ID Register
   @Description   Check Device ID for Error Handler
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  uint16_t
 */
uint16_t TMP117_get_ID_Register(uint32_t iic_baseaddress)
{
      uint8_t address_offset = TMP117_ID_Register;
      uint8_t buf[3];
      buf[0] = address_offset;

      /* send the cmd of get ID Register*/
      DEBUG_INFO("XIic_Send");
      XIic_Send(iic_baseaddress, 0x92, &address_offset, 1, XIIC_STOP);
      usleep(1500);
      DEBUG_INFO("XIic_Recv");
      XIic_Recv(iic_baseaddress, 0x93, buf, 2, XIIC_STOP);

      return ((buf[0] << 8) | buf[1]);
}

/*
   @Brief         Custom Initialization
   @Description   Custom Parameters for Sensor
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  void
 */
void TMP117_Initialization(uint32_t iic_baseaddress)
{
      DEBUG_INFO("TMP117_set_Configuration");
      TMP117_set_Configuration(iic_baseaddress, 0x02, 0x20);
      DEBUG_INFO("TMP117_set_Temperature_Offset");
      TMP117_set_Temperature_Offset(iic_baseaddress, 0x00, 0x00); // Default Value
      DEBUG_INFO("TMP117_set_LowLimit");
      TMP117_set_LowLimit(iic_baseaddress, 0x12, 0x80); // Set 10 Celcius
      DEBUG_INFO("TMP117_set_HighLimit");
      TMP117_set_HighLimit(iic_baseaddress, 0x51, 0x20); // Set 40 Celcius
}

/*
   @Brief         Default Initialization
   @Description   Default Parameters for Sensor
   @Parameter     I2C_HandleTypeDef ->  HAL_I2C Handle
   @Return value  void
 */
void TMP117_Initialization_DEFAULT(uint32_t iic_baseaddress)
{
      DEBUG_INFO("TMP117_set_Configuration");
      TMP117_set_Configuration(iic_baseaddress, 0x02, 0x20);
      DEBUG_INFO("TMP117_set_Temperature_Offset");
      TMP117_set_Temperature_Offset(iic_baseaddress, 0x00, 0x00);
      DEBUG_INFO("TMP117_set_LowLimit");
      TMP117_set_LowLimit(iic_baseaddress, 0x80, 0x00);
      DEBUG_INFO("TMP117_set_HighLimit");
      TMP117_set_HighLimit(iic_baseaddress, 0x60, 0x00);
      DEBUG_INFO("TMP117_set_EEPROM_Unlock");
      TMP117_set_EEPROM_Unlock(iic_baseaddress, 0x00, 0x00);
}