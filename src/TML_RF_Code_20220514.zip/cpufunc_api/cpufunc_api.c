/*******************************************************************************
**	File name		: cpufunc_api.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
								header file
------------------------------------------------------------------------------*/
#include <sys/time.h>
#include <pthread.h>
#include <stdio.h>
#include <sched.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/watchdog.h>

#include "i2c.h"
#include "gpio.h"
#include "mem_map.h"
#include "Err32_def_api.h"
#include "Communication_api.h"
#include "cpufunc_api.h"
#include "tmp117.h"
#include "axi_i2c.h"
#include "common.h"

/*------------------------------------------------------------------------------
							  static variables
------------------------------------------------------------------------------*/
WDT_ST wdtInfo;

/*--------------------------------------------------------------------------------
							   function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] LedControl

[arguments]
ledno			    :	the number of leds
control				:	control command


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int LedControl(int ledno, int control)
{
	int iRet;
	unsigned int exportGpio;
	/* judge the validity of the parameters */
	if ((0 > ledno) || (3 < ledno))
	{
		printf("the number of led is wrong\n");
		return LED_NO_ERROR;
	}
	if ((control != GPIO_VAL_LOW) && (control != GPIO_VAL_HIGH))
	{
		printf("the control parameters is wrong\n");
		return PARAM_ERROR;
	}

	exportGpio = ledno + LED_GPIO_MODE;
	gpio_export(exportGpio); /* export the gpio */
	// usleep(1000);
	gpio_set_dir(exportGpio, GPIO_DIR_OUT); /* set the direction of gpio */
	// usleep(1000);
	iRet = gpio_set_value(exportGpio, (unsigned char)control); /* set the value of gpio */
	// usleep(1000);
	gpio_unexport(exportGpio); /* unexport the gpio */
	return iRet;
}

/*********************************************************************************
[function name] GetDeviceDriverVersion

[arguments]
version			    :	the version of FPGA



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetDeviceDriverVersion(int *version)
{
	uint32_t iRet = 0;
	unsigned long long reg_VirthBaseAddr;

	if (NULL == version)
	{
		return PARAM_ERROR;
	}

	/* map the mode register address */
	iRet = mem_mmap(BASE_ADDRESS, MAX_REG_SIZE, &reg_VirthBaseAddr);
	if (NO_ERROR != iRet)
	{
		return GENERAL_ERROR;
	}

	*version = *(unsigned *)(reg_VirthBaseAddr + FPGA_VERSION_OFFSET);

	mem_unmap(reg_VirthBaseAddr, MAX_REG_SIZE);

	return NO_ERROR;
}

/*********************************************************************************
[function name] DipSWRead

[arguments]
swno			    :	the number of dipsw
ReadData			:	the data to read


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int DipSWRead(int *ReadData)
{
	int iRet;
	int iTemp = 0;
	uint16_t ecat_val;
	unsigned int exportGpio = DIPSW_GPIO_MODE;
	unsigned char value[4];
	/* judge the validity of the parameters */
	if (NULL == ReadData)
	{
		printf("ReadData is null\n");
		return PARAM_ERROR;
	}

	for (iTemp = 0; iTemp < 4; iTemp++)
	{
		gpio_export(exportGpio);			   /* export the gpio */
		gpio_set_dir(exportGpio, GPIO_DIR_IN); /* set the direction of gpio */
		// printf("==================\n");
		iRet = gpio_get_value(exportGpio, value + iTemp); /* get the value of gpio */
		gpio_unexport(exportGpio);						  /* unexport the gpio */
		exportGpio++;
	}

	ReadData[1] = value[0] + (value[1] * 0x10) + (value[2] * 0x100) + (value[3] * 0x1000);

	iRet = ECAT_DipSwRead(&ecat_val);
	if (NO_ERROR == iRet)
	{
		iTemp = ecat_val;
		memcpy(ReadData, &iTemp, 4);
	}
	else
	{
		printf("fail to read the ETHCAT_SW\n");
	}

	return iRet;
}

/*********************************************************************************
[function name] GetCPUTemp

[arguments]
Temperature			:	the temperature of CPU



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetCPUTemp(double *Temperature)
{

	int fd; /* FD of the IIC device opened. */
	int iRet;
	// Create I2C bus
	if ((fd = open(I2C_DRV_CPU_TEMP, O_RDWR)) < 0)
	{
		printf("Failed to open the bus. \n");
		return OPEN_ERROR;
	}
	// Get I2C device, TMP112 I2C address is 0x48(72)
	ioctl(fd, I2C_SLAVE, TEMP_DEVICE_ADDR);

	// Select configuration register(0x01)
	// Continous Conversion mode, 12-Bit Resolution, Fault Queue is 1(0x60)
	// Polarity low, Thermostat in Comparator mode, Disables Shutdown mode(0xA0)
	uint8_t config[3] = {0};
	uint32_t I2C_config_cmd = I2C_CONFIG_CMD;
	memcpy(config, &I2C_config_cmd, 3);
	write(fd, config, 3);
	// usleep(10000);

	// Read 2 bytes of data from register(0x00)
	// temp msb, temp lsb
	char reg[1] = {0x00};
	write(fd, reg, 1);
	char data[2] = {0};
	iRet = read(fd, data, 2);
	if (iRet != 2)
	{
		printf("Error : Input/Output error \n");
		return iRet;
	}
	else
	{
		// Convert the data to 12-bits
		int temp = (data[0] * 256 + data[1]) / 16;
		if (temp > 2047)
		{
			temp -= 4096;
		}
		*Temperature = temp * 0.0625;

		return NO_ERROR;
	}
}

/*********************************************************************************
[function name] WdtStart

[arguments]
SelectableSecond	:	the spare time of the wdt



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int WdtStart(int SelectableSecond)
{
	/* judge the parameters*/
	if (0 >= SelectableSecond)
	{
		printf("parameter error\n");
		return PARAM_ERROR;
	}
	int iRet = 0;
	int timeout = 0;
	int fd_watchdog = open(WATCHDOG_DRV, O_WRONLY);
	if (fd_watchdog == -1)
	{
		perror("watchdog");
		return WDT_ERROR;
	}
	iRet = ioctl(fd_watchdog, WDIOC_GETTIMEOUT, &timeout);
	if (NO_ERROR != iRet)
	{
		printf("watchdog get timeout error\n");
		close(fd_watchdog);
		return WDT_ERROR;
	}
	printf("The timeout was is %d seconds\n", timeout);
	iRet = ioctl(fd_watchdog, WDIOC_SETTIMEOUT, &SelectableSecond);
	if (NO_ERROR != iRet)
	{
		printf("watchdog get timeout error\n");
		close(fd_watchdog);
		return WDT_ERROR;
	}
	printf("The timeout was set to %dseconds\n", SelectableSecond);
	iRet = ioctl(fd_watchdog, WDIOC_GETTIMEOUT, &timeout);
	if (NO_ERROR != iRet)
	{
		printf("watchdog get timeout error\n");
		close(fd_watchdog);
		return WDT_ERROR;
	}
	printf("The timeout was is %d seconds\n", timeout);

	// pthread_t wdt_thread;
	wdtInfo.fd = fd_watchdog;
	wdtInfo.SelectableSecond = SelectableSecond;

	return NO_ERROR;
}

/*********************************************************************************
[function name] WdtStop

[arguments]
 NULL



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int WdtStop(void)
{
	int iRet = NO_ERROR;
	int options = WDIOS_DISABLECARD;
	iRet = ioctl(wdtInfo.fd, WDIOC_SETOPTIONS, &options);
	if (NO_ERROR != iRet)
	{
		printf("watchdog close error\n");
		return WDT_ERROR;
	}
	printf("watchdog close successfully\n");
	close(wdtInfo.fd);

	return NO_ERROR;
}

/*********************************************************************************
[function name] WdtReset

[arguments]
 NULL



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int WdtReset(void)
{
	int iRet = 0;
	iRet = write(wdtInfo.fd, "\0", 1);
	if (iRet != 1)
	{
		printf("there are some errors\n");
		close(wdtInfo.fd);
		return WDT_ERROR;
	}
	printf("WDT reset successfully\n");

	return NO_ERROR;
}

/*********************************************************************************
[function name] GetBrdTemp

[arguments]
Temperature			:	the temperature of Board1,2



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetBrdTemp(double *Temperature)
{
	/*judge the temperature parameter */
	if (NULL == Temperature)
	{
		printf("the parameter is NULL\n");
		return PARAM_ERROR;
	}

	double val1;
	// double val2; /* store the result of reading the temperature */
	uint32_t iic_tmp117_baseaddr1 = I2C_TMP117_BASEADDR1;
	// uint32_t iic_tmp117_baseaddr2 = I2C_TMP117_BASEADDR2;
	// uint16_t Id_Temp;

	/* init the tmp117 */
	TMP117_Initialization_DEFAULT(iic_tmp117_baseaddr1);
	// TMP117_Initialization_DEFAULT(iic_tmp117_baseaddr2);

	// Id_Temp = TMP117_get_ID_Register(iic_tmp117_baseaddr1);
	// DEBUG_INFO("the id of tmp117 is %d\n", Id_Temp);

	/* read the data */
	val1 = TMP117_get_Temperature(iic_tmp117_baseaddr1);

	Temperature[0] = val1;

	/* read the data */
	// val2 = TMP117_get_Temperature(iic_tmp117_baseaddr2);

	// Temperature[1] = val2;

	return NO_ERROR;
}

/*********************************************************************************
[function name] GetFanState

[arguments]
FanState			:	the state of Fan



[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int GetFanState(int *FanState)
{
	uint8_t ret_exp;
	uint8_t ret_dir;
	uint8_t ret_value;
	uint8_t val;

	if (NULL == FanState)
	{
		printf("pointer error");
		return PARAM_ERROR;
	}

	ret_exp = gpio_export(FAN_GPIO_NUMBER);
	if (NO_ERROR != ret_exp)
	{
		printf("export error!");
		return FAN_EXPORT_ERROR;
	}

	ret_dir = gpio_set_dir(FAN_GPIO_NUMBER, GPIO_DIR_IN);
	if (NO_ERROR != ret_dir)
	{
		printf("set_dir error!");
		return FAN_DIR_ERROR;
	}

	ret_value = gpio_get_value(FAN_GPIO_NUMBER, &val);
	if (NO_ERROR != ret_value)
	{
		printf("get_value error!");
		return FAN_READ_ERROR;
	}

	*FanState = val;
	return NO_ERROR;
}

/*********************************************************************************
[function name] SetKernelDate

[arguments]
tv 				:	set the time of a particular clock
tz				:	the zone of the timer


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
int SetKernelDate(const struct timeval *tv, const struct timezone *tz)
{
	if (NULL == tv)
	{
		printf("the tv parameter is NULL\n");
		return PARAM_ERROR;
	}
	// if(NULL == tz)
	// {
	// 	printf("the tz parameter is NULL\n");
	// 	return PARAM_ERROR;
	// }
	int iRet;

	iRet = settimeofday(tv, tz);
	return iRet;
}
