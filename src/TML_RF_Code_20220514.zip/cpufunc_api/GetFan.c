/*
 * Copyright (c) 2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <string.h>
#include "stddef.h"
#include "mem_map.h"
// #include <sys/mman.h>



// int mem_mmap(unsigned long long phyModuleAddr, unsigned int phyModuleSize, unsigned long long *pVirModuleAddr)
// {
//     int iRet = 0;
//     int fd;
//     unsigned long long map_VirthAddr;
//     unsigned long long map_PhyAddr;
//     //unsigned int map_offset;
//     unsigned page_size = sysconf(_SC_PAGESIZE);

//     do
//     {
//         fd = open("/dev/mem", O_RDWR | O_SYNC);
//         if (fd <= 0)
//         {
//             iRet = -1;
//             printf("/dev/mem file open failed!\n");
//             break;
//         }
//         map_PhyAddr = phyModuleAddr; //physical address

//         map_VirthAddr = (unsigned long long)mmap(NULL, phyModuleSize,
//                                                  PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)map_PhyAddr);
//         if (map_VirthAddr == 0)
//         {
//             printf("\tERROR : Address Map Failed.\n");
//             iRet = -1;
//             break;
//         }

//         *pVirModuleAddr = map_VirthAddr;
//         close(fd);
//     } while (0);

//     return iRet;
// }

// int mem_unmap(unsigned long long VirModuleAddr, unsigned int phyModuleSize)
// {
//     int iRet = 0;
//     int fd;
//     do
//     {
//         fd = open("/dev/mem", O_RDWR | O_SYNC);
//         if (fd <= 0)
//         {
//             iRet = -1;
//             break;
//         }

//         munmap((void *)VirModuleAddr, phyModuleSize);

//         close(fd);
//     } while (0);

//     return iRet;
// }

int write_baseaddr_reg(unsigned int baseaddr, unsigned int addr, unsigned int data)
{
    unsigned long long reg_VirthBaseAddr;
    int iRet = 0;
    unsigned long long uiAddr;
    unsigned int uiData;
    unsigned int size = addr + 4;

    iRet = mem_mmap(baseaddr, size, &reg_VirthBaseAddr);
    if (iRet != 0)
    {
        printf("write_reg mmap error \n");
        return -1;
    }
    uiAddr = reg_VirthBaseAddr + addr;
    uiData = (unsigned int)(data & 0xFFFFFFFF);

    //  printf("write_reg %X %X\n",addr,uiData);
    *((unsigned *)(uiAddr)) = uiData;

    mem_unmap(reg_VirthBaseAddr, size);

    return 0;
}

unsigned int read_baseaddr_reg(unsigned int baseaddr, unsigned int addr)
{
    unsigned int data = 0;
    unsigned long long uiAddr;
    unsigned int uiData;
    unsigned long long reg_VirthBaseAddr;
    unsigned int size = addr + 4;
    int iRet = 0;

    iRet = mem_mmap(baseaddr, size, &reg_VirthBaseAddr);
    if (iRet != 0)
    {
        printf("read_reg error \n");
        return -1;
    }

    uiAddr = reg_VirthBaseAddr + addr;
    //printf("reg_VirthBaseAddr %X %X %X\n",uiAddr,reg_VirthBaseAddr,addr);

#if 1
    uiData = *((unsigned int *)uiAddr);
#else
    uiData = *((unsigned *)(uiAddr));
#endif
    // printf("read_reg %X %X\n",addr,uiData);
    data = (unsigned int)uiData;

    mem_unmap(reg_VirthBaseAddr, size);

    return data;
}

int write_reg(unsigned int addr, unsigned int data)
{
    // unsigned long long reg_VirthBaseAddr;
    // unsigned long long ullAddr;
    // int iRet = 0;
    unsigned long long page_size = sysconf(_SC_PAGESIZE);
    unsigned long long page_addr = (addr & ~(page_size - 1));
    unsigned long long page_offset = (unsigned long long)addr - page_addr;
    /*
 	 printf("\t wr reg start \n");
 	 printf("\t write_reg. %X \n",page_addr);
 	 printf("\t write_reg. %X \n",page_size);
 	 printf("\t write_reg. %X \n",page_offset);
 	 */

    return write_baseaddr_reg((unsigned int)page_addr, page_offset, data);
}

unsigned int read_reg(unsigned int addr)
{
    unsigned long long page_size = sysconf(_SC_PAGESIZE);
    unsigned long long page_addr = (addr & ~(page_size - 1));
    unsigned long long page_offset = (unsigned long long)addr - page_addr;

    return read_baseaddr_reg((unsigned int)page_addr, (unsigned int)page_offset);
}

// int getFanSpeed()
// {
//     unsigned int ulRet;
//     unsigned int ulRet2;
//     unsigned int speed;
//     /*RST_TTC (CRL) Register Description
//         Description:	TTC Software Reset
//         0xC ---------- 0b1100
//         bit0:   Triple counter timer instance 0
//         bit1:   Triple counter timer instance 1
//         bit2:   Triple counter timer instance 2
//         bit3:   Triple counter timer instance 3*/
//     write_reg(0xFF5E0238, 0x00006000); //   (0xE|0xD)
//     /* 0x30 -------- 0b0110000
//         bit0:Presscaler Enable:
//                 0: disable
//                 1: enable
//         bit1-4:Prescale value:1000->2^9
//                 0: divide by 2
//                 1: divide by 4
//                 N: 2^(N+1)
//                 15: 65536
//                 Note: Prescaler must be enabled using [PS_En].
//         bit5:   0: from 3-input mux (see LPD_IOP_SLCR.TTC_CLK_SEL)
//                 1: EMIO: TTCx_CLK0
//         bit6:   External Clock Edge: when this bit is set and the extend clock is selected, 
//                 the counter clocks on the negative going edge of the external clock input.*/
//     write_reg(0xFF120000, 0x30);
//     /* 0x5 --------- 0b101
//         bit0:   Enable timer: when this bit is high, the event timer is enabled.
//         bit1:   When this bit is high, the timer counts pclk cycles during the low level duration of ext_clk; when low, 
//                 the event timer counts the high level duration of ext_clk.
//         bit2:   When this bit is low, the event timer is disabled and set to zero when an Event Timer Register overflow occurs; 
//                 when set high, the timer continues counting on overflow.*/
//     write_reg(0xFF12006c, 0x5);
//     /*0x20 ----  0b100000 ,
//      
//         Output Waveform Enable, acitve Low
//         0: enabled
//         1: disabled
//         (field name: Wave_en)*/
//     write_reg(0xFF12000C, 0x20);

//     ulRet = read_reg(0xFF120018);
//     sleep(1);
//     ulRet2 = read_reg(0xFF120018);
//     speed = ulRet2 - ulRet;
//     speed = speed * 30;
//     printf("get speed %ld RPM\r\n", speed);
//     return 0;
// }

// int main(int argc, char *argv[])
// {
//     int speed;

//     getFanSpeed();
//     return 0;
// }
