/*******************************************************************************
**	File name		: i2c.c                                           **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include "i2c.h"
#include "Err32_def_api.h"

/*------------------------------------------------------------------------------
                              static variables
------------------------------------------------------------------------------*/
typedef unsigned short Xuint16; /**< unsigned 16-bit */
typedef unsigned char Xuint8;

/*--------------------------------------------------------------------------------
                               function define
--------------------------------------------------------------------------------*/
/*********************************************************************************
[function name] i2c read

[arguments]
device_addr			:	device slave address
sub_addr			:	device register address
buff				:	read data
ByteNo				:	read byte length

[return value]
Normal	:	S_OK

*********************************************************************************/
unsigned char _i2c_read(int fd, unsigned char device_addr, unsigned short sub_addr, unsigned char *buff, int ByteNo)
{
	int ret;
	unsigned char buftmp[32];
	struct i2c_rdwr_ioctl_data i2c_data;
	unsigned short slaveAddr = device_addr;

	i2c_data.nmsgs = 2;
	i2c_data.msgs = (struct i2c_msg *)malloc(i2c_data.nmsgs * sizeof(struct i2c_msg));
	if (i2c_data.msgs == NULL)
	{
		printf("malloc error");
		close(fd);
		return SYS_ENOMEM_ERROR;
	}

	ret = ioctl(fd, I2C_TIMEOUT, 1);

	ret = ioctl(fd, I2C_RETRIES, 2);

	//write reg
	memset(buftmp, 0, 32);
	if (sizeof(AddressType) == 1)
	{
		buftmp[0] = (Xuint8)(sub_addr);
	}
	else
	{
		buftmp[0] = (Xuint8)(sub_addr >> 8);
		buftmp[1] = (Xuint8)(sub_addr);
	}

	i2c_data.msgs[0].len = sizeof(AddressType);
	i2c_data.msgs[0].addr = slaveAddr;
	i2c_data.msgs[0].flags = 0; // 0: write 1:read
	i2c_data.msgs[0].buf = buftmp;
	//read data
	i2c_data.msgs[1].len = ByteNo;
	i2c_data.msgs[1].addr = slaveAddr;
	i2c_data.msgs[1].flags = 1; // 0: write 1:read
	i2c_data.msgs[1].buf = buff;

	ret = ioctl(fd, I2C_RDWR, &i2c_data);

	printf("I2C_RDWR_RET = %d\n", ret);

	if (NO_ERROR > ret)
	{
		printf("read data (device address: %x register address: %x ) error,ioctl return %d\r\n", slaveAddr, sub_addr, ret);
		close(fd);
		free(i2c_data.msgs);
		return I2C_READ_ERROR;
	}
	free(i2c_data.msgs);
	// close(fd);

	return NO_ERROR;
}

/*********************************************************************************
[function name] i2c write

[arguments]
device_addr			:	device slave address
sub_addr			:	device register address
buff				:	write data
ByteNo				:	write byte length

[return value]
Normal	:	S_OK

*********************************************************************************/
unsigned char _i2c_write(int fd, unsigned char device_addr, unsigned short sub_addr, unsigned char *buff, int ByteNo)
{
	int ret;
	unsigned char buftmp[32];
	struct i2c_rdwr_ioctl_data i2c_data;
	// struct i2c_msg msgs[2];
	unsigned short slaveAddr = device_addr;
	//unsigned char      wrbuf[3] = {0, 0x1, 0x3c};
	//device_addr >>= 1;

	i2c_data.nmsgs = 1;
	i2c_data.msgs = (struct i2c_msg *)malloc(i2c_data.nmsgs * sizeof(struct i2c_msg));
	if (i2c_data.msgs == NULL)
	{
		printf("malloc error");
		close(fd);
		return SYS_ENOMEM_ERROR;
	}

	ioctl(fd, I2C_TIMEOUT, 1);
	ioctl(fd, I2C_RETRIES, 2);

	memset(buftmp, 0, 32);

	if (sizeof(AddressType) == 1)
	{
		buftmp[0] = (Xuint8)(sub_addr);
	}
	else
	{
		buftmp[0] = (Xuint8)(sub_addr >> 8);
		buftmp[1] = (Xuint8)(sub_addr);
	}

	memcpy(buftmp + sizeof(AddressType), buff, ByteNo);
	// msgs[0].addr = slaveAddr;
	// msgs[0].len = ByteNo + sizeof(AddressType);
	// msgs[0].buf = buftmp;
	// i2c_data.msgs = &msgs[0];
	// i2c_data.nmsgs = 1;
	i2c_data.msgs[0].len = ByteNo + sizeof(AddressType);
	i2c_data.msgs[0].addr = slaveAddr;
	i2c_data.msgs[0].flags = 0; // 0: write 1:read
	i2c_data.msgs[0].buf = buftmp;
	printf("===============================================\n");
	// printf("fd is %d\n", fd);
	// printf("I2C_RDWR: %x\n", I2C_RDWR);
	printf("i2c_data.msgs[0].len = %d\n", i2c_data.msgs[0].len);
	printf("i2c_data.msgs[0].addr = %x\n", i2c_data.msgs[0].addr);
	printf("i2c_data.msgs[0].flags = %d\n", i2c_data.msgs[0].flags);
	printf("i2c_data.msgs[0].buf[0] = %x\n", i2c_data.msgs[0].buf[0]);
	printf("i2c_data.msgs[0].buf[1] = %x\n", i2c_data.msgs[0].buf[1]);
	printf("i2c_data.msgs[0].buf[2] = %x\n", i2c_data.msgs[0].buf[2]);
	printf("i2c_data.msgs[0].buf[3] = %x\n", i2c_data.msgs[0].buf[3]);
	printf("i2c_data.msgs[0].buf[4] = %x\n", i2c_data.msgs[0].buf[4]);
	ret = ioctl(fd, I2C_RDWR, &i2c_data);

	if (ret < 0)
	{
		printf("write data (device address: %x register address: %x ) error, ioctl return %d\r\n", slaveAddr, sub_addr, ret);
		close(fd);
		free(i2c_data.msgs);
		return I2C_READ_ERROR;
	}
	free(i2c_data.msgs);
	// close(fd);

	_alpu_delay_ms(100);
	return NO_ERROR;
}

/*********************************************************************************
[function name] binary_to_decimal

[arguments]
data		    :	the data will be transformed


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
double binary_to_decimal(char data)
{
	double sum;
	int a[4];
	double b = 1;

	if (((data >> 0) & 0b0001) == 1)
	{
		a[3] = 1;
	}
	else
	{
		a[3] = 0;
	}
	if (((data >> 1) & 0b0001) == 1)
	{
		a[2] = 1;
	}
	else
	{
		a[2] = 0;
	}
	if (((data >> 2) & 0b0001) == 1)
	{
		a[1] = 1;
	}
	else
	{
		a[1] = 0;
	}
	if (((data >> 3) & 0b0001) == 1)
	{
		a[0] = 1;
	}
	else
	{
		a[0] = 0;
	}

	sum = a[0] * (b / 2) + a[1] * (b / 4) + a[2] * (b / 8) + a[3] * (b / 16);

	return sum;
}

/*********************************************************************************
[function name] _alpu_delay_ms

[arguments]
i			    :	the time of dalay


[return value]
Normal	:	NO_ERROR

*********************************************************************************/
void _alpu_delay_ms(unsigned int i)
{
	usleep(2000 * i);
}
