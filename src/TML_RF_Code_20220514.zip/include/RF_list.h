/*******************************************************************************
**	File name		: RF_list.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __RF_LIST_H__
#define __RF_LIST_H__

/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct RF_PDO_SDO_LIST_s
{
    int address;
    int datasize;
} RF_list;

extern RF_list RF_read_pdo_area[10];

extern RF_list RF_write_pdo_area[10];

extern RF_list RF_write_sdo_area[3];

extern RF_list RF_read_sdo_area[3];

extern unsigned int writepdo_listnum;
extern unsigned int readpdo_listnum;
extern unsigned int writesdo_listnum;
extern unsigned int readsdo_listnum;

// #define _RF_LIST_H_
#endif /*_RF_LIST_H_*/