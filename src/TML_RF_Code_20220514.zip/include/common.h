#ifndef __COMMON_H__
#define __COMMON_H__

#include <stdio.h>
#include <stdint.h>
#define DEBUG 0
#define MAX_PATH 100
#define MAX_STRING 1024
#define RETURN_MAIN_MENU 0
#define RETURN_CUR_MENU -1
#define EXIT_MAIN_MENU -2
#define LEDTEST 1
#define VERSIONTEST 2
#define DIPSWTEST 3
#define CPUTEMPTEST 4
#define WDTTEST 5
#define BOARDTEMPTEST 6
#define FANTEST 7
#define TIMETEST 8
#define ETHERCATTEST 9
#define DEVICENETTEST 10
#define RFFREQMODETEST 11
#define FEATURERUNTEST 12
#define MAXDATASETMODETEST 13
#define SAMPLINGMODETEST 14
#define WLEVELCALC 15
#define SELFCALIBRATIONTEST 16
#define TEMPCOMPENSATIONTEST 17
#define BOARDSENSORTEST 18
#define RAWDATATEST 19
#define EEPROMTEST 20
#define DIOTEST 21
#define FILETEST 22
#define ROWCOLUMNTEST 23
#define MULTCORTEST 24
#define TIMESTATISTICTEST 25
#define EXITMENU 99
#define MAX_AD_OFFSET 0x75300
#define MAX_AD_BUF_SIZE 6000000

typedef struct
{
    long long now_time;
    uint32_t data[6];
} AD_DATA_STRUCT;

// struct timeval timeout;

#if DEBUG
// #define DEBUG_INFO(format, ...) printf("[DEBUG]" format " \n", ##__VA_ARGS__);
#define DEBUG_INFO(format, ...) printf("[DEBUG]" format " %s %d\n", ##__VA_ARGS__, __func__, __LINE__);
#else
#define DEBUG_INFO(format, ...)
#endif

#endif