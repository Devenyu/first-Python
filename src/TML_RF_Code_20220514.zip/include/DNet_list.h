/*******************************************************************************
**	File name		: RF_list.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __DNET_LIST_H__
#define __DNET_LIST_H__

#include <stdint.h>
/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef struct DNET_EXPLICIT_LIST_S
{
    uint8_t ServiceId;
    uint8_t ClassId;
    uint8_t AttributeId;
    uint8_t DataSize;
} DNet_Explicit_list;

typedef struct DNET_IDENTITY_LIST_S
{
    uint8_t ServiceId;
    uint8_t ClassId;
    uint8_t AttributeId;
    uint8_t InstanceId;
    uint8_t DataSize;
} DNet_Identity_list;

extern DNet_Explicit_list Explicit_area[12];

extern DNet_Identity_list Identity_area[20];

extern unsigned int explicit_listnum;
extern unsigned int identity_listnum;

#endif 