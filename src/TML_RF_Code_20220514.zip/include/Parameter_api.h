/*******************************************************************************
**	File name		: Parameter_api.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2022/03/21 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __PARAMETER_API_H__
#define __PARAMETER_API_H__

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define BASE_ADDRESS 0x80000000
#define I2C_EEPROM_BASEADDR 0x80013000
#define MODE_REG_SIZE 0x7FFF
#define COFF_1STORDER_OFFSET 0x0
#define CONSTANTS_OFFSET 0x4

#define MAX_PARAM_SIZE 128
#define MAX_DATASIZE 0x1000
#define EEPROM_ONCE_OFFSET 4
#define MaxnumOfBoardSeriallParamArrays 128
typedef struct BoardSerialParam
{
    float coff_1stOrder[MaxnumOfBoardSeriallParamArrays];    // linear coefficient
    float constant[MaxnumOfBoardSeriallParamArrays];         // constant
    float range_lowerLimit[MaxnumOfBoardSeriallParamArrays]; // Effective range Lower limit
    float range_upperLimit[MaxnumOfBoardSeriallParamArrays]; // Effective range Upper limit
} boardserial_param;

typedef struct SensorSerialParam
{
    // Two-row, two-column single-precision floating-point arithmetic float matrix_1raw_1clm;
    float matrix_1raw_1clm; // A
    float matrix_1raw_2clm; // B
    float matrix_2raw_1clm; // C
    float matrix_2raw_2clm; // D
} sensor_param;

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int GetBoardSerialparameter(struct BoardSerialParam *boardParam, int ch);
extern int SetBoardSerialparameter(const struct BoardSerialParam *boardParam, int ch);
extern int GetSensorSerialparameter(struct SensorSerialParam *sensorParam, int ch);
extern int SetSensorSerialparameter(const struct SensorSerialParam *sensorParam, int ch);
#endif