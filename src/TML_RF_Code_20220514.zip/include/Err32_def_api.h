/**
 *	@brief	制御用演算装置 APIエラーコード定義ヘッダファイル
 *
 *	@file	Err32_def_api.h
 *
 *	@author	
 *
 *	@date	2020/05/19
 *
 *  @copyright  Copyright (c) 2020 Tokyo Electron Miyagi Ltd.  All rights reserved.
 */
#ifndef	ERR32_DEF_API_H_	/* { */
#define	ERR32_DEF_API_H_

/************************************************/
/*	インクルード・ファイル						*/
/************************************************/
#include <stdint.h>

/************************************************/
/*	ユーザ定義型定義							*/
/************************************************/
typedef	int32_t		Err32_t;					/**< エラー型定義						*/

/************************************************/
/*	プログラム定数／列挙型定義					*/
/************************************************/
enum
{
	NO_ERROR				= 0,				/* エラーなし									*/
	GENERAL_ERROR			= -1,				/* その他エラー									*/
	INIT_ERROR				= -2,				/* 初期化エラー									*/
	PARAM_ERROR				= -3,				/* パラメータエラー								*/
	OPEN_ERROR				= -4,				/* オープンエラー								*/
	CLOSE_ERROR				= -5,				/* クローズエラー								*/
	MMAP_ERROR				= -6,				/* MMAPエラー									*/
	MUNMAP_ERROR			= -7,				/* MUNMAPエラー									*/
	LED_NO_ERROR			= -8,				/* LED番号エラー								*/
	DIPSW_NO_ERROR			= -9,				/* DIPSW番号エラー								*/
	I2C_READ_ERROR			= -10,				/* I2Cリードエラー								*/
	NO_BOARD_ERROR			= -11,				/* ボードなしエラー								*/
	DI_VAL_GET_ERROR		= -12,				/* DI取得エラー									*/
	DO_VAL_GET_ERROR		= -13,				/* DO取得エラー									*/
	SPI_OPEN_ERROR			= -14,				/* SPIオープンエラー							*/
	SPI_CLOSE_ERROR			= -15,				/* SPIクローズエラー							*/
	SPI_READ_ERROR			= -16,				/* SPIリードエラー	*/		
	SPI_WRITE_ERROR			= -17,				/* SPI書き込みエラー */	
	REQ_FULL_ERROR			= -18,				/* 要求ブロックフル								*/
	FILE_EXCL_ERROR			= -19,				/* ファイル排他エラー							*/
	FILE_OVER_ERROR			= -20,				/* ファイルオープン上限エラー					*/
	ET1100_ERROR			= -21,				/* ET1100エラー									*/
	R5_FIRMWARE_ERROR		= -22,				/* R5ファームウェアエラー						*/
	BOOTSTRAP_IN_PROGRESS	= -23,				/* ET1100がBOOTSTRAPモード						*/
	MODBUS_LOOP_ERROR		= -24,				/* libmodbusのループエラー						*/
	FILE_OPEN_ERROR			= -25,				/* ファイルオープニングエラー */
	FILE_INIT_ERROR			= -26,				/* ファイル初期化エラー */
	DNET_WRITE_ERROR		= -27,				/* DNet書き込みエラー */
	DNET_READ_ERROR			= -28,				/* DNetの読み込みエラー */
	FAN_EXPORT_ERROR		= -29,				/* FAN エクスポートエラー */
	FAN_DIR_ERROR			= -30,				/* FANの方向エラー */
	FAN_READ_ERROR			= -31,				/* FAN読み取りエラー */
	SPI_COMMUN_ERROR		= -32,				/* SPI通信エラー */
	MEMMAP_ERROR 			= -33,				/* MEMMAPエラー */
	EEPROM_READ_ERROR		= -34,				/* EEPROMリードエラー */
	EEPROM_WRITE_ERROR		= -35,				/* EEPROM書き込みエラー */
	DNET_TRANSFER_ERROR		= -36,				/* DNET転送エラー */
	DNET_CONNECT_ERROR		= -37,				/* DNET接続エラー */
	DNET_DISCONNECT_ERROR	= -38,				/* DNET断線エラー */
	OUT_RANGE_ERROR			= -39,				/* データ長範囲外エラー */
	REQUEST_BLOCK_FULL_ERROR= -40,				/* リクエストブロックオーバーフローエラー */
	MALLOC_ERROR				= -41,				/* メモリ要求エラー */
	WDT_ERROR				= -42,				/*Watchdogの設定エラー*/
	DNET_POLLING_ERROR		= -43,				/*	DNET Pollingエラー*/
	FILE_EXCLUSION_ERROR	= -44,				/*	File exclusionエラー*/
	FILE_MANAGE_INFO_ERROR  = -45,				/*	File infoエラー*/
	REQUEST_LOCK_FULL		= -46,				/*	Request Lockエラー*/				
	TIME_STATISTIC_ERROR	= -47,				/*	Time statisticsエラー*/ 
	DNET_SIZE_ERROR			= -48,	
	DNET_NOCONN_ERROR		= -49,	
	
	SYS_EACCES_ERROR		= -100,				/* アクセス許可エラー(EACCES)					*/
	SYS_EDQUOT_ERROR		= -101,				/* クォータエラー(EDQUOT)						*/
	SYS_EEXIST_ERROR		= -102,				/* ファイル存在エラー(EEXIST)					*/
	SYS_EFAULT_ERROR		= -103,				/* アドレスエラー(EFAULT)						*/
	SYS_EFBIG_ERROR			= -104,				/* ファイルサイズ超過エラー(EFBIG)				*/
	SYS_EINTR_ERROR			= -105,				/* シグナルエラー(EINTR)						*/
	SYS_EINVAL_ERROR		= -106,				/* 無効な引数エラー(EINVAL)						*/
	SYS_EISDIR_ERROR		= -107,				/* ディレクトリ参照エラー(EISDIR)				*/
	SYS_ELOOP_ERROR			= -108,				/* リンクループエラー(ELOOP)					*/
	SYS_EMFILE_ERROR		= -109,				/* ファイルオープン数エラー(EMFILE)				*/
	SYS_ENAMETOOLONG_ERROR	= -110,				/* ファイル名長さ超過エラー(ENAMETOOLONG)		*/
	SYS_ENFILE_ERROR		= -111,				/* ファイルオープン数システム超過エラー(ENFILE)	*/
	SYS_ENODEV_ERROR		= -112,				/* デバイス参照エラー(ENODEV)					*/
	SYS_ENOENT_ERROR		= -113,				/* ファイル不在エラー(ENOENT)					*/
	SYS_ENOMEM_ERROR		= -114,				/* メモリ不足エラー(ENOMEM)						*/
	SYS_ENOSPC_ERROR		= -115,				/* 空き容量不足エラー(ENOSPC)					*/
	SYS_ENOTDIR_ERROR		= -116,				/* ディレクトリ不在エラー(ENOTDIR)				*/
	SYS_ENXIO_ERROR			= -117,				/* デバイス不在エラー(ENXIO)					*/
	SYS_EOPNOTSUPP_ERROR	= -118,				/* サポート外エラー(EOPNOTSUPP)					*/
	SYS_EOVERFLOW_ERROR		= -119,				/* ファイルサイズ超過エラー(EOVERFLOW)			*/
	SYS_EPERM_ERROR			= -120,				/* パーミッションエラー(EPERM)					*/
	SYS_EROFS_ERROR			= -121,				/* 読み込み専用ファイルシステムエラー(EROFS)	*/
	SYS_ETXTBSY_ERROR		= -122,				/* ファイルビジーエラー(ETXTBSY)				*/
	SYS_EWOULDBLOCK_ERROR	= -123,				/* ファイルブロックエラー(EWOULDBLOCK)			*/
	SYS_EBADF_ERROR			= -124,				/* ファイルディスクリプタ無効エラー(EBADF)		*/
	SYS_EIO_ERROR			= -125,				/* I/Oエラー(EIO)								*/
												/* EAGAIN と EWOULDBLOCKは同一値				*/
	SYS_EAGAIN_ERROR		= SYS_EWOULDBLOCK_ERROR,
	SYS_EDESTADDRREQ_ERROR	= -127,				/* デスティネーションアドレスエラー(EDESTADDRREQ)	*/
	SYS_EPIPE_ERROR			= -128,				/* パイプエラー(EPIPE)							*/
};

#endif	///	ERR32_DEF_API_H_	/* } */

