/*******************************************************************************
**	File name		: i2c.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __I2C_H__ 
#define __I2C_H__

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <fcntl.h>
#include <stdio.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
typedef unsigned short  Xuint16;    /**< unsigned 16-bit */
typedef unsigned char   Xuint8;
typedef Xuint8 AddressType;

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
unsigned char _i2c_write(int fd, unsigned char device_addr, unsigned short sub_addr, unsigned char *buff, int ByteNo);
unsigned char _i2c_read(int fd, unsigned char device_addr, unsigned short sub_addr, unsigned char *buff, int ByteNo);
void _alpu_delay_ms(unsigned int i);
double binary_to_decimal(char data);

#endif /* __I2C_H__ */