/*******************************************************************************
**	File name		: gpio.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef SRC_COMPONENTS_GPIO_H_
#define SRC_COMPONENTS_GPIO_H_

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define GPIO_ON		0
#define GPIO_OFF	1
#define MAX_BUF			64
#define PLL_EEPROMSEL_NUM	953
#define PLL_RESET_NUM		959
#define GPIO_DIR_OUT		1
#define GPIO_DIR_IN			0
#define GPIO_VAL_LOW		0
#define GPIO_VAL_HIGH		1

/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
int io_gpio_read(int gpioNumb);													// Read the gpio's value, and return it.
int gpio_export(unsigned int uiGPIO_number);									// Export GPIO
int gpio_unexport(unsigned int uiGPIO_number);									// Unexport GPIO
int gpio_set_dir(unsigned int iGPIO_number, unsigned int uiOutFlag);			// Set the direction of GPIO
int gpio_set_value(unsigned int iGPIO_number, unsigned char uiValue);			// Set the value of GPIO
int gpio_get_value(unsigned int iGPIO_number, unsigned char *puchValue);		// Get the value of GPIO
int gpio_set_edge(unsigned int iGPIO_number, char *cEdge);						// Set the edge of GPIO


#endif /* SRC_COMPONENTS_GPIO_H_ */
