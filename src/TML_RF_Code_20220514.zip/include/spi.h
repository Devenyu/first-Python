/*******************************************************************************
**	File name		: spi.h                                     **
**	Company			: TOKYO ELECTRON DEVICE LTD.                              **
**----------------------------------------------------------------------------**
** [2021/09/14 Devenyu] New regulations have been made                        **
*******************************************************************************/
#ifndef __SPI_H_
#define __SPI_H_

/*------------------------------------------------------------------------------
                                header file
------------------------------------------------------------------------------*/
#include <stdint.h>


/*------------------------------------------------------------------------------
                              global define
------------------------------------------------------------------------------*/
#define SPI_CPHA 0x01
#define SPI_CPOL 0x02
#define SPI_MODE_0 (0 | 0)
#define SPI_MODE_1 (0 | SPI_CPHA)
#define SPI_MODE_2 (SPI_CPOL | 0)
#define SPI_MODE_3 (SPI_CPOL | SPI_CPHA)


/*------------------------------------------------------------------------------
                              define structures
------------------------------------------------------------------------------*/
typedef enum
{
    SPI_MODE0 = SPI_MODE_0, /*!< CPOL = 0, CPHA = 0 */
    SPI_MODE1 = SPI_MODE_1, /*!< CPOL = 0, CPHA = 1 */
    SPI_MODE2 = SPI_MODE_2, /*!< CPOL = 1, CPHA = 0 */
    SPI_MODE3 = SPI_MODE_3, /*!< CPOL = 1, CPHA = 1 */
} SPIMode;

typedef enum
{
    DISABLE = 0,
    ENABLE = 1
} SPICSEN;

typedef enum
{
    SPI_CS_Mode_LOW = 0,  /*!< Chip Select 0 */
    SPI_CS_Mode_HIGH = 1, /*!< Chip Select 1 */
    SPI_CS_Mode_NONE = 3  /*!< No CS, control it yourself */
} SPIChipSelect;

typedef enum
{
    SPI_BIT_ORDER_LSBFIRST = 0, /*!< LSB First */
    SPI_BIT_ORDER_MSBFIRST = 1  /*!< MSB First */
} SPIBitOrder;

typedef enum
{
    SPI_3WIRE_Mode = 0,
    SPI_4WIRE_Mode = 1
} BusMode;

typedef struct SPIStruct
{
    uint32_t speed;
    uint16_t mode;
    uint16_t delay;
    int fd; //
} SPI_InitTypeDef;





/*------------------------------------------------------------------------------
                              function define
------------------------------------------------------------------------------*/
extern int SPI_Init(char *SPI_device, SPIMode mode, uint32_t speed);           // The most primitive configuration of SPI
extern int SPI_End(void);                                                          // close spi
extern int SPI_SendAndReceive(const uint8_t *txBuf, uint8_t *rxBuf, uint32_t len); //Synchronous sending and receiving of spi data
extern int SPI_SendData(uint8_t *txBuf, int32_t len);                              //spi sends data
extern int SPI_ReceiveData(uint8_t *rxBuf, int32_t len);                           //spi receive data
extern void Delay_Ms(unsigned int i);                                                          //delay in milliseconds
extern uint8_t Get_CheckSum(uint8_t *buff , int len);                                      //calculate the checksum

#endif //__spi_
